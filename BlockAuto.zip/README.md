## Version 3.0 — refonte visuelle et +110 nouveaux blocs

BlockAuto passe à **285 blocs** (83 déclencheurs, 202 actions / conditions).

### 🎨 Refonte visuelle
- Nouvelle palette « Nébuleuse » : fonds plus profonds, surfaces étagées, halo violet en haut de l'écran.
- Écran d'accueil repensé : carte d'en-tête en dégradé avec salutation selon l'heure et compteurs
  (automatisations actives, total, nombre d'exécutions), tuiles de raccourcis, recherche épinglée,
  filtres **Toutes / Actives / En pause**, animation d'apparition de la liste, bouton « + » qui se replie au défilement.
- Cartes d'automatisation plus lisibles : aperçu de la chaîne en icônes (déclencheur ➜ blocs),
  automatisations désactivées estompées, actions compactes.
- Boîtes de dialogue sombres et arrondies dans toute l'appli, nouvelle icône d'application.
- Les réglages d'un bloc s'affichent en clair (« Durée (secondes) : 10 » au lieu de « seconds = 10 »).
- Formulaire de réglage généré automatiquement pour tous les nouveaux blocs (libellés, valeurs par défaut, bornes, aide).

### ⚡ 24 nouveaux déclencheurs
Batterie pleine à 100 %, batterie trop chaude, recharge sans fil · données mobiles connectées / coupées,
Internet perdu / retrouvé, Bluetooth déconnecté / activé / désactivé, Wi‑Fi activé / désactivé ·
volume modifié, téléphone retourné face contre table / remis à l'endroit, main devant le capteur de proximité,
Xᵉ déverrouillage de la journée · lever et coucher du soleil (calcul local, avec décalage),
plusieurs heures par jour, chaque heure pile (plage réglable), dernier jour du mois ·
SMS contenant un mot-clé, appel manqué. Tous les SMS exposent aussi `{sms_code}` (code de validation détecté).

### 🧩 72 nouvelles actions
- **🎵 Musique & son** : piste suivante / précédente, lecture, pause, stop, volume +/−, couper le son,
  volumes notifications / appels, faire sonner le téléphone pour le retrouver, mélodies synthétisées,
  lancer une musique par recherche, annoncer l'heure / la batterie, briefing vocal.
- **⚙️ Système** : lampe qui clignote, SOS lumineux, luminosité automatique, 14 pages de réglages,
  volet de notifications, réglages rapides, menu d'alimentation, écran partagé, effacer les notifications BlockAuto.
- **✉️ Communication** : notification à long texte, notification qui ouvre un lien, WhatsApp pré-rempli,
  SMS pré-rempli, composer un numéro.
- **🧭 Web & navigation** : itinéraire GPS (voiture, à pied, vélo, transports), recherche sur la carte,
  recherche web, YouTube, fiche Play Store, résumé Wikipédia.
- **📊 Infos & capteurs** : batterie, appareil, date/heure (format libre), réseau, presse-papiers,
  IP publique, cours crypto, taux de change, luminosité ambiante, jours restants avant une date.
- **🔤 Texte & fichiers** : transformer (majuscules, inverser, compter…), rechercher/remplacer,
  regex, extraire un code OTP, arrondir, supprimer une variable globale, élément de liste au hasard,
  journal / écriture / lecture de fichiers texte.
- **🌐 Connecteurs** : Microsoft Teams, Gotify, Mastodon, webhook JSON libre.
- **🎉 Fun** : dé, boule magique, compliment, citation, anecdote, fond d'écran aléatoire ou dégradé,
  mode disco, mot de passe, respiration guidée, action ou vérité, pierre-feuille-ciseaux.

### 🔀 16 nouvelles conditions
En charge, écran allumé, verrouillé, écouteurs connectés, musique en cours, mode sonnerie,
mode sombre, économie d'énergie, Internet disponible, données mobiles, mode avion, Bluetooth activé,
week-end, variable contient un texte, variable vide, date précise.

### ✨ 10 nouveaux modèles
Retrouver mon téléphone par SMS, copie automatique des codes SMS, retourné = vibreur, briefing vocal du matin,
ambiance coucher de soleil, trop de déverrouillages, surveillance de la connexion, journal des appels manqués,
écouteurs = musique, batterie pleine.

### 🐛 Corrections
- « Arrêter l'automatisation » placé dans un Si / Sinon ou une répétition n'arrêtait que la branche en cours :
  il arrête maintenant vraiment l'automatisation (idem pour une condition « ancien style » non remplie et la chance perdue).
- La condition « une application est installée » n'était jamais évaluée.
- Les diffusions système « collantes » (casque, dock, USB…) ne déclenchent plus d'automatisations à chaque démarrage du service.

## Version 2.2 — cette itération
### Correctif clé : envoi de messages dans une appli (Instagram, WhatsApp, Messenger, Telegram, SMS...)
Le bloc "écrire dans le champ actif" exigeait qu'un champ de saisie ait DÉJÀ le focus,
ce qui n'arrive presque jamais juste après avoir ouvert une appli/conversation — c'est
pourquoi écrire puis envoyer un message dans une appli de messagerie échouait
silencieusement. Le service d'accessibilité cherche maintenant lui-même le champ de
saisie le plus probable (le dernier champ éditable trouvé dans l'arbre — la barre de
message est presque toujours en bas de l'écran), clique dessus pour lui donner le
focus, PUIS y écrit le texte, avec un repli automatique si le premier essai échoue le
temps que le clavier s'affiche.

### Nouveaux blocs actions
- **Dans l'appli : cliquer sur le champ de saisie**
- **Dans l'appli : écrire et envoyer un message** — générique (pas propre à une appli),
  fonctionne avec ce qui est réellement affiché à l'écran ; recherche automatique du
  bouton d'envoi (« Envoyer », « Send »...) si aucun libellé précis n'est donné.
- **Dans l'appli : envoyer plusieurs messages à la suite** — comme "Envoyer plusieurs
  SMS", mais pour n'importe quelle appli de messagerie déjà ouverte à l'écran ; pause
  réglable entre chaque envoi, `{n}` pour le numéro d'ordre.
- **Ouvrir une appli, ouvrir une conversation, et envoyer un message** — combo complet
  en un seul bloc (ouverture de l'appli, clic sur un contact/une conversation, écriture,
  envoi).

### Nouveaux déclencheurs
- **Toutes les X heures**
- **Un texte disparaît de l'écran** (symétrique de "Un texte apparaît à l'écran")
- **Notification contenant un texte précis** (filtre par contenu, en plus du filtre par
  application déjà existant)

### Limite d'usage à garder en tête
Ces blocs pilotent l'écran comme le ferait un doigt humain : ils ne peuvent cliquer que
sur ce qui est réellement affiché. Envoyer beaucoup de messages très rapidement via une
appli tierce reste soumis aux limites/règles d'usage de cette appli (une appli de
messagerie peut limiter ou bloquer un usage jugé automatisé/abusif, comme pour tout
usage automatisé intensif).

# BlockAuto V2

Version 2.0 du projet BlockAuto.

## Corrections principales
- moteur d'exécution sérialisé pour éviter les conflits entre automatisations simultanées ;
- chaînes A → B plus fiables et variables transmises ;
- erreurs d'actions visibles dans l'historique au lieu d'être masquées ;
- HTTP GET/POST/PUT/PATCH/DELETE avec code et réponse disponibles via `{http_code}` et `{http_body}` ;
- presse-papiers corrigé avec `ClipData` ;
- notifications refusées explicitement si la permission manque ;
- captures d'écran / accueil / récents / verrouillage signalent quand l'accessibilité n'est pas active ;
- alarmes exactes utilisées quand Android les autorise, sinon fallback sur une alarme inexacte ;
- déclencheurs d'intervalle reprogrammés après chaque exécution ;
- nom du projet et du ZIP conservés : `BlockAuto.zip`.

## Nouveautés de cette version
### Nouveaux déclencheurs
- Mode sombre activé / désactivé
- Économie d'énergie activée / désactivée
- Langue du téléphone changée
- Date ou heure changée manuellement
- Posé / retiré d'un dock ou support
- Mode avion désactivé (le mode "activé" existait déjà)
- Application mise à jour
- **Un texte apparaît à l'écran** (surveille le contenu d'une appli via l'accessibilité, dans une appli précise ou n'importe laquelle)

### Nouveaux blocs "Dans l'appli" (interaction avec d'autres applications)
Ces blocs utilisent le service d'accessibilité BlockAuto pour agir directement dans une autre application (à activer dans Réglages BlockAuto) :
- Cliquer sur un texte / appui long sur un texte
- Cliquer sur une icône via sa description d'accessibilité
- Écrire dans le champ de saisie actif
- Faire défiler vers le haut / le bas (ou balayer dans une direction précise via un vrai geste tactile)
- Bouton retour
- Attendre qu'un texte apparaisse (avec délai maximum)
- Ouvrir une application puis cliquer sur un texte (combine ouverture + clic)
- Nouvelle condition : "un texte est visible à l'écran"

## Version 2.1 — améliorations de cette itération
### Fiabilité / sécurité des données
- **Suppression sécurisée** : un appui sur « Supprimer » demande maintenant confirmation, puis affiche un bandeau « Annuler » pendant quelques secondes (l'automatisation et sa programmation sont restaurées si besoin). Avant, un appui accidentel supprimait définitivement une automatisation sans aucun recours.

### Nouvelles fonctionnalités
- **Dupliquer une automatisation** : bouton « Dupliquer » sur chaque carte, pour partir d'un scénario existant sans tout reconstruire. La copie est créée désactivée par sécurité (pour ne pas faire tourner deux automatisations identiques en même temps sans le vouloir) et son nom se termine par « (copie) ».
- **Recherche** : un champ de recherche filtre la liste par nom d'automatisation ou par type de déclencheur, utile dès que la liste s'allonge.
- **Sauvegarde / restauration** : bouton « 💾 Sauvegarde » pour exporter toutes les automatisations vers un fichier `.json` (à garder, partager, ou remettre après réinstallation), et pour en réimporter un. L'import fusionne avec l'existant sans écraser les automatisations déjà présentes (basé sur leur identifiant interne).

## Limites Android
Certaines fonctions sont volontairement signalées comme indisponibles lorsqu'Android les interdit aux applications classiques (notamment activation/désactivation directe du Wi-Fi ou du Bluetooth sur les versions récentes). BlockAuto ne prétend pas contourner ces protections. De même, les blocs "Dans l'appli" ne peuvent cliquer que sur ce qui est réellement affiché à l'écran (texte ou description exacts) : ils ne peuvent pas deviner le contenu d'une application qui n'est pas ouverte, ni contourner une appli qui bloque volontairement l'accessibilité (ex : certaines apps bancaires).

## Version 2.2 — vraies chaînes, nouveaux déclencheurs et blocs fun

### 🔗 Créateur de séquence (nouvelle fonctionnalité)
Bouton "🔗 Séquences" sur l'écran principal : un assistant qui enchaîne plusieurs automatisations **existantes**, dans l'ordre choisi, avec une pause réglable (en secondes) entre chacune — sans avoir à poser un par un les blocs "Exécuter une autre automatisation" / "Attendre" dans l'atelier. On choisit ensuite quand la lancer (manuellement, ou à heure fixe chaque jour). Le résultat est une automatisation normale (préfixée 🔗), modifiable ensuite bloc par bloc dans l'atelier comme n'importe quelle autre.

### Nouveaux blocs déclencheurs
- **Toutes les X min, entre deux heures** : un intervalle classique qui reste silencieux hors de sa fenêtre horaire (pratique pour des rappels fréquents en journée, jamais la nuit).
- **Pleine lune 🌕** et **Vendredi 13 😱** : vérifiés chaque jour à une heure choisie, calculés localement (aucune connexion nécessaire).
- **Heure palindrome 🔮** : se déclenche tout seul à chaque heure qui se lit pareil à l'envers (11:11, 12:21, 20:02...), sans aucun réglage.

### Nouveaux blocs actions — catégorie "🎉 Fun & surprises"
- **Pile ou face 🪙** : tire à pile ou face et pose le résultat (PILE/FACE) dans une variable — pensé pour être testé juste après par un bloc "Si variable = X", pour de vrais scénarios à embranchements.
- **Raconter une blague au hasard 🤡** : blagues intégrées à l'application, fonctionne sans réseau.
- **Changer le fond d'écran 🎨** : couleur unie, préréglages ou code hex personnalisé.
- **Ouvrir une application au hasard 🎰** : pioche parmi les applications installées.
- **Boîte mystère 🎁** : effet surprise différent à chaque exécution (vibration, bip, blague, pile ou face, ou rien du tout).


## Format de fichier `.Ba`

BlockAuto utilise l'extension personnalisée **`.Ba`** pour les automatisations exportées.

- Signature : `BLOCKAUTO_BA`
- Version actuelle : `1`
- `TYPE=AUTOMATION` : une automatisation
- `TYPE=BUNDLE` : plusieurs automatisations
- `DATA=` : données JSON de l'automatisation ou du bundle

Une application future peut prendre en charge `.Ba` en déclarant le MIME `application/x-blockauto` et en lisant cette signature/version. Les fichiers `.Ba` sont associés à BlockAuto sur Android ; l'extension seule ne constitue pas un chiffrement ou un verrouillage de sécurité.
