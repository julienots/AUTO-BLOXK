# BlockAuto V2

Version 2.0 du projet BlockAuto.

## Corrections principales
- moteur d'exécution sérialisé pour éviter les conflits entre automatisations simultanées ;
- chaînes A → B plus fiables et variables transmises ;
- erreurs d'actions visibles dans l'historique au lieu d'être masquées ;
- HTTP GET/POST/PUT/PATCH/DELETE avec code et réponse disponibles via `{http_code}` et `{http_body}` ;
- presse-papiers corrigé avec `ClipData` ;
- notifications refusées explicitement si la permission manque ;
- captures d'écran / accueil / récents / verrouillage signalent quand l'accessibilité n'est pas active ;
- alarmes exactes utilisées quand Android les autorise, sinon fallback sur une alarme inexacte ;
- déclencheurs d'intervalle reprogrammés après chaque exécution ;
- nom du projet et du ZIP conservés : `BlockAuto.zip`.

## Limites Android
Certaines fonctions sont volontairement signalées comme indisponibles lorsqu'Android les interdit aux applications classiques (notamment activation/désactivation directe du Wi-Fi ou du Bluetooth sur les versions récentes). BlockAuto ne prétend pas contourner ces protections.
