## Version 2.2 — cette itération
### Correctif clé : envoi de messages dans une appli (Instagram, WhatsApp, Messenger, Telegram, SMS...)
Le bloc "écrire dans le champ actif" exigeait qu'un champ de saisie ait DÉJÀ le focus,
ce qui n'arrive presque jamais juste après avoir ouvert une appli/conversation — c'est
pourquoi écrire puis envoyer un message dans une appli de messagerie échouait
silencieusement. Le service d'accessibilité cherche maintenant lui-même le champ de
saisie le plus probable (le dernier champ éditable trouvé dans l'arbre — la barre de
message est presque toujours en bas de l'écran), clique dessus pour lui donner le
focus, PUIS y écrit le texte, avec un repli automatique si le premier essai échoue le
temps que le clavier s'affiche.

### Nouveaux blocs actions
- **Dans l'appli : cliquer sur le champ de saisie**
- **Dans l'appli : écrire et envoyer un message** — générique (pas propre à une appli),
  fonctionne avec ce qui est réellement affiché à l'écran ; recherche automatique du
  bouton d'envoi (« Envoyer », « Send »...) si aucun libellé précis n'est donné.
- **Dans l'appli : envoyer plusieurs messages à la suite** — comme "Envoyer plusieurs
  SMS", mais pour n'importe quelle appli de messagerie déjà ouverte à l'écran ; pause
  réglable entre chaque envoi, `{n}` pour le numéro d'ordre.
- **Ouvrir une appli, ouvrir une conversation, et envoyer un message** — combo complet
  en un seul bloc (ouverture de l'appli, clic sur un contact/une conversation, écriture,
  envoi).

### Nouveaux déclencheurs
- **Toutes les X heures**
- **Un texte disparaît de l'écran** (symétrique de "Un texte apparaît à l'écran")
- **Notification contenant un texte précis** (filtre par contenu, en plus du filtre par
  application déjà existant)

### Limite d'usage à garder en tête
Ces blocs pilotent l'écran comme le ferait un doigt humain : ils ne peuvent cliquer que
sur ce qui est réellement affiché. Envoyer beaucoup de messages très rapidement via une
appli tierce reste soumis aux limites/règles d'usage de cette appli (une appli de
messagerie peut limiter ou bloquer un usage jugé automatisé/abusif, comme pour tout
usage automatisé intensif).

# BlockAuto V2

Version 2.0 du projet BlockAuto.

## Corrections principales
- moteur d'exécution sérialisé pour éviter les conflits entre automatisations simultanées ;
- chaînes A → B plus fiables et variables transmises ;
- erreurs d'actions visibles dans l'historique au lieu d'être masquées ;
- HTTP GET/POST/PUT/PATCH/DELETE avec code et réponse disponibles via `{http_code}` et `{http_body}` ;
- presse-papiers corrigé avec `ClipData` ;
- notifications refusées explicitement si la permission manque ;
- captures d'écran / accueil / récents / verrouillage signalent quand l'accessibilité n'est pas active ;
- alarmes exactes utilisées quand Android les autorise, sinon fallback sur une alarme inexacte ;
- déclencheurs d'intervalle reprogrammés après chaque exécution ;
- nom du projet et du ZIP conservés : `BlockAuto.zip`.

## Nouveautés de cette version
### Nouveaux déclencheurs
- Mode sombre activé / désactivé
- Économie d'énergie activée / désactivée
- Langue du téléphone changée
- Date ou heure changée manuellement
- Posé / retiré d'un dock ou support
- Mode avion désactivé (le mode "activé" existait déjà)
- Application mise à jour
- **Un texte apparaît à l'écran** (surveille le contenu d'une appli via l'accessibilité, dans une appli précise ou n'importe laquelle)

### Nouveaux blocs "Dans l'appli" (interaction avec d'autres applications)
Ces blocs utilisent le service d'accessibilité BlockAuto pour agir directement dans une autre application (à activer dans Réglages BlockAuto) :
- Cliquer sur un texte / appui long sur un texte
- Cliquer sur une icône via sa description d'accessibilité
- Écrire dans le champ de saisie actif
- Faire défiler vers le haut / le bas (ou balayer dans une direction précise via un vrai geste tactile)
- Bouton retour
- Attendre qu'un texte apparaisse (avec délai maximum)
- Ouvrir une application puis cliquer sur un texte (combine ouverture + clic)
- Nouvelle condition : "un texte est visible à l'écran"

## Version 2.1 — améliorations de cette itération
### Fiabilité / sécurité des données
- **Suppression sécurisée** : un appui sur « Supprimer » demande maintenant confirmation, puis affiche un bandeau « Annuler » pendant quelques secondes (l'automatisation et sa programmation sont restaurées si besoin). Avant, un appui accidentel supprimait définitivement une automatisation sans aucun recours.

### Nouvelles fonctionnalités
- **Dupliquer une automatisation** : bouton « Dupliquer » sur chaque carte, pour partir d'un scénario existant sans tout reconstruire. La copie est créée désactivée par sécurité (pour ne pas faire tourner deux automatisations identiques en même temps sans le vouloir) et son nom se termine par « (copie) ».
- **Recherche** : un champ de recherche filtre la liste par nom d'automatisation ou par type de déclencheur, utile dès que la liste s'allonge.
- **Sauvegarde / restauration** : bouton « 💾 Sauvegarde » pour exporter toutes les automatisations vers un fichier `.json` (à garder, partager, ou remettre après réinstallation), et pour en réimporter un. L'import fusionne avec l'existant sans écraser les automatisations déjà présentes (basé sur leur identifiant interne).

## Limites Android
Certaines fonctions sont volontairement signalées comme indisponibles lorsqu'Android les interdit aux applications classiques (notamment activation/désactivation directe du Wi-Fi ou du Bluetooth sur les versions récentes). BlockAuto ne prétend pas contourner ces protections. De même, les blocs "Dans l'appli" ne peuvent cliquer que sur ce qui est réellement affiché à l'écran (texte ou description exacts) : ils ne peuvent pas deviner le contenu d'une application qui n'est pas ouverte, ni contourner une appli qui bloque volontairement l'accessibilité (ex : certaines apps bancaires).

