# BlockAuto

Application Android d'automatisation par blocs (façon Tasker/MacroDroid simplifié).
Tu crées des automatisations en choisissant **1 bloc déclencheur** + **plusieurs blocs actions**
que tu empiles dans l'ordre que tu veux, tu leur donnes un nom, et tu les actives/désactives
d'un simple interrupteur.

## Blocs déclencheurs disponibles
- Heure précise (répétée chaque jour)
- Démarrage du téléphone
- Batterie faible
- Branché sur secteur
- Application ouverte (choisie dans la liste des apps installées)
- Notification reçue (d'une app précise, ou de n'importe laquelle)
- Déclenchement manuel (bouton "Exécuter" dans la liste)
- Appel entrant / Appel terminé

## Blocs actions disponibles
- Ouvrir une application
- Envoyer une notification
- Afficher un message (toast)
- Faire vibrer
- Régler le volume média
- Régler la luminosité
- Lampe torche (on/off)
- Ouvrir un lien
- Ouvrir les réglages Wi-Fi / Bluetooth / Ne pas déranger
- Envoyer un SMS / Passer un appel / Envoyer un e-mail
- Appeler un contact (recherché par nom)
- Ajouter un événement au calendrier
- Partager du texte (menu de partage système)
- Activer/désactiver la rotation automatique
- Activer/désactiver Ne pas déranger
- Prendre une capture d'écran
- Enregistrer un extrait audio (micro)
- Récupérer la position GPS (réutilisable dans les blocs suivants via `{lat}`, `{lon}`, `{location}`)
- Copier dans le presse-papiers / Créer une alarme / Réveiller l'écran
- Enregistrer un événement dans l'historique
- Attendre X secondes (utile entre deux actions)

## Blocs connecteurs (services externes)
- **Requête HTTP générique** (GET/POST) — connecte BlockAuto à n'importe quelle API ou webhook
- **Webhook Discord** — poste un message dans un salon via son URL de webhook
- **Message Telegram** — envoie un message via un bot Telegram (token + chat ID)
- **Webhook Slack**
- **Webhook IFTTT** (Maker Webhooks)
- **Webhook Home Assistant** — déclenche une automatisation Home Assistant locale

Ces blocs peuvent utiliser les variables issues du bloc "Récupérer la position GPS"
(`{lat}`, `{lon}`, `{location}`) dans leurs champs de message/texte, ce qui permet par
exemple d'enchaîner "Position GPS" → "Webhook Discord" pour poster sa position.

Les actions d'une automatisation s'exécutent **dans l'ordre où tu les as ajoutées**.

## 1. Mettre le projet sur GitHub

```bash
cd BlockAuto
git init
git add .
git commit -m "BlockAuto - première version"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/BlockAuto.git
git push -u origin main
```

## 2. Récupérer l'APK compilé automatiquement

Dès que tu pousses sur `main`, l'onglet **Actions** de ton dépôt GitHub lance le workflow
`Build APK` qui compile le projet et génère un fichier APK, téléchargeable dans
**Actions → (dernière exécution) → Artifacts → BlockAuto-debug-apk**.

Pour obtenir une **Release** avec l'APK attaché directement en pièce jointe :
```bash
git tag v1.0
git push origin v1.0
```

## 3. Installer l'APK sur ton téléphone
1. Télécharge le fichier `.apk` depuis GitHub.
2. Transfère-le sur ton téléphone (câble, Drive, etc.).
3. Autorise "Installer des applications inconnues" pour l'app que tu utilises pour l'ouvrir.
4. Installe puis ouvre BlockAuto.

## 4. Autoriser l'app dans BlockAuto
Ouvre le bouton **Autorisations** en haut de l'écran principal et active, selon les blocs
que tu comptes utiliser :
- **Service d'accessibilité** → nécessaire pour "Application ouverte" et "Capture d'écran"
- **Accès aux notifications** → nécessaire pour "Notification reçue"
- **Modifier les réglages système** → nécessaire pour "Régler la luminosité" et "Rotation auto"
- **Afficher par-dessus les autres applications** → **essentiel**, demandé automatiquement au
  premier lancement : sans elle, Android bloque parfois l'ouverture d'une appli/URL/appel/partage
  quand l'automatisation se déclenche app totalement fermée (restriction système Android 10+)
- **Ignorer l'optimisation de batterie** → recommandé pour que les automatisations
  se déclenchent même app fermée
- **Accès à "Ne pas déranger"** → nécessaire pour le bloc "Ne pas déranger" (activer/désactiver)
- SMS, appels, contacts, calendrier, position GPS, micro et notifications classiques sont
  demandées automatiquement au premier lancement (permissions runtime Android).
- Les blocs connecteurs (HTTP, Discord, Telegram, Slack, IFTTT, Home Assistant) utilisent
  Internet, qui est une permission automatique : aucune fenêtre à valider.

## Limites à connaître
- Android moderne ne permet plus à une app normale (sans root) de couper le Wi-Fi/Bluetooth
  ou de passer en mode avion directement : les blocs correspondants ouvrent l'écran de
  réglages concerné plutôt que de basculer l'état eux-mêmes.
- Le bloc "Application ouverte" nécessite le service d'accessibilité activé manuellement
  (Android l'exige pour ce type de détection).
- Aucune donnée ne quitte le téléphone : tout est stocké localement dans l'app.

## Structure du projet
- `app/src/main/java/com/blockauto/app/model` — les blocs (déclencheurs/actions) et le modèle Automatisation
- `app/src/main/java/com/blockauto/app/builder` — l'écran d'assemblage des blocs
- `app/src/main/java/com/blockauto/app/engine` — exécution des actions + planification des alarmes
- `app/src/main/java/com/blockauto/app/receivers` / `services` — écoute des événements système
- `.github/workflows/build-apk.yml` — compilation automatique de l'APK sur GitHub
