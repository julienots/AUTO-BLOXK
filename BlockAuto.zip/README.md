# BlockAuto

Application Android d'automatisation par blocs (façon Tasker/MacroDroid simplifié).
Tu crées des automatisations en choisissant **1 bloc déclencheur** + **plusieurs blocs actions**
que tu empiles dans l'ordre que tu veux, tu leur donnes un nom, et tu les actives/désactives
d'un simple interrupteur.

## Blocs déclencheurs disponibles
- Heure précise (répétée chaque jour)
- Démarrage du téléphone
- Batterie faible
- Branché sur secteur
- Application ouverte (choisie dans la liste des apps installées)
- Notification reçue (d'une app précise, ou de n'importe laquelle)
- Déclenchement manuel (bouton "Exécuter" dans la liste)
- Appel entrant / Appel terminé
- Écouteurs débranchés
- Câble USB (données) branché / débranché
- Connexion à un Wi-Fi précis (par nom de réseau)
- Mode sonnerie changé (normal / vibreur / silencieux, ou n'importe lequel)
- Stockage presque plein

## Blocs actions disponibles
- Ouvrir une application
- Envoyer une notification
- Afficher un message (toast)
- Faire vibrer
- Régler le volume média
- Régler la luminosité
- Lampe torche (on/off)
- Ouvrir un lien
- Ouvrir les réglages Wi-Fi / Bluetooth / Ne pas déranger
- Envoyer un SMS / Passer un appel / Envoyer un e-mail
- Appeler un contact (recherché par nom)
- Ajouter un événement au calendrier
- Partager du texte (menu de partage système)
- Activer/désactiver la rotation automatique
- Activer/désactiver Ne pas déranger
- Prendre une capture d'écran
- Enregistrer un extrait audio (micro)
- Récupérer la position GPS (réutilisable dans les blocs suivants via `{lat}`, `{lon}`, `{location}`)
- Copier dans le presse-papiers / Créer une alarme / Réveiller l'écran
- Enregistrer un événement dans l'historique
- Attendre X secondes (utile entre deux actions)
- Régler le volume de sonnerie (séparé du volume média)
- Arrêter la vibration en cours
- Régler le volume d'alarme
- Lire un texte à voix haute (synthèse vocale)
- Démarrer un minuteur
- Ouvrir l'appareil photo
- Régler la mise en veille de l'écran

## Ce qui a été corrigé
- **Vibrer un temps précis ne fonctionnait pas correctement** : l'action envoyait l'ordre de
  vibrer puis passait tout de suite à la suite (ou arrêtait l'automatisation), ce qui coupait
  souvent la vibration en cours de route sur beaucoup de téléphones — seule la durée par défaut
  (500 ms, assez courte pour se terminer avant que ça n'arrive) semblait fiable. Le bloc attend
  maintenant réellement la durée demandée, comme le faisaient déjà "Réveiller l'écran" et
  "Enregistrer un extrait audio".
- **Les champs de durée/pourcentage/niveau acceptaient n'importe quel texte** : une frappe
  invalide (lettre, champ vide, espace) retombait silencieusement sur une valeur par défaut
  sans prévenir, donnant l'impression que le bloc ne respectait pas ce qui avait été réglé.
  Ces champs utilisent maintenant un clavier numérique, une valeur par défaut pré-remplie, et
  affichent un message explicite si la saisie est ignorée.
- **Écouteurs débranchés** ne pouvait pas être détecté (seul "branchés" existait) : ajouté en
  symétrie avec le Wi-Fi connecté/déconnecté déjà géré par le service de veille.
- **Boucle infinie de notifications** : le bloc "Notification reçue" se déclenchait aussi sur
  les notifications que BlockAuto affiche lui-même (bloc "Envoyer une notification", notification
  du service de veille...). Une automatisation "Notification reçue (n'importe laquelle)" +
  "Envoyer une notification" partait donc en boucle infinie dès sa première exécution. Corrigé :
  les notifications émises par BlockAuto lui-même sont désormais ignorées par ce déclencheur.
- **Mode "n'importe quelle application" du bloc "Notification reçue" inaccessible** : le moteur
  savait déclencher sur la notification de n'importe quelle app (paramètre vide), mais l'écran
  de configuration forçait jusqu'ici à toujours choisir une app précise — ce mode pourtant
  documenté était donc impossible à créer. Le choix "N'importe quelle application" apparaît
  maintenant explicitement à la configuration de ce bloc.

## Nouveau : automatisations fun et notifications silencieuses
- Le bloc **Envoyer une notification** propose désormais un choix **silencieuse / normale**
  à la configuration : en silencieux, la notification s'affiche sans aucun son ni vibration
  (pratique la nuit, en réunion, ou simplement pour rester discret).
- 6 nouveaux modèles prêts à l'emploi sont proposés dans **Suggestions**, tous déclenchés
  simplement (une secousse, un bouton, un branchement) et sans aucun bruit — seulement de la
  vibration, de la lumière (lampe torche) et des messages visuels :
  - 🎉 **Secousse party** — secoue le téléphone pour une petite fête silencieuse
  - 🔦 **SOS lumineux** — la lampe torche clignote un vrai SOS en morse, d'un bouton
  - 🥷 **Mode fantôme (22h-7h)** — bascule tout en silencieux chaque soir à 22h
  - ✨ **Danse de la batterie pleine** — flashs + vibration quand la charge est terminée
  - 🎧 **Casque branché = mode focus** — Ne pas déranger dès que les écouteurs sont branchés
  - 🎲 **Coup de dé du matin** — un message porte-bonheur aléatoire, silencieux, d'un bouton

## Design : de vrais blocs de chaîne
L'atelier de blocs affiche désormais de véritables pièces de puzzle qui s'emboîtent les unes
dans les autres (façon Scratch/Blockly), plutôt que des cartes reliées par un simple trait
décoratif :
- chaque bloc possède une **encoche** en haut (qui reçoit la languette du bloc précédent) et
  une **languette** en bas (qui s'emboîte dans le bloc suivant), dessinées dynamiquement ;
- les blocs se chevauchent exactement de la hauteur de cette languette, donnant un vrai effet
  d'emboîtement physique plutôt qu'un empilement de cartes espacées ;
- le bloc déclencheur est la "tête" de la chaîne (pas d'encoche en haut, une languette en bas) ;
- chaque catégorie de bloc garde sa couleur (violet = action, ambre = logique, bleu = connecteur,
  sarcelle = déclencheur/chaînage), désormais visible sur le contour du bloc lui-même.



## Savoir ce que prend chaque automatisation
Chaque automatisation affiche maintenant, sous son nom dans la liste principale, un résumé
des accès qu'elle consomme (SMS, position GPS, micro, contacts, calendrier, Internet...),
calculé automatiquement à partir de son déclencheur et de ses blocs actions. La liste est
aussi rangée : les automatisations actives d'abord, puis regroupées par type de déclencheur.

## Blocs connecteurs (services externes)
- **Requête HTTP générique** (GET/POST) — connecte BlockAuto à n'importe quelle API ou webhook
- **Webhook Discord** — poste un message dans un salon via son URL de webhook
- **Message Telegram** — envoie un message via un bot Telegram (token + chat ID)
- **Webhook Slack**
- **Webhook IFTTT** (Maker Webhooks)
- **Webhook Home Assistant** — déclenche une automatisation Home Assistant locale

Ces blocs peuvent utiliser les variables issues du bloc "Récupérer la position GPS"
(`{lat}`, `{lon}`, `{location}`) dans leurs champs de message/texte, ce qui permet par
exemple d'enchaîner "Position GPS" → "Webhook Discord" pour poster sa position.

Les actions d'une automatisation s'exécutent **dans l'ordre où tu les as ajoutées**.

## 1. Mettre le projet sur GitHub

```bash
cd BlockAuto
git init
git add .
git commit -m "BlockAuto - première version"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/BlockAuto.git
git push -u origin main
```

## 2. Récupérer l'APK compilé automatiquement

Dès que tu pousses sur `main`, l'onglet **Actions** de ton dépôt GitHub lance le workflow
`Build APK` qui compile le projet et génère un fichier APK, téléchargeable dans
**Actions → (dernière exécution) → Artifacts → BlockAuto-debug-apk**.

Pour obtenir une **Release** avec l'APK attaché directement en pièce jointe :
```bash
git tag v1.0
git push origin v1.0
```

## 3. Installer l'APK sur ton téléphone
1. Télécharge le fichier `.apk` depuis GitHub.
2. Transfère-le sur ton téléphone (câble, Drive, etc.).
3. Autorise "Installer des applications inconnues" pour l'app que tu utilises pour l'ouvrir.
4. Installe puis ouvre BlockAuto.

## 4. Autoriser l'app dans BlockAuto
Ouvre le bouton **Autorisations** en haut de l'écran principal et active, selon les blocs
que tu comptes utiliser :
- **Service d'accessibilité** → nécessaire pour "Application ouverte" et "Capture d'écran"
- **Accès aux notifications** → nécessaire pour "Notification reçue"
- **Modifier les réglages système** → nécessaire pour "Régler la luminosité" et "Rotation auto"
- **Afficher par-dessus les autres applications** → **essentiel**, demandé automatiquement au
  premier lancement : sans elle, Android bloque parfois l'ouverture d'une appli/URL/appel/partage
  quand l'automatisation se déclenche app totalement fermée (restriction système Android 10+)
- **Ignorer l'optimisation de batterie** → recommandé pour que les automatisations
  se déclenchent même app fermée
- **Accès à "Ne pas déranger"** → nécessaire pour le bloc "Ne pas déranger" (activer/désactiver)
- SMS, appels, contacts, calendrier, position GPS, micro et notifications classiques sont
  demandées automatiquement au premier lancement (permissions runtime Android).
- Les blocs connecteurs (HTTP, Discord, Telegram, Slack, IFTTT, Home Assistant) utilisent
  Internet, qui est une permission automatique : aucune fenêtre à valider.

## Limites à connaître
- Android moderne ne permet plus à une app normale (sans root) de couper le Wi-Fi/Bluetooth
  ou de passer en mode avion directement : les blocs correspondants ouvrent l'écran de
  réglages concerné plutôt que de basculer l'état eux-mêmes.
- Le bloc "Application ouverte" nécessite le service d'accessibilité activé manuellement
  (Android l'exige pour ce type de détection).
- Aucune donnée ne quitte le téléphone : tout est stocké localement dans l'app.

## Structure du projet
- `app/src/main/java/com/blockauto/app/model` — les blocs (déclencheurs/actions) et le modèle Automatisation
- `app/src/main/java/com/blockauto/app/builder` — l'écran d'assemblage des blocs
- `app/src/main/java/com/blockauto/app/engine` — exécution des actions + planification des alarmes
- `app/src/main/java/com/blockauto/app/receivers` / `services` — écoute des événements système
- `.github/workflows/build-apk.yml` — compilation automatique de l'APK sur GitHub
