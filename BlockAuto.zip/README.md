# BlockAuto V2

Version 2.0 du projet BlockAuto.

## Corrections principales
- moteur d'exécution sérialisé pour éviter les conflits entre automatisations simultanées ;
- chaînes A → B plus fiables et variables transmises ;
- erreurs d'actions visibles dans l'historique au lieu d'être masquées ;
- HTTP GET/POST/PUT/PATCH/DELETE avec code et réponse disponibles via `{http_code}` et `{http_body}` ;
- presse-papiers corrigé avec `ClipData` ;
- notifications refusées explicitement si la permission manque ;
- captures d'écran / accueil / récents / verrouillage signalent quand l'accessibilité n'est pas active ;
- alarmes exactes utilisées quand Android les autorise, sinon fallback sur une alarme inexacte ;
- déclencheurs d'intervalle reprogrammés après chaque exécution ;
- nom du projet et du ZIP conservés : `BlockAuto.zip`.

## Nouveautés de cette version
### Nouveaux déclencheurs
- Mode sombre activé / désactivé
- Économie d'énergie activée / désactivée
- Langue du téléphone changée
- Date ou heure changée manuellement
- Posé / retiré d'un dock ou support
- Mode avion désactivé (le mode "activé" existait déjà)
- Application mise à jour
- **Un texte apparaît à l'écran** (surveille le contenu d'une appli via l'accessibilité, dans une appli précise ou n'importe laquelle)

### Nouveaux blocs "Dans l'appli" (interaction avec d'autres applications)
Ces blocs utilisent le service d'accessibilité BlockAuto pour agir directement dans une autre application (à activer dans Réglages BlockAuto) :
- Cliquer sur un texte / appui long sur un texte
- Cliquer sur une icône via sa description d'accessibilité
- Écrire dans le champ de saisie actif
- Faire défiler vers le haut / le bas (ou balayer dans une direction précise via un vrai geste tactile)
- Bouton retour
- Attendre qu'un texte apparaisse (avec délai maximum)
- Ouvrir une application puis cliquer sur un texte (combine ouverture + clic)
- Nouvelle condition : "un texte est visible à l'écran"

## Limites Android
Certaines fonctions sont volontairement signalées comme indisponibles lorsqu'Android les interdit aux applications classiques (notamment activation/désactivation directe du Wi-Fi ou du Bluetooth sur les versions récentes). BlockAuto ne prétend pas contourner ces protections. De même, les blocs "Dans l'appli" ne peuvent cliquer que sur ce qui est réellement affiché à l'écran (texte ou description exacts) : ils ne peuvent pas deviner le contenu d'une application qui n'est pas ouverte, ni contourner une appli qui bloque volontairement l'accessibilité (ex : certaines apps bancaires).

