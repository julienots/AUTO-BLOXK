package com.blockauto.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.builder.AutomationBuilderActivity
import com.blockauto.app.databinding.ActivityMainBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AutomationAdapter

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerAutomations.layoutManager = LinearLayoutManager(this)
        adapter = AutomationAdapter(
            onClick = { automation ->
                val intent = Intent(this, AutomationBuilderActivity::class.java)
                intent.putExtra("automation_id", automation.id)
                startActivity(intent)
            },
            onToggle = { automation, enabled ->
                automation.enabled = enabled
                AutomationRepository.save(this, automation)
                TriggerScheduler.schedule(this, automation)
            },
            onRun = { automation ->
                AutomationExecutionService.start(this, automation.id)
                Snackbar.make(binding.root, "Exécution de « ${automation.name} »", Snackbar.LENGTH_SHORT).show()
            },
            onDelete = { automation ->
                AutomationRepository.delete(this, automation.id)
                TriggerScheduler.cancel(this, automation.id)
                refresh()
            }
        )
        binding.recyclerAutomations.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AutomationBuilderActivity::class.java))
        }

        binding.btnPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val list = AutomationRepository.getAll(this)
        adapter.submitList(list)
        binding.emptyState.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        perms.add(Manifest.permission.SEND_SMS)
        val toRequest = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) permLauncher.launch(toRequest.toTypedArray())
    }
}
