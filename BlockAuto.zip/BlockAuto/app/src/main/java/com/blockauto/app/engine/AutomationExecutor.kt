package com.blockauto.app.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Exécute, dans l'ordre, tous les blocs actions d'une automatisation. */
object AutomationExecutor {

    private const val CHANNEL_ID = "block_auto_channel"

    suspend fun run(context: Context, automation: Automation) {
        ensureChannel(context)
        for (action in automation.actions) {
            try {
                executeOne(context, action)
            } catch (e: Exception) {
                // On continue les blocs suivants même si l'un d'eux échoue
            }
        }
    }

    private suspend fun executeOne(context: Context, action: ActionBlock) {
        when (action.type) {
            ActionType.OPEN_APP -> {
                val pkg = action.params["package"] ?: return
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchIntent?.let { context.startActivity(it) }
            }

            ActionType.SEND_NOTIFICATION -> {
                val title = action.params["title"]?.ifBlank { "Automatisation" } ?: "Automatisation"
                val text = action.params["text"] ?: ""
                val notif = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), notif)
            }

            ActionType.SHOW_TOAST -> withContext(Dispatchers.Main) {
                Toast.makeText(context, action.params["text"] ?: "", Toast.LENGTH_LONG).show()
            }

            ActionType.VIBRATE -> {
                val ms = action.params["duration_ms"]?.toLongOrNull() ?: 500L
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }

            ActionType.SET_VOLUME -> {
                val level = action.params["level"]?.toIntOrNull() ?: 5
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0, max), 0)
            }

            ActionType.SET_BRIGHTNESS -> {
                if (Settings.System.canWrite(context)) {
                    val level = action.params["level"]?.toIntOrNull() ?: 128
                    Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0, 255))
                }
            }

            ActionType.TOGGLE_FLASHLIGHT -> {
                try {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val camId = cm.cameraIdList.firstOrNull()
                    val turnOn = action.params["state"] != "off"
                    if (camId != null) cm.setTorchMode(camId, turnOn)
                } catch (e: Exception) { /* pas de flash disponible */ }
            }

            ActionType.OPEN_URL -> {
                val url = action.params["url"] ?: return
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_WIFI_SETTINGS -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_BLUETOOTH_SETTINGS -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_DND_SETTINGS -> {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.SEND_SMS -> {
                val number = action.params["number"] ?: return
                val text = action.params["text"] ?: ""
                try {
                    val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                        context.getSystemService(SmsManager::class.java)
                    else @Suppress("DEPRECATION") SmsManager.getDefault()
                    sms?.sendTextMessage(number, null, text, null, null)
                } catch (e: Exception) { /* SMS non envoyé */ }
            }

            ActionType.WAIT -> {
                val sec = action.params["seconds"]?.toLongOrNull() ?: 1L
                delay(sec * 1000)
            }
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "BlockAuto", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }
}
