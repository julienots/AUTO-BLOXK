package com.blockauto.app.model

import java.util.UUID

/** Les blocs "déclencheur" disponibles dans la palette. */
enum class TriggerType(val label: String) {
    TIME("Heure précise"),
    BOOT_COMPLETED("Démarrage du téléphone"),
    BATTERY_LOW("Batterie faible"),
    BATTERY_FULL("Branché sur secteur"),
    APP_OPENED("Application ouverte"),
    NOTIFICATION_RECEIVED("Notification reçue"),
    MANUAL("Déclenchement manuel uniquement")
}

/** Les blocs "action" disponibles dans la palette. */
enum class ActionType(val label: String) {
    OPEN_APP("Ouvrir une application"),
    SEND_NOTIFICATION("Envoyer une notification"),
    SHOW_TOAST("Afficher un message"),
    VIBRATE("Faire vibrer"),
    SET_VOLUME("Régler le volume média"),
    SET_BRIGHTNESS("Régler la luminosité"),
    TOGGLE_FLASHLIGHT("Lampe torche"),
    OPEN_URL("Ouvrir un lien"),
    OPEN_WIFI_SETTINGS("Ouvrir réglages Wi-Fi"),
    OPEN_BLUETOOTH_SETTINGS("Ouvrir réglages Bluetooth"),
    OPEN_DND_SETTINGS("Ouvrir Ne pas déranger"),
    SEND_SMS("Envoyer un SMS"),
    WAIT("Attendre quelques secondes")
}

data class TriggerBlock(
    val type: TriggerType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class ActionBlock(
    val type: ActionType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class Automation(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var enabled: Boolean = true,
    var trigger: TriggerBlock? = null,
    var actions: MutableList<ActionBlock> = mutableListOf()
)
