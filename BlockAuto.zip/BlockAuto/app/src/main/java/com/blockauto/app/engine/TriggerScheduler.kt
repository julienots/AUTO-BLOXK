package com.blockauto.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerType
import com.blockauto.app.receivers.AlarmReceiver
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/** Programme / annule les alarmes système pour les déclencheurs de type "Heure précise". */
object TriggerScheduler {

    fun schedule(context: Context, automation: Automation) {
        cancel(context, automation.id)
        val trigger = automation.trigger ?: return
        if (!automation.enabled) return
        if (trigger.type == TriggerType.TIME) {
            val hour = trigger.params["hour"]?.toIntOrNull() ?: return
            val minute = trigger.params["minute"]?.toIntOrNull() ?: return
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
            }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("automation_id", automation.id)
            }
            val pi = PendingIntent.getBroadcast(
                context, automation.id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    fun cancel(context: Context, automationId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun scheduleAll(context: Context) {
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.TIME) schedule(context, a)
        }
    }
}
