package com.blockauto.app.builder

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.databinding.ActivityAutomationBuilderBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/**
 * Écran "atelier de blocs" : on choisit un bloc déclencheur, puis on empile
 * les blocs actions dans l'ordre voulu, exactement comme des briques qu'on assemble.
 */
class AutomationBuilderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAutomationBuilderBinding
    private lateinit var automation: Automation
    private lateinit var actionAdapter: ActionBlockAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAutomationBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra("automation_id")
        automation = if (id != null) AutomationRepository.get(this, id) ?: Automation() else Automation()

        binding.editName.setText(automation.name)

        binding.recyclerActions.layoutManager = LinearLayoutManager(this)
        actionAdapter = ActionBlockAdapter { position ->
            automation.actions.removeAt(position)
            actionAdapter.submitList(automation.actions)
        }
        binding.recyclerActions.adapter = actionAdapter
        actionAdapter.submitList(automation.actions)

        refreshTriggerLabel()

        binding.btnPickTrigger.setOnClickListener { showTriggerPicker() }
        binding.btnAddAction.setOnClickListener { showActionPicker() }

        binding.btnSave.setOnClickListener {
            automation.name = binding.editName.text.toString().ifBlank { "Automatisation" }
            if (automation.trigger == null) {
                Toast.makeText(this, "Choisis un bloc déclencheur", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (automation.actions.isEmpty()) {
                Toast.makeText(this, "Ajoute au moins un bloc action", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AutomationRepository.save(this, automation)
            TriggerScheduler.schedule(this, automation)
            finish()
        }

        binding.btnDelete.setOnClickListener {
            AutomationRepository.delete(this, automation.id)
            TriggerScheduler.cancel(this, automation.id)
            finish()
        }
        binding.btnDelete.visibility = if (id != null) View.VISIBLE else View.GONE
    }

    private fun refreshTriggerLabel() {
        binding.textCurrentTrigger.text = automation.trigger?.type?.label ?: "Aucun déclencheur choisi"
    }

    // ---- Choix du bloc déclencheur ----

    private fun showTriggerPicker() {
        val types = TriggerType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc déclencheur")
            .setItems(labels) { _, which -> configureTrigger(types[which]) }
            .show()
    }

    private fun configureTrigger(type: TriggerType) {
        when (type) {
            TriggerType.TIME -> {
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    automation.trigger = TriggerBlock(
                        type, mutableMapOf("hour" to hour.toString(), "minute" to minute.toString())
                    )
                    refreshTriggerLabel()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            TriggerType.APP_OPENED, TriggerType.NOTIFICATION_RECEIVED -> {
                showAppPicker { pkg ->
                    automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                    refreshTriggerLabel()
                }
            }
            else -> {
                automation.trigger = TriggerBlock(type)
                refreshTriggerLabel()
            }
        }
    }

    // ---- Choix des blocs actions ----

    private fun showActionPicker() {
        val types = ActionType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc action")
            .setItems(labels) { _, which -> configureAction(types[which]) }
            .show()
    }

    private fun configureAction(type: ActionType) {
        when (type) {
            ActionType.OPEN_APP -> showAppPicker { pkg ->
                addAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.SEND_NOTIFICATION -> showTextInputs(listOf("Titre" to "title", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SHOW_TOAST -> showTextInputs(listOf("Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.VIBRATE -> showTextInputs(listOf("Durée en millisecondes" to "duration_ms")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SET_VOLUME -> showTextInputs(listOf("Niveau (0 à 15)" to "level")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SET_BRIGHTNESS -> showTextInputs(listOf("Niveau (0 à 255)" to "level")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.TOGGLE_FLASHLIGHT -> {
                AlertDialog.Builder(this)
                    .setTitle("Lampe torche")
                    .setItems(arrayOf("Allumer", "Éteindre")) { _, which ->
                        addAction(ActionBlock(type, mutableMapOf("state" to if (which == 0) "on" else "off")))
                    }.show()
            }
            ActionType.OPEN_URL -> showTextInputs(listOf("URL (https://...)" to "url")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_SMS -> showTextInputs(listOf("Numéro" to "number", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.WAIT -> showTextInputs(listOf("Secondes" to "seconds")) {
                addAction(ActionBlock(type, it))
            }
            else -> addAction(ActionBlock(type))
        }
    }

    private fun addAction(block: ActionBlock) {
        automation.actions.add(block)
        actionAdapter.submitList(automation.actions)
    }

    // ---- Utilitaires de saisie ----

    private fun showTextInputs(fields: List<Pair<String, String>>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { (label, _) ->
            val edit = EditText(this)
            edit.hint = label
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                fields.forEachIndexed { index, (_, key) -> map[key] = editTexts[index].text.toString() }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showAppPicker(onPicked: (String) -> Unit) {
        val pm = packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir une application")
            .setItems(labels) { _, which -> onPicked(apps[which].activityInfo.packageName) }
            .show()
    }
}
