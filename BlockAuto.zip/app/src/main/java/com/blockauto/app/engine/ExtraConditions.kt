package com.blockauto.app.engine

import android.app.KeyguardManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.res.Configuration
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.storage.VariableStore
import java.util.Calendar

/** Évaluation des conditions ajoutées en version 3 (état du téléphone, texte, dates...). */
object ExtraConditions {

    fun evaluate(context: Context, action: ActionBlock, variables: Map<String, String>): Boolean = try {
        when (action.type) {
            ActionType.IF_CHARGING -> {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                bm.isCharging
            }
            ActionType.IF_SCREEN_ON -> (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
            ActionType.IF_DEVICE_LOCKED -> (context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
            ActionType.IF_HEADSET_CONNECTED -> isHeadsetConnected(context)
            ActionType.IF_MUSIC_PLAYING -> (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive
            ActionType.IF_RINGER_MODE -> {
                val mode = when ((context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode) {
                    AudioManager.RINGER_MODE_SILENT -> "silent"
                    AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
                    else -> "normal"
                }
                mode == (action.params["mode"] ?: "normal")
            }
            ActionType.IF_DARK_MODE ->
                (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            ActionType.IF_POWER_SAVE -> (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
            ActionType.IF_INTERNET -> hasInternet(context)
            ActionType.IF_MOBILE_DATA -> {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            }
            ActionType.IF_AIRPLANE_MODE ->
                Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
            ActionType.IF_BLUETOOTH_ON ->
                (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter?.isEnabled == true
            ActionType.IF_WEEKEND -> {
                val day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
                day == Calendar.SATURDAY || day == Calendar.SUNDAY
            }
            ActionType.IF_VARIABLE_CONTAINS -> {
                val value = readVariable(context, action.params["name"], variables)
                val needle = AutomationExecutor.subst(action.params["value"] ?: "", variables)
                needle.isNotEmpty() && value.contains(needle, ignoreCase = true)
            }
            ActionType.IF_VARIABLE_EMPTY -> readVariable(context, action.params["name"], variables).isBlank()
            ActionType.IF_DATE_IS -> {
                val now = Calendar.getInstance()
                now.get(Calendar.DAY_OF_MONTH) == (action.params["day"]?.toIntOrNull() ?: 1) &&
                    now.get(Calendar.MONTH) + 1 == (action.params["month"]?.toIntOrNull() ?: 1)
            }
            else -> true
        }
    } catch (e: SecurityException) {
        false
    }

    /** Lit une variable locale, puis à défaut la variable globale du même nom. */
    private fun readVariable(context: Context, rawName: String?, variables: Map<String, String>): String {
        val name = rawName?.trim().orEmpty()
        if (name.isEmpty()) return ""
        return variables[name] ?: VariableStore.get(context, name) ?: ""
    }

    fun hasInternet(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun isHeadsetConnected(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val headsetTypes = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_USB_HEADSET
        )
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in headsetTypes }
    }
}
