package com.blockauto.app.store

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import com.blockauto.app.R
import com.blockauto.app.databinding.ActivityStoreBinding
import com.blockauto.app.databinding.ItemStoreFeatureBinding
import com.google.android.material.snackbar.Snackbar

/**
 * Écran "Boutique" : liste les fonctionnalités premium, leur prix indicatif, et permet
 * de les débloquer via un code promo (voir [PremiumManager] pour le pourquoi de ce choix
 * plutôt qu'un vrai paiement intégré directement ici).
 */
class StoreActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStoreBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoreBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        renderFeatures()

        binding.btnRedeemPromo.setOnClickListener {
            val code = binding.inputPromoCode.text?.toString().orEmpty()
            if (code.isBlank()) return@setOnClickListener
            when (val result = PremiumManager.redeemPromoCode(this, code)) {
                is PremiumManager.RedeemResult.Success -> {
                    Snackbar.make(binding.root, getString(R.string.store_promo_success, result.feature.displayName), Snackbar.LENGTH_LONG).show()
                    binding.inputPromoCode.text?.clear()
                    renderFeatures()
                }
                PremiumManager.RedeemResult.Invalid ->
                    Snackbar.make(binding.root, R.string.store_promo_invalid, Snackbar.LENGTH_LONG).show()
            }
        }

        if (PremiumManager.isDevUnlockAvailable()) {
            binding.devUnlockContainer.visibility = android.view.View.VISIBLE
            binding.switchDevUnlock.isChecked = PremiumManager.isDevUnlockAllEnabled(this)
            binding.switchDevUnlock.setOnCheckedChangeListener { _, checked ->
                PremiumManager.setDevUnlockAll(this, checked)
                renderFeatures()
            }
        }
    }

    private fun renderFeatures() {
        binding.storeFeatureContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        PremiumManager.FeatureId.values().forEach { feature ->
            val itemBinding = ItemStoreFeatureBinding.inflate(inflater, binding.storeFeatureContainer, false)
            itemBinding.featureName.text = feature.displayName
            itemBinding.featureDescription.text = feature.description
            val unlocked = PremiumManager.isUnlocked(this, feature)
            if (unlocked) {
                itemBinding.featureBadge.text = getString(R.string.store_badge_unlocked)
                itemBinding.featureBuyButton.visibility = android.view.View.GONE
            } else {
                itemBinding.featureBadge.text = getString(R.string.store_badge_locked)
                itemBinding.featureBuyButton.visibility = android.view.View.VISIBLE
                itemBinding.featureBuyButton.text = getString(R.string.store_buy_button, feature.priceLabel)
                itemBinding.featureBuyButton.setOnClickListener {
                    // Aucune vraie facturation n'est branchée ici (voir PremiumManager) :
                    // on l'indique clairement plutôt que de simuler un achat silencieux.
                    Snackbar.make(binding.root, R.string.store_billing_not_connected, Snackbar.LENGTH_LONG).show()
                }
            }
            binding.storeFeatureContainer.addView(itemBinding.root)
        }
    }
}
