package com.blockauto.app.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.blockauto.app.R

/**
 * Petites fonctions de mise en forme partagées par toutes les listes de l'app
 * (automatisations, blocs d'action, historique...) : logo rond coloré par
 * catégorie, barre d'accent, puce de catégorie. Centralisé ici pour que toute
 * l'appli garde un langage visuel cohérent, façon "palette de blocs" Scratch.
 */
object BadgeStyle {

    /** Applique un logo rond façon "sticker" (disque + reflet) teinté [color] sur [target]. */
    fun applyLogo(target: TextView, color: Int) {
        val bg = ContextCompat.getDrawable(target.context, R.drawable.bg_badge_logo)
            ?.mutate() as? LayerDrawable
        val circle = bg?.findDrawableByLayerId(R.id.badge_circle_layer) as? GradientDrawable
        circle?.setColor(color)
        target.background = bg
    }

    /** Teinte une barre d'accent verticale (bord coloré des cartes de liste). */
    fun applyAccentBar(bar: View, color: Int) {
        bar.backgroundTintList = ColorStateList.valueOf(color)
    }

    /** Prépare une puce de catégorie : fond très légèrement teinté + texte de la couleur pleine. */
    fun applyCategoryChip(chip: TextView, color: Int, label: String) {
        chip.text = label
        chip.setTextColor(color)
        val bg = ContextCompat.getDrawable(chip.context, R.drawable.bg_chip_category)
            ?.mutate() as? GradientDrawable
        bg?.setColor(withAlpha(color, 0x33))
        chip.background = bg
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}
