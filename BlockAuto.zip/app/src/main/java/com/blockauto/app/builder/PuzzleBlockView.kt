package com.blockauto.app.builder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.widget.FrameLayout

/**
 * Dessine un vrai bloc de chaîne d'automatisation, façon pièce de puzzle qui
 * s'emboîte dans la suivante (comme Scratch/Blockly) plutôt qu'une simple carte
 * reliée par un trait décoratif :
 *  - une "languette" (bosse) qui dépasse en bas du bloc, sur laquelle vient
 *    s'emboîter le bloc suivant,
 *  - une "encoche" (creux) en haut du bloc, dans laquelle vient se loger la
 *    languette du bloc précédent.
 * Les deux formes ont exactement le même rayon : combinées à un léger
 * chevauchement vertical entre les blocs (voir ChainConnectorDecoration), la
 * languette de l'un se glisse visuellement dans l'encoche de l'autre, donnant
 * un vrai effet de chaîne physique plutôt qu'un simple empilement de cartes.
 */
class PuzzleBlockView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** Rayon de la languette/encoche, en pixels (calculé une fois depuis la densité). */
    val knobRadiusPx = KNOB_RADIUS_DP * resources.displayMetrics.density
    private val cornerRadiusPx = 18f * resources.displayMetrics.density
    private val strokeWidthPx = 2.5f * resources.displayMetrics.density

    var hasTopNotch: Boolean = true
        set(value) { field = value; updateInsets(); rebuildPath(width.toFloat(), height.toFloat()); requestLayout(); invalidate() }
    var hasBottomTab: Boolean = true
        set(value) { field = value; updateInsets(); rebuildPath(width.toFloat(), height.toFloat()); requestLayout(); invalidate() }

    /** Couleur d'accent de la catégorie du bloc (déclencheur / action / logique / connecteur / chaîne). */
    var accentColor: Int = Color.parseColor("#7C5CFC")
        set(value) { field = value; invalidate() }

    private var fillColor: Int = Color.parseColor("#242B4A")

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
    }
    private val path = Path()

    init {
        setWillNotDraw(false)
        updateInsets()
    }

    /**
     * Espace réservé en haut/bas pour laisser respirer l'encoche et la languette sans
     * qu'elles ne rognent le contenu (texte, icônes) posé à l'intérieur du bloc.
     * BUG CORRIGÉ : ce calcul se faisait uniquement une fois dans le bloc `init`, avant
     * même que l'écran d'assemblage n'ait la chance de mettre `hasTopNotch`/`hasBottomTab`
     * à jour (ex: le bloc déclencheur retire son encoche du haut après construction) — le
     * padding restait alors basé sur les valeurs par défaut et le contenu se retrouvait
     * mal centré ou légèrement rogné par la forme réellement dessinée. On recalcule donc
     * le padding à chaque changement de ces deux propriétés, pas seulement à la création.
     */
    private fun updateInsets() {
        val topInset = if (hasTopNotch) (knobRadiusPx * 1.6f).toInt() else (10f * resources.displayMetrics.density).toInt()
        val bottomInset = if (hasBottomTab) (knobRadiusPx * 1.6f).toInt() else (10f * resources.displayMetrics.density).toInt()
        setPadding(paddingLeft, topInset, paddingRight, bottomInset)
    }

    fun setColors(accent: Int, fill: Int) {
        accentColor = accent
        fillColor = fill
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildPath(w.toFloat(), h.toFloat())
    }

    private fun rebuildPath(w: Float, h: Float) {
        path.reset()
        if (w <= 0f || h <= 0f) return

        val topEdge = if (hasTopNotch) knobRadiusPx * 1.1f else 0f
        val bottomEdge = h - (if (hasBottomTab) knobRadiusPx * 1.1f else 0f)
        val knobCenterX = w / 2f

        val body = Path().apply {
            addRoundRect(
                RectF(0f, topEdge, w, bottomEdge),
                cornerRadiusPx, cornerRadiusPx, Path.Direction.CW
            )
        }

        if (hasTopNotch) {
            val notch = Path().apply {
                addCircle(knobCenterX, topEdge, knobRadiusPx, Path.Direction.CW)
            }
            body.op(body, notch, Path.Op.DIFFERENCE)
        }
        if (hasBottomTab) {
            val tab = Path().apply {
                addCircle(knobCenterX, bottomEdge, knobRadiusPx, Path.Direction.CW)
            }
            body.op(body, tab, Path.Op.UNION)
        }
        path.set(body)
    }

    override fun onDraw(canvas: Canvas) {
        fillPaint.color = fillColor
        strokePaint.color = accentColor
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
        super.onDraw(canvas)
    }

    companion object {
        /** Rayon (en dp) de la languette/encoche — partagé avec [ChainConnectorDecoration]
         *  pour que le chevauchement entre deux blocs corresponde toujours exactement à la
         *  forme réellement dessinée, même si cette valeur est modifiée un jour. */
        const val KNOB_RADIUS_DP = 11f
    }
}
