package com.blockauto.app.model

/**
 * Catalogue déclaratif des blocs ajoutés en version 3.
 *
 * Plutôt que d'écrire à la main, pour chaque nouveau bloc, une boîte de dialogue dans
 * l'atelier, une icône dans un grand `when` et une ligne dans le catalogue des accès, chaque
 * bloc est décrit UNE fois ici : son icône, sa catégorie dans la palette, les réglages à
 * demander (texte, nombre, choix, application) et l'accès système qu'il consomme.
 * L'atelier construit le formulaire automatiquement à partir de [BlockField].
 */
sealed class BlockField(val key: String, val label: String) {
    /** Champ texte libre (accepte les variables {nom}). */
    class Text(key: String, label: String, val default: String = "", val multiline: Boolean = false) :
        BlockField(key, label)

    /** Champ numérique borné. */
    class Number(key: String, label: String, val default: Long, val min: Long, val max: Long) :
        BlockField(key, label)

    /** Choix dans une liste : paires (libellé affiché, valeur enregistrée). */
    class Choice(key: String, label: String, val options: List<Pair<String, String>>) :
        BlockField(key, label)

    /** Choix d'une application installée (enregistre le nom de package). */
    class App(key: String, label: String) : BlockField(key, label)
}

class TriggerMeta(
    val icon: String,
    val category: TriggerCategory,
    val fields: List<BlockField> = emptyList(),
    val requirement: String? = null,
    val help: String? = null
)

class ActionMeta(
    val icon: String,
    val category: ActionCategory,
    val fields: List<BlockField> = emptyList(),
    val requirement: String? = null,
    val help: String? = null
)

private const val ACCESSIBILITY = "Service d'accessibilité"
private const val INTERNET = "Internet"
private const val WRITE_SETTINGS = "Modifier les réglages système"

private val ON_OFF = listOf("Activer" to "on", "Désactiver" to "off")
private val YES_NO = listOf("Oui" to "true", "Non" to "false")
private val STREAMS = listOf(
    "🎵 Médias" to "music", "🔔 Sonnerie" to "ring",
    "💬 Notifications" to "notification", "⏰ Alarme" to "alarm"
)

private fun hourField(default: Long = 8) = BlockField.Number("hour", "Heure", default, 0, 23)
private fun minuteField(default: Long = 0) = BlockField.Number("minute", "Minute", default, 0, 59)
private fun resultField(default: String) = BlockField.Text("result_name", "Nom de la variable résultat", default)

// ============================================================================
// Déclencheurs
// ============================================================================

val EXTRA_TRIGGER_META: Map<TriggerType, TriggerMeta> = mapOf(
    TriggerType.BATTERY_CHARGED_FULL to TriggerMeta("💯", TriggerCategory.BATTERIE,
        help = "Se déclenche quand la batterie atteint 100 % pendant la charge."),
    TriggerType.BATTERY_TEMP_HIGH to TriggerMeta("🌡️", TriggerCategory.BATTERIE,
        listOf(BlockField.Number("threshold", "Température maximale (°C)", 42, 30, 60)),
        help = "Prévient quand la batterie chauffe au-delà du seuil choisi."),
    TriggerType.CHARGING_WIRELESS to TriggerMeta("🪄", TriggerCategory.BATTERIE),

    TriggerType.MOBILE_DATA_CONNECTED to TriggerMeta("📡", TriggerCategory.RESEAU),
    TriggerType.MOBILE_DATA_DISCONNECTED to TriggerMeta("📵", TriggerCategory.RESEAU),
    TriggerType.INTERNET_LOST to TriggerMeta("🚫", TriggerCategory.RESEAU),
    TriggerType.INTERNET_RESTORED to TriggerMeta("🌐", TriggerCategory.RESEAU),
    TriggerType.BLUETOOTH_DISCONNECTED to TriggerMeta("🔹", TriggerCategory.RESEAU, requirement = "Bluetooth"),
    TriggerType.BLUETOOTH_TURNED_ON to TriggerMeta("🟦", TriggerCategory.RESEAU, requirement = "Bluetooth"),
    TriggerType.BLUETOOTH_TURNED_OFF to TriggerMeta("⬜", TriggerCategory.RESEAU, requirement = "Bluetooth"),
    TriggerType.WIFI_TURNED_ON to TriggerMeta("📶", TriggerCategory.RESEAU),
    TriggerType.WIFI_TURNED_OFF to TriggerMeta("📴", TriggerCategory.RESEAU),

    TriggerType.VOLUME_CHANGED to TriggerMeta("🔉", TriggerCategory.APPAREIL),
    TriggerType.PHONE_FACE_DOWN to TriggerMeta("🙃", TriggerCategory.APPAREIL,
        help = "Pose le téléphone écran contre la table (ex : passer en silencieux)."),
    TriggerType.PHONE_FACE_UP to TriggerMeta("🙂", TriggerCategory.APPAREIL),
    TriggerType.PROXIMITY_NEAR to TriggerMeta("👋", TriggerCategory.APPAREIL,
        help = "Passe la main au-dessus du haut de l'écran pour déclencher, sans toucher."),
    TriggerType.UNLOCK_COUNT_REACHED to TriggerMeta("🔢", TriggerCategory.APPAREIL,
        listOf(BlockField.Number("count", "Nombre de déverrouillages", 50, 1, 500)),
        help = "Idéal pour se rendre compte qu'on regarde trop son téléphone."),

    TriggerType.SUNRISE to TriggerMeta("🌅", TriggerCategory.TEMPS, listOf(
        BlockField.Text("lat", "Latitude (ex : 48.8566)", "48.8566"),
        BlockField.Text("lon", "Longitude (ex : 2.3522)", "2.3522"),
        BlockField.Number("offset", "Décalage en minutes (− avant, + après)", 0, -180, 180)
    )),
    TriggerType.SUNSET to TriggerMeta("🌇", TriggerCategory.TEMPS, listOf(
        BlockField.Text("lat", "Latitude (ex : 48.8566)", "48.8566"),
        BlockField.Text("lon", "Longitude (ex : 2.3522)", "2.3522"),
        BlockField.Number("offset", "Décalage en minutes (− avant, + après)", 0, -180, 180)
    )),
    TriggerType.MULTI_TIMES_DAILY to TriggerMeta("🕰️", TriggerCategory.TEMPS, listOf(
        BlockField.Text("times", "Heures séparées par des virgules", "08:00, 12:30, 19:00")
    )),
    TriggerType.HOURLY_CHIME to TriggerMeta("🔔", TriggerCategory.TEMPS, listOf(
        BlockField.Number("start_hour", "À partir de (heure)", 8, 0, 23),
        BlockField.Number("end_hour", "Jusqu'à (heure)", 22, 0, 23)
    )),
    TriggerType.LAST_DAY_OF_MONTH to TriggerMeta("🗓️", TriggerCategory.TEMPS,
        listOf(hourField(9), minuteField())),

    TriggerType.SMS_CONTAINS_TEXT to TriggerMeta("💬", TriggerCategory.COMMUNICATION,
        listOf(BlockField.Text("keyword", "Mot-clé à chercher dans le SMS")), requirement = "SMS",
        help = "Le texte du SMS est disponible dans {sms_body}, l'expéditeur dans {sms_sender} et un éventuel code dans {sms_code}."),
    TriggerType.MISSED_CALL to TriggerMeta("☎️", TriggerCategory.COMMUNICATION, requirement = "État du téléphone")
)

// ============================================================================
// Actions, conditions, connecteurs
// ============================================================================

val EXTRA_ACTION_META: Map<ActionType, ActionMeta> = mapOf(
    // --- Musique & son ---
    ActionType.MEDIA_NEXT to ActionMeta("⏭️", ActionCategory.MUSIQUE),
    ActionType.MEDIA_PREVIOUS to ActionMeta("⏮️", ActionCategory.MUSIQUE),
    ActionType.MEDIA_PAUSE to ActionMeta("⏸️", ActionCategory.MUSIQUE),
    ActionType.MEDIA_PLAY to ActionMeta("▶️", ActionCategory.MUSIQUE),
    ActionType.MEDIA_STOP to ActionMeta("⏹️", ActionCategory.MUSIQUE),
    ActionType.VOLUME_UP to ActionMeta("🔊", ActionCategory.MUSIQUE,
        listOf(BlockField.Choice("stream", "Quel volume ?", STREAMS))),
    ActionType.VOLUME_DOWN to ActionMeta("🔉", ActionCategory.MUSIQUE,
        listOf(BlockField.Choice("stream", "Quel volume ?", STREAMS))),
    ActionType.MUTE_MEDIA to ActionMeta("🔇", ActionCategory.MUSIQUE,
        listOf(BlockField.Choice("state", "Son des médias", listOf("Couper le son" to "on", "Remettre le son" to "off")))),
    ActionType.SET_NOTIFICATION_VOLUME to ActionMeta("🔔", ActionCategory.MUSIQUE,
        listOf(BlockField.Number("level", "Niveau", 5, 0, 15))),
    ActionType.SET_CALL_VOLUME to ActionMeta("📞", ActionCategory.MUSIQUE,
        listOf(BlockField.Number("level", "Niveau", 5, 1, 15))),
    ActionType.PLAY_RINGTONE to ActionMeta("📢", ActionCategory.MUSIQUE, listOf(
        BlockField.Number("seconds", "Durée (secondes)", 10, 1, 60),
        BlockField.Choice("sound", "Quel son ?", listOf(
            "🔔 Sonnerie" to "ringtone", "⏰ Alarme" to "alarm", "💬 Notification" to "notification"
        ))
    ), help = "Joue au volume maximum : pratique combiné au déclencheur « SMS contenant un mot-clé » pour retrouver un téléphone perdu."),
    ActionType.PLAY_MELODY to ActionMeta("🎼", ActionCategory.MUSIQUE, listOf(
        BlockField.Choice("melody", "Quelle mélodie ?", listOf(
            "🏆 Victoire" to "victory", "🚨 Alerte" to "alert", "🚪 Sonnette" to "doorbell",
            "📈 Gamme montante" to "rise", "📉 Gamme descendante" to "fall", "☎️ Vieux téléphone" to "phone"
        ))
    )),
    ActionType.PLAY_MEDIA_SEARCH to ActionMeta("🎶", ActionCategory.MUSIQUE,
        listOf(BlockField.Text("query", "Artiste, titre ou album"))),
    ActionType.SPEAK_TIME to ActionMeta("🕐", ActionCategory.MUSIQUE),
    ActionType.SPEAK_BATTERY to ActionMeta("🔋", ActionCategory.MUSIQUE),
    ActionType.SPEAK_SUMMARY to ActionMeta("🎙️", ActionCategory.MUSIQUE,
        listOf(BlockField.Text("name", "Ton prénom (facultatif)"))),

    // --- Système ---
    ActionType.FLASHLIGHT_BLINK to ActionMeta("💡", ActionCategory.SYSTEME, listOf(
        BlockField.Number("count", "Nombre de clignotements", 5, 1, 50),
        BlockField.Number("interval_ms", "Vitesse (ms entre deux flashs)", 250, 50, 2000)
    ), requirement = "Caméra (flash)"),
    ActionType.FLASHLIGHT_SOS to ActionMeta("🆘", ActionCategory.SYSTEME, requirement = "Caméra (flash)"),
    ActionType.SET_AUTO_BRIGHTNESS to ActionMeta("🌗", ActionCategory.SYSTEME,
        listOf(BlockField.Choice("state", "Luminosité automatique", ON_OFF)), requirement = WRITE_SETTINGS),
    ActionType.OPEN_SETTINGS_PAGE to ActionMeta("⚙️", ActionCategory.SYSTEME, listOf(
        BlockField.Choice("page", "Quelle page ?", listOf(
            "🔋 Batterie" to "battery", "🖥️ Affichage" to "display", "🔊 Son" to "sound",
            "📍 Localisation" to "location", "📶 Données mobiles" to "data", "🏷️ NFC" to "nfc",
            "📱 Applications" to "apps", "🕐 Date et heure" to "date", "♿ Accessibilité" to "accessibility",
            "💾 Stockage" to "storage", "🔐 Sécurité" to "security", "🌐 Langue" to "locale",
            "✈️ Mode avion" to "airplane", "ℹ️ À propos du téléphone" to "about"
        ))
    )),
    ActionType.OPEN_NOTIFICATION_SHADE to ActionMeta("🔽", ActionCategory.SYSTEME, requirement = ACCESSIBILITY),
    ActionType.OPEN_QUICK_SETTINGS to ActionMeta("🎛️", ActionCategory.SYSTEME, requirement = ACCESSIBILITY),
    ActionType.OPEN_POWER_MENU to ActionMeta("⏻", ActionCategory.SYSTEME, requirement = ACCESSIBILITY),
    ActionType.TOGGLE_SPLIT_SCREEN to ActionMeta("🪟", ActionCategory.SYSTEME, requirement = ACCESSIBILITY),
    ActionType.CLEAR_BLOCKAUTO_NOTIFICATIONS to ActionMeta("🧽", ActionCategory.SYSTEME),

    // --- Communication ---
    ActionType.SEND_BIG_NOTIFICATION to ActionMeta("📰", ActionCategory.COMMUNICATION, listOf(
        BlockField.Text("title", "Titre", "BlockAuto"),
        BlockField.Text("text", "Texte long (plusieurs lignes possibles)", multiline = true)
    )),
    ActionType.SEND_NOTIFICATION_WITH_LINK to ActionMeta("🔗", ActionCategory.COMMUNICATION, listOf(
        BlockField.Text("title", "Titre", "BlockAuto"),
        BlockField.Text("text", "Message"),
        BlockField.Text("url", "Lien à ouvrir au toucher (https://...)", "https://")
    )),
    ActionType.WHATSAPP_PREFILL to ActionMeta("🟢", ActionCategory.COMMUNICATION, listOf(
        BlockField.Text("number", "Numéro au format international (ex : 33612345678)"),
        BlockField.Text("text", "Message pré-rempli", multiline = true)
    ), help = "Ouvre la conversation avec le message déjà écrit : il ne reste qu'à appuyer sur Envoyer."),
    ActionType.SMS_COMPOSE to ActionMeta("✍️", ActionCategory.COMMUNICATION, listOf(
        BlockField.Text("number", "Numéro"),
        BlockField.Text("text", "Message pré-rempli", multiline = true)
    )),
    ActionType.OPEN_DIALER to ActionMeta("☎️", ActionCategory.COMMUNICATION,
        listOf(BlockField.Text("number", "Numéro à composer"))),

    // --- Web & navigation ---
    ActionType.OPEN_MAPS_NAVIGATION to ActionMeta("🧭", ActionCategory.NAVIGATION, listOf(
        BlockField.Text("destination", "Destination (adresse ou lieu)"),
        BlockField.Choice("mode", "Moyen de transport", listOf(
            "🚗 Voiture" to "d", "🚶 À pied" to "w", "🚲 Vélo" to "b", "🚌 Transports" to "transit"
        ))
    )),
    ActionType.OPEN_MAPS_SEARCH to ActionMeta("🗺️", ActionCategory.NAVIGATION,
        listOf(BlockField.Text("query", "Lieu à chercher (ex : boulangerie)"))),
    ActionType.WEB_SEARCH to ActionMeta("🔎", ActionCategory.NAVIGATION,
        listOf(BlockField.Text("query", "Recherche"))),
    ActionType.YOUTUBE_SEARCH to ActionMeta("📺", ActionCategory.NAVIGATION,
        listOf(BlockField.Text("query", "Vidéo à chercher"))),
    ActionType.OPEN_PLAY_STORE to ActionMeta("🛍️", ActionCategory.NAVIGATION,
        listOf(BlockField.App("package", "Application"))),
    ActionType.WIKIPEDIA_SUMMARY to ActionMeta("📚", ActionCategory.NAVIGATION, listOf(
        BlockField.Text("subject", "Sujet (ex : Tour Eiffel)"),
        resultField("wiki")
    ), requirement = INTERNET),

    // --- Infos & capteurs ---
    ActionType.GET_BATTERY_INFO to ActionMeta("🔋", ActionCategory.INFOS,
        help = "Remplit {batterie}, {batterie_temp}, {en_charge} et {batterie_sante}."),
    ActionType.GET_DEVICE_INFO to ActionMeta("📱", ActionCategory.INFOS,
        help = "Remplit {appareil}, {android}, {stockage_libre_go} et {ram_libre_mo}."),
    ActionType.GET_DATE_TIME to ActionMeta("📅", ActionCategory.INFOS,
        listOf(BlockField.Text("format", "Format personnalisé (facultatif, ex : dd/MM/yyyy HH:mm)")),
        help = "Remplit {date}, {heure}, {jour}, {mois}, {annee}, {semaine} et {date_perso}."),
    ActionType.GET_NETWORK_INFO to ActionMeta("📶", ActionCategory.INFOS,
        help = "Remplit {reseau} (wifi / mobile / aucun) et {internet} (oui / non)."),
    ActionType.GET_CLIPBOARD to ActionMeta("📋", ActionCategory.INFOS, listOf(resultField("presse_papiers"))),
    ActionType.GET_PUBLIC_IP to ActionMeta("🌍", ActionCategory.INFOS, listOf(resultField("ip")), requirement = INTERNET),
    ActionType.GET_CRYPTO_PRICE to ActionMeta("🪙", ActionCategory.INFOS, listOf(
        BlockField.Text("coin", "Identifiant de la crypto (ex : bitcoin, ethereum)", "bitcoin"),
        BlockField.Choice("currency", "Devise", listOf("€ Euro" to "eur", "$ Dollar" to "usd")),
        resultField("crypto")
    ), requirement = INTERNET),
    ActionType.GET_EXCHANGE_RATE to ActionMeta("💱", ActionCategory.INFOS, listOf(
        BlockField.Text("from", "Devise de départ (ex : EUR)", "EUR"),
        BlockField.Text("to", "Devise d'arrivée (ex : USD)", "USD"),
        resultField("taux")
    ), requirement = INTERNET),
    ActionType.GET_LIGHT_LEVEL to ActionMeta("☀️", ActionCategory.INFOS, listOf(resultField("lumiere")),
        help = "Valeur en lux : moins de 10 = pénombre, plus de 1000 = plein jour."),
    ActionType.COUNT_DAYS_UNTIL to ActionMeta("⏳", ActionCategory.INFOS, listOf(
        BlockField.Number("day", "Jour", 25, 1, 31),
        BlockField.Number("month", "Mois", 12, 1, 12),
        resultField("jours_restants")
    )),

    // --- Texte & fichiers ---
    ActionType.TEXT_TRANSFORM to ActionMeta("🔤", ActionCategory.TEXTE, listOf(
        BlockField.Text("input", "Texte d'origine (ou {variable})"),
        BlockField.Choice("mode", "Transformation", listOf(
            "ABC Majuscules" to "upper", "abc Minuscules" to "lower", "Abc Première lettre en majuscule" to "capitalize",
            "↔️ Inverser" to "reverse", "✂️ Retirer les espaces en trop" to "trim", "🔢 Compter les caractères" to "length",
            "🔣 Compter les mots" to "words"
        )),
        resultField("texte")
    )),
    ActionType.TEXT_REPLACE to ActionMeta("🔁", ActionCategory.TEXTE, listOf(
        BlockField.Text("input", "Texte d'origine (ou {variable})"),
        BlockField.Text("search", "Rechercher"),
        BlockField.Text("replace", "Remplacer par"),
        resultField("texte")
    )),
    ActionType.TEXT_EXTRACT_REGEX to ActionMeta("🧲", ActionCategory.TEXTE, listOf(
        BlockField.Text("input", "Texte d'origine (ou {variable})"),
        BlockField.Text("pattern", "Expression régulière (le 1er groupe est gardé s'il existe)"),
        resultField("extrait")
    )),
    ActionType.EXTRACT_CODE to ActionMeta("🔑", ActionCategory.TEXTE, listOf(
        BlockField.Text("input", "Texte où chercher le code", "{sms_body}"),
        resultField("code")
    ), help = "Trouve un code de 4 à 8 chiffres (SMS de validation, 2FA...)."),
    ActionType.ROUND_NUMBER to ActionMeta("🔘", ActionCategory.TEXTE, listOf(
        BlockField.Text("input", "Nombre (ou {variable})"),
        BlockField.Number("decimals", "Chiffres après la virgule", 0, 0, 6),
        resultField("arrondi")
    )),
    ActionType.DELETE_GLOBAL_VARIABLE to ActionMeta("🗑️", ActionCategory.TEXTE,
        listOf(BlockField.Text("name", "Nom de la variable globale"))),
    ActionType.LIST_RANDOM_ITEM to ActionMeta("🎲", ActionCategory.TEXTE, listOf(
        BlockField.Text("name", "Nom de la liste", "liste"),
        resultField("element")
    )),
    ActionType.FILE_APPEND_LINE to ActionMeta("📒", ActionCategory.TEXTE, listOf(
        BlockField.Text("file", "Nom du fichier", "journal.txt"),
        BlockField.Text("text", "Ligne à ajouter"),
        BlockField.Choice("timestamp", "Ajouter la date et l'heure devant ?", YES_NO)
    ), help = "Fichiers rangés dans Android/data/com.blockauto.app/files/Documents."),
    ActionType.FILE_WRITE to ActionMeta("📝", ActionCategory.TEXTE, listOf(
        BlockField.Text("file", "Nom du fichier", "note.txt"),
        BlockField.Text("text", "Contenu", multiline = true)
    )),
    ActionType.FILE_READ to ActionMeta("📖", ActionCategory.TEXTE, listOf(
        BlockField.Text("file", "Nom du fichier", "note.txt"),
        resultField("contenu")
    )),

    // --- Connecteurs ---
    ActionType.TEAMS_WEBHOOK to ActionMeta("🟪", ActionCategory.CONNECTEURS, listOf(
        BlockField.Text("url", "URL du webhook Teams"),
        BlockField.Text("text", "Message")
    ), requirement = INTERNET),
    ActionType.GOTIFY_NOTIFICATION to ActionMeta("📯", ActionCategory.CONNECTEURS, listOf(
        BlockField.Text("server", "Adresse du serveur (https://...)"),
        BlockField.Text("token", "Jeton d'application"),
        BlockField.Text("title", "Titre", "BlockAuto"),
        BlockField.Text("message", "Message")
    ), requirement = INTERNET),
    ActionType.MASTODON_POST to ActionMeta("🐘", ActionCategory.CONNECTEURS, listOf(
        BlockField.Text("instance", "Instance (ex : https://mastodon.social)", "https://mastodon.social"),
        BlockField.Text("token", "Jeton d'accès"),
        BlockField.Text("text", "Message à publier", multiline = true)
    ), requirement = INTERNET),
    ActionType.WEBHOOK_JSON to ActionMeta("🧾", ActionCategory.CONNECTEURS, listOf(
        BlockField.Text("url", "URL"),
        BlockField.Text("body", "Corps JSON (ex : {\"temp\": \"{meteo_temp_c}\"})", multiline = true)
    ), requirement = INTERNET),

    // --- Fun & surprises ---
    ActionType.ROLL_DICE to ActionMeta("🎲", ActionCategory.FUN, listOf(
        BlockField.Number("faces", "Nombre de faces", 6, 2, 100),
        BlockField.Text("name", "Variable pour le résultat", "de")
    )),
    ActionType.MAGIC_8_BALL to ActionMeta("🎱", ActionCategory.FUN),
    ActionType.RANDOM_COMPLIMENT to ActionMeta("💖", ActionCategory.FUN),
    ActionType.RANDOM_QUOTE to ActionMeta("💡", ActionCategory.FUN),
    ActionType.RANDOM_FACT to ActionMeta("🧠", ActionCategory.FUN),
    ActionType.RANDOM_WALLPAPER_COLOR to ActionMeta("🌈", ActionCategory.FUN, requirement = "Modifier le fond d'écran"),
    ActionType.GRADIENT_WALLPAPER to ActionMeta("🌅", ActionCategory.FUN, listOf(
        BlockField.Choice("preset", "Quel dégradé ?", listOf(
            "🌅 Coucher de soleil" to "sunset", "🌊 Océan" to "ocean", "🌌 Aurore boréale" to "aurora",
            "🍑 Pêche" to "peach", "🌃 Nuit" to "night", "🍀 Forêt" to "forest", "🎲 Au hasard" to "random"
        ))
    ), requirement = "Modifier le fond d'écran"),
    ActionType.DISCO_MODE to ActionMeta("🪩", ActionCategory.FUN,
        listOf(BlockField.Number("seconds", "Durée (secondes)", 8, 3, 30)), requirement = "Caméra (flash)"),
    ActionType.RANDOM_PASSWORD to ActionMeta("🔐", ActionCategory.FUN, listOf(
        BlockField.Number("length", "Longueur", 16, 6, 64),
        BlockField.Choice("copy", "Copier dans le presse-papiers ?", YES_NO)
    )),
    ActionType.BREATHING_EXERCISE to ActionMeta("🧘", ActionCategory.FUN,
        listOf(BlockField.Number("cycles", "Nombre de respirations", 4, 1, 10)),
        help = "Inspire pendant la vibration longue, bloque, puis expire : 4 s / 4 s / 6 s."),
    ActionType.TRUTH_OR_DARE to ActionMeta("😈", ActionCategory.FUN),
    ActionType.ROCK_PAPER_SCISSORS to ActionMeta("✊", ActionCategory.FUN,
        listOf(BlockField.Text("name", "Variable pour le résultat", "chifoumi"))),

    // --- Conditions ---
    ActionType.IF_CHARGING to ActionMeta("🔌", ActionCategory.LOGIQUE),
    ActionType.IF_SCREEN_ON to ActionMeta("🌞", ActionCategory.LOGIQUE),
    ActionType.IF_DEVICE_LOCKED to ActionMeta("🔒", ActionCategory.LOGIQUE),
    ActionType.IF_HEADSET_CONNECTED to ActionMeta("🎧", ActionCategory.LOGIQUE),
    ActionType.IF_MUSIC_PLAYING to ActionMeta("🎵", ActionCategory.LOGIQUE),
    ActionType.IF_RINGER_MODE to ActionMeta("🔕", ActionCategory.LOGIQUE, listOf(
        BlockField.Choice("mode", "Mode attendu", listOf(
            "🔔 Normal" to "normal", "📳 Vibreur" to "vibrate", "🔕 Silencieux" to "silent"
        ))
    )),
    ActionType.IF_DARK_MODE to ActionMeta("🌑", ActionCategory.LOGIQUE),
    ActionType.IF_POWER_SAVE to ActionMeta("🍃", ActionCategory.LOGIQUE),
    ActionType.IF_INTERNET to ActionMeta("🌐", ActionCategory.LOGIQUE),
    ActionType.IF_MOBILE_DATA to ActionMeta("📡", ActionCategory.LOGIQUE),
    ActionType.IF_AIRPLANE_MODE to ActionMeta("✈️", ActionCategory.LOGIQUE),
    ActionType.IF_BLUETOOTH_ON to ActionMeta("🟦", ActionCategory.LOGIQUE),
    ActionType.IF_WEEKEND to ActionMeta("🏖️", ActionCategory.LOGIQUE),
    ActionType.IF_VARIABLE_CONTAINS to ActionMeta("🔍", ActionCategory.LOGIQUE, listOf(
        BlockField.Text("name", "Nom de la variable"),
        BlockField.Text("value", "Texte recherché (majuscules ignorées)")
    )),
    ActionType.IF_VARIABLE_EMPTY to ActionMeta("🫙", ActionCategory.LOGIQUE,
        listOf(BlockField.Text("name", "Nom de la variable"))),
    ActionType.IF_DATE_IS to ActionMeta("📆", ActionCategory.LOGIQUE, listOf(
        BlockField.Number("day", "Jour", 1, 1, 31),
        BlockField.Number("month", "Mois", 1, 1, 12)
    ))
)

/** Nouvelles conditions : elles ouvrent un bloc Si / Sinon / Fin de condition. */
val EXTRA_CONDITION_TYPES: Set<ActionType> = setOf(
    ActionType.IF_CHARGING, ActionType.IF_SCREEN_ON, ActionType.IF_DEVICE_LOCKED,
    ActionType.IF_HEADSET_CONNECTED, ActionType.IF_MUSIC_PLAYING, ActionType.IF_RINGER_MODE,
    ActionType.IF_DARK_MODE, ActionType.IF_POWER_SAVE, ActionType.IF_INTERNET,
    ActionType.IF_MOBILE_DATA, ActionType.IF_AIRPLANE_MODE, ActionType.IF_BLUETOOTH_ON,
    ActionType.IF_WEEKEND, ActionType.IF_VARIABLE_CONTAINS, ActionType.IF_VARIABLE_EMPTY,
    ActionType.IF_DATE_IS
)

val EXTRA_CONNECTOR_TYPES: Set<ActionType> = setOf(
    ActionType.TEAMS_WEBHOOK, ActionType.GOTIFY_NOTIFICATION, ActionType.MASTODON_POST, ActionType.WEBHOOK_JSON
)

val EXTRA_VARIABLE_TYPES: Set<ActionType> = setOf(
    ActionType.TEXT_TRANSFORM, ActionType.TEXT_REPLACE, ActionType.TEXT_EXTRACT_REGEX,
    ActionType.EXTRACT_CODE, ActionType.ROUND_NUMBER, ActionType.DELETE_GLOBAL_VARIABLE,
    ActionType.LIST_RANDOM_ITEM
)

/** Libellé lisible d'un réglage pour l'affichage dans l'atelier ("Durée (secondes) : 10"
 *  plutôt que "seconds = 10"). Retombe sur la clé brute pour les anciens blocs. */
fun describeParams(fields: List<BlockField>?, params: Map<String, String>): String {
    if (params.isEmpty()) return ""
    return params.entries
        .filter { it.value.isNotBlank() && it.key != "consumed" && it.key != "times_left" }
        .joinToString(" • ") { (key, value) ->
            val field = fields?.firstOrNull { it.key == key }
            val shownValue = (field as? BlockField.Choice)?.options?.firstOrNull { it.second == value }?.first ?: value
            val label = field?.label?.substringBefore(" (") ?: prettyKey(key)
            "$label : ${shownValue.take(60)}"
        }
}

private val KEY_LABELS = mapOf(
    "hour" to "Heure", "minute" to "Minute", "text" to "Texte", "title" to "Titre",
    "number" to "Numéro", "package" to "Appli", "level" to "Niveau", "duration_ms" to "Durée (ms)",
    "seconds" to "Secondes", "minutes" to "Minutes", "url" to "URL", "name" to "Nom",
    "value" to "Valeur", "count" to "Nombre", "percent" to "Pourcentage", "days" to "Jours",
    "state" to "État", "city" to "Ville", "message" to "Message", "silent" to "Silencieuse",
    "global" to "Globale", "sender" to "Expéditeur", "ssid" to "Wi-Fi", "mode" to "Mode",
    "automation_name" to "Automatisation", "automation_id" to "ID", "start_hour" to "Début",
    "end_hour" to "Fin", "operator" to "Opérateur", "threshold" to "Seuil"
)

private fun prettyKey(key: String): String =
    KEY_LABELS[key] ?: key.replace('_', ' ').replaceFirstChar { it.uppercase() }
