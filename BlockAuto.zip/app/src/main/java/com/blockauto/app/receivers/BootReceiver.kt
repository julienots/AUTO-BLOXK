package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.services.WatchdogService
import com.blockauto.app.storage.AutomationRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // Relance le service de veille dès le démarrage : c'est ce qui garantit
        // que BlockAuto continue de fonctionner même si l'app n'a jamais été rouverte.
        WatchdogService.start(context)
        TriggerScheduler.scheduleAll(context)
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.BOOT_COMPLETED) {
                AutomationExecutionService.start(context, a.id)
            }
        }
    }
}
