package com.blockauto.app.builder

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.R
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.text.Normalizer

/**
 * Sélecteur "façon Scratch" pour choisir un bloc déclencheur ou action.
 *
 * Remplace les anciens menus texte (AlertDialog.setItems) par :
 * - une étape 1 en grille de catégories colorées (icône + libellé + nombre de blocs) ;
 * - une étape 2 en liste de blocs avec badge coloré/icône, à l'intérieur de la catégorie ;
 * - une recherche instantanée qui traverse TOUTES les catégories dès qu'on tape,
 *   avec le nom de la catégorie affiché en sous-titre pour se repérer.
 *
 * Le contenu (catégories/blocs/couleurs/icônes) reste fourni par l'appelant : ce composant
 * ne connaît rien de TriggerType/ActionType, il ne fait que l'afficher et le filtrer.
 */
class BlockPickerDialog(
    private val context: Context,
    private val title: String,
) {

    /** Une catégorie de blocs (ex : "⏰ Temps"), avec sa couleur et ses blocs. */
    data class CategoryEntry(
        val label: String,
        val icon: String,
        val color: Int,
        val items: List<ItemEntry>,
    )

    /** Un bloc précis à l'intérieur d'une catégorie. */
    data class ItemEntry(
        val label: String,
        val icon: String,
        val color: Int,
        val onSelect: () -> Unit,
    )

    private sealed class Row {
        data class Category(val entry: CategoryEntry) : Row()
        data class Item(val entry: ItemEntry, val categoryLabel: String?) : Row()
    }

    private lateinit var dialog: BottomSheetDialog
    private lateinit var recycler: RecyclerView
    private lateinit var titleView: android.widget.TextView
    private lateinit var backButton: android.widget.ImageButton
    private lateinit var breadcrumb: android.widget.TextView
    private lateinit var searchBox: android.widget.EditText
    private lateinit var clearSearchButton: android.widget.ImageButton
    private lateinit var emptyView: android.widget.TextView

    private var currentCategory: CategoryEntry? = null
    private var categories: List<CategoryEntry> = emptyList()

    fun show(categories: List<CategoryEntry>) {
        this.categories = categories
        dialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_block_picker, null)
        dialog.setContentView(view)

        titleView = view.findViewById(R.id.textPickerTitle)
        backButton = view.findViewById(R.id.btnPickerBack)
        breadcrumb = view.findViewById(R.id.textPickerBreadcrumb)
        searchBox = view.findViewById(R.id.editPickerSearch)
        clearSearchButton = view.findViewById(R.id.btnPickerClearSearch)
        emptyView = view.findViewById(R.id.textPickerEmpty)
        recycler = view.findViewById(R.id.recyclerPicker)
        val closeButton = view.findViewById<android.widget.ImageButton>(R.id.btnPickerClose)

        closeButton.setOnClickListener { dialog.dismiss() }
        backButton.setOnClickListener {
            searchBox.setText("")
            showCategories()
        }
        clearSearchButton.setOnClickListener { searchBox.setText("") }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString().orEmpty()
                clearSearchButton.visibility = if (query.isBlank()) View.GONE else View.VISIBLE
                if (query.isBlank()) {
                    if (currentCategory != null) showCategoryItems(currentCategory!!) else showCategories()
                } else {
                    showSearchResults(query)
                }
            }
        })

        showCategories()
        dialog.show()
    }

    private fun normalize(text: String): String {
        val decomposed = Normalizer.normalize(text, Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{M}"), "").lowercase()
    }

    private fun showCategories() {
        currentCategory = null
        titleView.text = title
        backButton.visibility = View.GONE
        breadcrumb.visibility = View.GONE
        val rows = categories.map { Row.Category(it) }
        renderRows(rows, grid = true)
    }

    private fun showCategoryItems(category: CategoryEntry) {
        currentCategory = category
        titleView.text = category.label
        backButton.visibility = View.VISIBLE
        breadcrumb.visibility = View.GONE
        val rows = category.items.map { Row.Item(it, categoryLabel = null) }
        renderRows(rows, grid = false)
    }

    private fun showSearchResults(query: String) {
        val needle = normalize(query)
        backButton.visibility = if (currentCategory != null) View.VISIBLE else View.GONE
        titleView.text = context.getString(R.string.picker_search_results_title)
        val scope = if (currentCategory != null) listOf(currentCategory!!) else categories
        breadcrumb.visibility = if (currentCategory != null) View.VISIBLE else View.GONE
        breadcrumb.text = currentCategory?.label.orEmpty()

        val rows = scope.flatMap { cat ->
            cat.items
                .filter { normalize(it.label).contains(needle) }
                .map { Row.Item(it, categoryLabel = if (currentCategory == null) cat.label else null) }
        }
        renderRows(rows, grid = false)
    }

    private fun renderRows(rows: List<Row>, grid: Boolean) {
        emptyView.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        recycler.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE
        recycler.layoutManager = if (grid) GridLayoutManager(context, 2) else LinearLayoutManager(context)
        recycler.adapter = RowAdapter(rows)
    }

    private inner class RowAdapter(private val rows: List<Row>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun getItemViewType(position: Int): Int = when (rows[position]) {
            is Row.Category -> TYPE_CATEGORY
            is Row.Item -> TYPE_ITEM
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_CATEGORY) {
                CategoryHolder(inflater.inflate(R.layout.item_picker_category, parent, false))
            } else {
                ItemHolder(inflater.inflate(R.layout.item_picker_block, parent, false))
            }
        }

        override fun getItemCount(): Int = rows.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = rows[position]) {
                is Row.Category -> (holder as CategoryHolder).bind(row.entry)
                is Row.Item -> (holder as ItemHolder).bind(row.entry, row.categoryLabel)
            }
        }
    }

    private inner class CategoryHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val badgeBg: View = itemView.findViewById(R.id.viewCategoryBadgeBg)
        private val icon: android.widget.TextView = itemView.findViewById(R.id.textCategoryIcon)
        private val label: android.widget.TextView = itemView.findViewById(R.id.textCategoryLabel)
        private val count: android.widget.TextView = itemView.findViewById(R.id.textCategoryCount)

        fun bind(entry: CategoryEntry) {
            tintBadge(badgeBg, entry.color)
            icon.text = entry.icon
            label.text = entry.label
            val n = entry.items.size
            count.text = itemView.context.resources.getQuantityStringSafe(n)
            itemView.setOnClickListener { showCategoryItems(entry) }
        }
    }

    private inner class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val badgeBg: View = itemView.findViewById(R.id.viewBlockBadgeBg)
        private val icon: android.widget.TextView = itemView.findViewById(R.id.textBlockIcon)
        private val label: android.widget.TextView = itemView.findViewById(R.id.textBlockLabel)
        private val categoryLabel: android.widget.TextView = itemView.findViewById(R.id.textBlockCategory)

        fun bind(entry: ItemEntry, categoryHint: String?) {
            tintBadge(badgeBg, entry.color)
            icon.text = entry.icon
            label.text = entry.label
            if (categoryHint != null) {
                categoryLabel.visibility = View.VISIBLE
                categoryLabel.text = categoryHint
            } else {
                categoryLabel.visibility = View.GONE
            }
            itemView.setOnClickListener {
                dialog.dismiss()
                entry.onSelect()
            }
        }
    }

    private fun tintBadge(badgeBg: View, color: Int) {
        val drawable = badgeBg.background.mutate()
        DrawableCompat.setTint(drawable, color)
        badgeBg.background = drawable
    }

    companion object {
        private const val TYPE_CATEGORY = 0
        private const val TYPE_ITEM = 1
    }
}

/** Petit helper pour un texte "N blocs" / "1 bloc" sans avoir à déclarer un plurals.xml. */
private fun android.content.res.Resources.getQuantityStringSafe(count: Int): String =
    if (count <= 1) "$count bloc" else "$count blocs"
