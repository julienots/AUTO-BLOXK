package com.blockauto.app.model

import java.util.UUID

/**
 * Les blocs "déclencheur" disponibles dans la palette.
 * Chaque bloc est comme une pièce d'engrenage : il ne tourne qu'une fois
 * l'événement réel produit, même app fermée / téléphone verrouillé.
 */
enum class TriggerType(val label: String) {
    TIME("Heure précise"),
    INTERVAL("Toutes les X minutes"),
    BOOT_COMPLETED("Démarrage du téléphone"),
    BATTERY_LOW("Batterie faible (<15%)"),
    BATTERY_FULL("Branché sur secteur"),
    BATTERY_LEVEL("Niveau de batterie précis"),
    APP_OPENED("Application ouverte"),
    NOTIFICATION_RECEIVED("Notification reçue"),
    SMS_RECEIVED("SMS reçu"),
    WIFI_CONNECTED("Wi-Fi connecté"),
    WIFI_DISCONNECTED("Wi-Fi déconnecté"),
    BLUETOOTH_CONNECTED("Appareil Bluetooth connecté"),
    HEADSET_CONNECTED("Écouteurs branchés"),
    SCREEN_ON("Écran allumé"),
    SCREEN_OFF("Écran éteint"),
    DEVICE_UNLOCKED("Téléphone déverrouillé"),
    AIRPLANE_MODE_ON("Mode avion activé"),
    SHAKE("Secousse du téléphone"),
    CALL_INCOMING("Appel entrant"),
    CALL_ENDED("Appel terminé"),
    POWER_DISCONNECTED("Débranché du secteur"),
    HEADSET_DISCONNECTED("Écouteurs débranchés"),
    USB_CONNECTED("Câble USB (données) branché"),
    USB_DISCONNECTED("Câble USB (données) débranché"),
    WIFI_CONNECTED_SSID("Connexion à un Wi-Fi précis"),
    RINGER_MODE_CHANGED("Mode sonnerie changé"),
    STORAGE_LOW("Stockage presque plein"),
    MANUAL("Déclenchement manuel uniquement"),
    APP_CLOSED("Application fermée / quittée"),
    APP_INSTALLED("Application installée"),
    APP_UNINSTALLED("Application désinstallée"),
    CLIPBOARD_CHANGED("Presse-papiers modifié"),
    MEMORY_LOW("Mémoire RAM presque pleine"),

    // --- Nouveaux blocs déclencheurs (temps avancé) ---
    WEEKDAY_TIME("Heure précise, certains jours"),
    RANDOM_DAILY_TIME("Heure aléatoire chaque jour"),
    COUNTDOWN_ONCE("Dans X minutes (une seule fois)"),
    INTERVAL_LIMITED("Toutes les X minutes, N fois"),
    MONTHLY_DATE("Jour précis du mois"),
    YEARLY_DATE("Date annuelle (anniversaire, fête...)"),
    RANDOM_INTERVAL("Toutes les X à Y minutes (aléatoire)"),

    // --- Nouveaux blocs déclencheurs (système, seconde vague) ---
    DARK_MODE_ON("Mode sombre activé"),
    DARK_MODE_OFF("Mode sombre désactivé"),
    POWER_SAVE_MODE_ON("Économie d'énergie activée"),
    POWER_SAVE_MODE_OFF("Économie d'énergie désactivée"),
    LANGUAGE_CHANGED("Langue du téléphone changée"),
    DATE_TIME_CHANGED("Date ou heure changée manuellement"),
    DOCK_CONNECTED("Posé sur un dock/support"),
    DOCK_DISCONNECTED("Retiré du dock/support"),
    AIRPLANE_MODE_OFF("Mode avion désactivé"),
    APP_UPDATED("Application mise à jour"),

    // --- Nouveau déclencheur "dans l'application" (accessibilité) ---
    UI_TEXT_APPEARS("Un texte apparaît à l'écran"),

    // --- Nouveaux déclencheurs (troisième vague) ---
    EVERY_N_HOURS("Toutes les X heures"),
    UI_TEXT_DISAPPEARS("Un texte disparaît de l'écran"),
    NOTIFICATION_CONTAINS_TEXT("Notification contenant un texte précis"),

    // --- Nouveaux déclencheurs (quatrième vague : chaînes réelles + fun) ---
    TIME_WINDOW_INTERVAL("Toutes les X min, entre deux heures"),
    FULL_MOON("Pleine lune 🌕"),
    FRIDAY_13TH("Vendredi 13 😱"),
    PALINDROME_TIME("Heure palindrome (12:21, 20:02...) 🔮"),

    // --- Nouveau déclencheur : tag NFC ---
    NFC_TAG_SCANNED("Tag NFC scanné"),

    // --- Version 3 : nouveaux déclencheurs ---
    BATTERY_CHARGED_FULL("Batterie chargée à 100%"),
    BATTERY_TEMP_HIGH("Batterie trop chaude"),
    CHARGING_WIRELESS("Recharge sans fil démarrée"),
    MOBILE_DATA_CONNECTED("Données mobiles connectées"),
    MOBILE_DATA_DISCONNECTED("Données mobiles coupées"),
    INTERNET_LOST("Connexion Internet perdue"),
    INTERNET_RESTORED("Connexion Internet retrouvée"),
    BLUETOOTH_DISCONNECTED("Appareil Bluetooth déconnecté"),
    BLUETOOTH_TURNED_ON("Bluetooth activé"),
    BLUETOOTH_TURNED_OFF("Bluetooth désactivé"),
    WIFI_TURNED_ON("Wi-Fi activé"),
    WIFI_TURNED_OFF("Wi-Fi désactivé"),
    VOLUME_CHANGED("Volume modifié"),
    PHONE_FACE_DOWN("Téléphone retourné face contre table"),
    PHONE_FACE_UP("Téléphone remis face vers le haut"),
    PROXIMITY_NEAR("Main passée devant le capteur de proximité"),
    UNLOCK_COUNT_REACHED("Xᵉ déverrouillage de la journée"),
    SUNRISE("Lever du soleil 🌅"),
    SUNSET("Coucher du soleil 🌇"),
    MULTI_TIMES_DAILY("Plusieurs heures par jour"),
    HOURLY_CHIME("Chaque heure pile"),
    LAST_DAY_OF_MONTH("Dernier jour du mois"),
    SMS_CONTAINS_TEXT("SMS contenant un mot-clé"),
    MISSED_CALL("Appel manqué")
}

/** Les blocs "action" et "logique" disponibles dans la palette. */
enum class ActionType(val label: String) {
    // --- Actions concrètes ---
    OPEN_APP("Ouvrir une application"),
    SEND_NOTIFICATION("Envoyer une notification"),
    SHOW_TOAST("Afficher un message"),
    VIBRATE("Faire vibrer"),
    SET_VOLUME("Régler le volume média"),
    SET_BRIGHTNESS("Régler la luminosité"),
    TOGGLE_FLASHLIGHT("Lampe torche"),
    TOGGLE_WIFI("Activer / désactiver le Wi-Fi"),
    TOGGLE_BLUETOOTH("Activer / désactiver le Bluetooth"),
    SET_RINGER_MODE("Régler le mode sonnerie"),
    OPEN_URL("Ouvrir un lien"),
    OPEN_WIFI_SETTINGS("Ouvrir réglages Wi-Fi"),
    OPEN_BLUETOOTH_SETTINGS("Ouvrir réglages Bluetooth"),
    OPEN_DND_SETTINGS("Ouvrir Ne pas déranger"),
    SEND_SMS("Envoyer un SMS"),
    MAKE_CALL("Passer un appel"),
    SEND_EMAIL("Envoyer un e-mail"),
    COPY_CLIPBOARD("Copier dans le presse-papiers"),
    CREATE_ALARM("Créer une alarme"),
    WAKE_SCREEN("Réveiller l'écran"),
    LOG_EVENT("Enregistrer dans l'historique"),
    WAIT("Attendre quelques secondes"),
    CALL_CONTACT("Appeler un contact"),
    ADD_CALENDAR_EVENT("Ajouter un événement au calendrier"),
    SHARE_TEXT("Partager du texte (menu de partage)"),
    TOGGLE_AUTO_ROTATE("Activer / désactiver la rotation auto"),
    TOGGLE_DND("Activer / désactiver Ne pas déranger"),
    TAKE_SCREENSHOT("Prendre une capture d'écran"),
    RECORD_AUDIO_CLIP("Enregistrer un extrait audio"),
    GET_LOCATION("Récupérer la position GPS"),
    CLEAR_NOTIFICATIONS("Effacer toutes les notifications"),
    SET_RING_VOLUME("Régler le volume de sonnerie"),
    CANCEL_VIBRATION("Arrêter la vibration en cours"),
    SET_ALARM_VOLUME("Régler le volume d'alarme"),
    SPEAK_TEXT("Lire un texte à voix haute"),
    CREATE_TIMER("Démarrer un minuteur"),
    OPEN_CAMERA("Ouvrir l'appareil photo"),
    SET_SCREEN_TIMEOUT("Régler la mise en veille de l'écran"),
    MEDIA_PLAY_PAUSE("Lecture / pause de la musique"),

    // --- Blocs connecteurs (services externes) ---
    HTTP_REQUEST("Connecteur : requête HTTP générique"),
    DISCORD_WEBHOOK("Connecteur : webhook Discord"),
    TELEGRAM_MESSAGE("Connecteur : message Telegram (bot)"),
    SLACK_WEBHOOK("Connecteur : webhook Slack"),
    IFTTT_WEBHOOK("Connecteur : webhook IFTTT"),
    HOME_ASSISTANT_WEBHOOK("Connecteur : webhook Home Assistant"),
    ZAPIER_WEBHOOK("Connecteur : webhook Zapier"),
    MAKE_WEBHOOK("Connecteur : webhook Make (Integromat)"),
    NTFY_NOTIFICATION("Connecteur : notification ntfy.sh"),
    PUSHOVER_NOTIFICATION("Connecteur : notification Pushover"),
    GOOGLE_SHEETS_WEBHOOK("Connecteur : ajouter une ligne Google Sheets"),
    NOTION_API("Connecteur : créer une page Notion"),
    TRELLO_WEBHOOK("Connecteur : créer une carte Trello"),
    HTTP_REQUEST_ADVANCED("Connecteur : requête HTTP avancée (headers + en-têtes)"),
    GET_WEATHER("Connecteur : météo actuelle (ville)"),

    // --- Blocs logiques (engrenages de contrôle) ---
    IF_BATTERY_ABOVE("Condition : batterie au-dessus de X%"),
    IF_BATTERY_BELOW("Condition : batterie en dessous de X%"),
    IF_WIFI_CONNECTED("Condition : Wi-Fi connecté"),
    IF_DAY_OF_WEEK("Condition : jour de la semaine"),
    IF_TIME_BETWEEN("Condition : heure comprise entre"),
    IF_APP_INSTALLED("Condition : une application est installée"),
    RANDOM_CHANCE("Chance aléatoire (%)"),
    REPEAT_START("Répéter les blocs suivants"),
    REPEAT_END("Fin de répétition"),
    ELSE_BRANCH("Sinon"),
    ENDIF("Fin de condition (Si / Sinon)"),
    STOP_AUTOMATION("Arrêter l'automatisation"),

    // --- Chaînage d'automatisations ---
    RUN_AUTOMATION("Exécuter une autre automatisation"),

    // --- Nouveaux blocs actions (navigation système / accessibilité) ---
    LOCK_SCREEN("Verrouiller l'écran"),
    GO_HOME("Retour à l'écran d'accueil"),
    OPEN_RECENT_APPS("Ouvrir les applications récentes"),
    OPEN_APP_SETTINGS("Ouvrir les réglages d'une application"),

    // --- Blocs variables (façon Scratch : valeurs réutilisables entre les blocs) ---
    SET_VARIABLE("Variable : définir une valeur"),
    INCREMENT_VARIABLE("Variable : ajouter à une valeur"),
    RANDOM_NUMBER("Variable : nombre aléatoire"),
    MATH_OPERATION("Variable : calcul (+ − × ÷ %)"),
    RANDOM_CHOICE_VARIABLE("Variable : choix aléatoire dans une liste"),
    LOAD_GLOBAL_VARIABLE("Variable globale : charger (partagée entre automatisations)"),
    JSON_EXTRACT_VARIABLE("Variable : extraire un champ d'une réponse JSON"),

    // --- Blocs listes (façon Scratch : une variable qui contient plusieurs valeurs) ---
    SET_LIST("Liste : créer/remplacer une liste"),
    LIST_APPEND("Liste : ajouter un élément"),
    LIST_GET_ITEM("Liste : lire un élément (par position)"),
    LIST_LENGTH("Liste : compter les éléments"),

    // --- Chaînage avancé : mise en pause temporaire d'une automatisation ---
    PAUSE_AUTOMATION_FOR("Mettre une automatisation en pause pendant X minutes"),

    // --- Blocs fun / envois groupés ---
    SEND_MULTIPLE_SMS("Envoyer plusieurs SMS à la suite"),
    SEND_MULTIPLE_NOTIFICATIONS("Envoyer plusieurs notifications"),
    PLAY_BEEP("Jouer un bip sonore"),
    VIBRATE_PATTERN("Vibrer en motif (SOS, etc.)"),
    SHOW_RANDOM_MESSAGE("Afficher un message au hasard"),
    RANDOM_DELAY("Attendre un temps aléatoire"),

    // --- Blocs logiques avancés (chaînes complexes à base de valeurs) ---
    IF_VARIABLE_ABOVE("Condition : variable au-dessus de X"),
    IF_VARIABLE_BELOW("Condition : variable en dessous de X"),
    IF_VARIABLE_EQUALS("Condition : variable égale à X"),
    REPEAT_WHILE_START("Répéter tant qu'une variable..."),

    // --- Chaînage avancé ---
    RANDOM_RUN_AUTOMATION("Chaîner vers une automatisation au hasard"),

    // --- Blocs d'interaction DANS les applications (accessibilité) ---
    UI_CLICK_TEXT("Dans l'appli : cliquer sur un texte"),
    UI_CLICK_DESCRIPTION("Dans l'appli : cliquer sur une icône (description)"),
    UI_LONG_CLICK_TEXT("Dans l'appli : appui long sur un texte"),
    UI_INPUT_TEXT("Dans l'appli : écrire dans le champ actif"),
    UI_SCROLL_DOWN("Dans l'appli : faire défiler vers le bas"),
    UI_SCROLL_UP("Dans l'appli : faire défiler vers le haut"),
    UI_SWIPE("Dans l'appli : balayer l'écran"),
    UI_PRESS_BACK("Dans l'appli : bouton retour"),
    UI_WAIT_FOR_TEXT("Dans l'appli : attendre qu'un texte apparaisse"),
    UI_OPEN_APP_AND_CLICK("Ouvrir une appli puis cliquer sur un texte"),

    // --- Condition d'interface ---
    IF_TEXT_VISIBLE("Condition : un texte est visible à l'écran"),

    // --- Nouveaux blocs "envoyer un message dans une appli" (accessibilité) ---
    // Ces blocs généralisent l'envoi de messages à N'IMPORTE QUELLE application de
    // messagerie (Instagram, WhatsApp, Messenger, Telegram, l'appli SMS elle-même...) :
    // ils ne sont PAS spécifiques à une appli, ils utilisent le champ de saisie et le
    // bouton d'envoi réellement affichés à l'écran, comme le ferait un doigt humain.
    UI_CLICK_INPUT_FIELD("Dans l'appli : cliquer sur le champ de saisie"),
    UI_SEND_MESSAGE_IN_APP("Dans l'appli : écrire et envoyer un message"),
    UI_SEND_MULTIPLE_MESSAGES_IN_APP("Dans l'appli : envoyer plusieurs messages à la suite"),
    UI_OPEN_APP_AND_SEND_MESSAGE("Ouvrir une appli, ouvrir une conversation, et envoyer un message"),

    // --- Nouveaux blocs fun / surprises (quatrième vague) ---
    FLIP_COIN("Pile ou face 🪙"),
    TELL_JOKE("Raconter une blague au hasard 🤡"),
    SET_WALLPAPER_COLOR("Changer le fond d'écran (couleur unie) 🎨"),
    OPEN_RANDOM_APP("Ouvrir une application au hasard 🎰"),
    MYSTERY_BOX("Boîte mystère (effet surprise) 🎁"),

    // ===================== Version 3 : nouveaux blocs =====================
    // --- Musique & son ---
    MEDIA_NEXT("Musique : piste suivante"),
    MEDIA_PREVIOUS("Musique : piste précédente"),
    MEDIA_PAUSE("Musique : pause"),
    MEDIA_PLAY("Musique : lecture"),
    MEDIA_STOP("Musique : arrêter"),
    VOLUME_UP("Monter le volume d'un cran"),
    VOLUME_DOWN("Baisser le volume d'un cran"),
    MUTE_MEDIA("Couper / remettre le son des médias"),
    SET_NOTIFICATION_VOLUME("Régler le volume des notifications"),
    SET_CALL_VOLUME("Régler le volume des appels"),
    PLAY_RINGTONE("Faire sonner le téléphone (le retrouver) 📢"),
    PLAY_MELODY("Jouer une petite mélodie 🎼"),
    PLAY_MEDIA_SEARCH("Lancer une musique par recherche"),
    SPEAK_TIME("Annoncer l'heure à voix haute"),
    SPEAK_BATTERY("Annoncer le niveau de batterie"),
    SPEAK_SUMMARY("Briefing vocal (heure, date, batterie)"),

    // --- Système ---
    FLASHLIGHT_BLINK("Faire clignoter la lampe torche"),
    FLASHLIGHT_SOS("Lampe torche en SOS morse"),
    SET_AUTO_BRIGHTNESS("Luminosité automatique"),
    OPEN_SETTINGS_PAGE("Ouvrir une page de réglages"),
    OPEN_NOTIFICATION_SHADE("Dérouler le volet des notifications"),
    OPEN_QUICK_SETTINGS("Ouvrir les réglages rapides"),
    OPEN_POWER_MENU("Ouvrir le menu d'alimentation"),
    TOGGLE_SPLIT_SCREEN("Activer l'écran partagé"),
    CLEAR_BLOCKAUTO_NOTIFICATIONS("Effacer les notifications de BlockAuto"),

    // --- Communication ---
    SEND_BIG_NOTIFICATION("Notification avec long texte"),
    SEND_NOTIFICATION_WITH_LINK("Notification qui ouvre un lien"),
    WHATSAPP_PREFILL("WhatsApp : préparer un message"),
    SMS_COMPOSE("Préparer un SMS (sans l'envoyer)"),
    OPEN_DIALER("Composer un numéro (sans appeler)"),

    // --- Web & navigation ---
    OPEN_MAPS_NAVIGATION("Lancer un itinéraire GPS"),
    OPEN_MAPS_SEARCH("Chercher un lieu sur la carte"),
    WEB_SEARCH("Faire une recherche web"),
    YOUTUBE_SEARCH("Rechercher sur YouTube"),
    OPEN_PLAY_STORE("Ouvrir une appli dans le Play Store"),
    WIKIPEDIA_SUMMARY("Résumé Wikipédia → variable"),

    // --- Infos & capteurs ---
    GET_BATTERY_INFO("Infos batterie → variables"),
    GET_DEVICE_INFO("Infos appareil → variables"),
    GET_DATE_TIME("Date et heure → variables"),
    GET_NETWORK_INFO("Infos réseau → variables"),
    GET_CLIPBOARD("Lire le presse-papiers → variable"),
    GET_PUBLIC_IP("Adresse IP publique → variable"),
    GET_CRYPTO_PRICE("Cours d'une crypto-monnaie → variable"),
    GET_EXCHANGE_RATE("Taux de change → variable"),
    GET_LIGHT_LEVEL("Luminosité ambiante (capteur) → variable"),
    COUNT_DAYS_UNTIL("Jours restants avant une date → variable"),

    // --- Texte & fichiers ---
    TEXT_TRANSFORM("Texte : transformer (majuscules, inverser...)"),
    TEXT_REPLACE("Texte : rechercher / remplacer"),
    TEXT_EXTRACT_REGEX("Texte : extraire avec une expression régulière"),
    EXTRACT_CODE("Texte : extraire un code de validation (OTP) 🔑"),
    ROUND_NUMBER("Nombre : arrondir"),
    DELETE_GLOBAL_VARIABLE("Variable globale : supprimer"),
    LIST_RANDOM_ITEM("Liste : piocher un élément au hasard"),
    FILE_APPEND_LINE("Fichier : ajouter une ligne (journal)"),
    FILE_WRITE("Fichier : écrire (remplace le contenu)"),
    FILE_READ("Fichier : lire dans une variable"),

    // --- Connecteurs ---
    TEAMS_WEBHOOK("Connecteur : webhook Microsoft Teams"),
    GOTIFY_NOTIFICATION("Connecteur : notification Gotify"),
    MASTODON_POST("Connecteur : publier sur Mastodon"),
    WEBHOOK_JSON("Connecteur : webhook JSON personnalisé"),

    // --- Fun & surprises ---
    ROLL_DICE("Lancer un dé 🎲"),
    MAGIC_8_BALL("Boule magique 🎱"),
    RANDOM_COMPLIMENT("Compliment au hasard 💖"),
    RANDOM_QUOTE("Citation inspirante au hasard 💡"),
    RANDOM_FACT("Le savais-tu ? (anecdote) 🧠"),
    RANDOM_WALLPAPER_COLOR("Fond d'écran couleur aléatoire 🌈"),
    GRADIENT_WALLPAPER("Fond d'écran dégradé 🌅"),
    DISCO_MODE("Mode disco (lampe + vibrations) 🪩"),
    RANDOM_PASSWORD("Générer un mot de passe 🔐"),
    BREATHING_EXERCISE("Respiration guidée 🧘"),
    TRUTH_OR_DARE("Action ou vérité 😈"),
    ROCK_PAPER_SCISSORS("Pierre-feuille-ciseaux ✊"),

    // --- Nouvelles conditions ---
    IF_CHARGING("Condition : téléphone en charge"),
    IF_SCREEN_ON("Condition : écran allumé"),
    IF_DEVICE_LOCKED("Condition : téléphone verrouillé"),
    IF_HEADSET_CONNECTED("Condition : écouteurs / casque connectés"),
    IF_MUSIC_PLAYING("Condition : de la musique est en cours"),
    IF_RINGER_MODE("Condition : mode sonnerie est..."),
    IF_DARK_MODE("Condition : mode sombre actif"),
    IF_POWER_SAVE("Condition : économie d'énergie active"),
    IF_INTERNET("Condition : Internet disponible"),
    IF_MOBILE_DATA("Condition : connecté en données mobiles"),
    IF_AIRPLANE_MODE("Condition : mode avion actif"),
    IF_BLUETOOTH_ON("Condition : Bluetooth activé"),
    IF_WEEKEND("Condition : c'est le week-end"),
    IF_VARIABLE_CONTAINS("Condition : variable contient un texte"),
    IF_VARIABLE_EMPTY("Condition : variable vide ou inexistante"),
    IF_DATE_IS("Condition : on est un jour précis (date)")
}

/** Catégorie visuelle d'un bloc, utilisée pour la couleur de l'engrenage dans l'atelier. */
enum class BlockCategory { TRIGGER, ACTION, LOGIC, CONNECTOR, CHAIN, VARIABLE }

/** Blocs de condition qui peuvent ouvrir un bloc Si / Sinon / Fin de condition. */
val CONDITION_TYPES = setOf(
    ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW, ActionType.IF_WIFI_CONNECTED,
    ActionType.IF_DAY_OF_WEEK, ActionType.IF_TIME_BETWEEN,
    ActionType.IF_VARIABLE_ABOVE, ActionType.IF_VARIABLE_BELOW, ActionType.IF_VARIABLE_EQUALS,
    ActionType.IF_TEXT_VISIBLE, ActionType.IF_APP_INSTALLED
) + EXTRA_CONDITION_TYPES

/** Blocs qui interagissent avec le contenu d'une autre application via l'accessibilité
 *  (cliquer sur un texte/une icône, écrire, défiler, balayer, revenir en arrière...). */
val UI_INTERACTION_TYPES = setOf(
    ActionType.UI_CLICK_TEXT, ActionType.UI_CLICK_DESCRIPTION, ActionType.UI_LONG_CLICK_TEXT,
    ActionType.UI_INPUT_TEXT, ActionType.UI_SCROLL_DOWN, ActionType.UI_SCROLL_UP,
    ActionType.UI_SWIPE, ActionType.UI_PRESS_BACK, ActionType.UI_WAIT_FOR_TEXT,
    ActionType.UI_OPEN_APP_AND_CLICK,
    ActionType.UI_CLICK_INPUT_FIELD, ActionType.UI_SEND_MESSAGE_IN_APP,
    ActionType.UI_SEND_MULTIPLE_MESSAGES_IN_APP, ActionType.UI_OPEN_APP_AND_SEND_MESSAGE
)

/** Blocs qui ouvrent une répétition et attendent un bloc "Fin de répétition" pour se refermer. */
val REPEAT_OPEN_TYPES = setOf(ActionType.REPEAT_START, ActionType.REPEAT_WHILE_START)

val FLOW_CONTROL_TYPES = CONDITION_TYPES + setOf(
    ActionType.RANDOM_CHANCE,
    ActionType.REPEAT_START, ActionType.REPEAT_WHILE_START, ActionType.REPEAT_END,
    ActionType.ELSE_BRANCH, ActionType.ENDIF,
    ActionType.STOP_AUTOMATION
)

/** Blocs qui parlent à un service externe (webhook, bot, requête HTTP...). */
val CONNECTOR_TYPES = setOf(
    ActionType.HTTP_REQUEST, ActionType.DISCORD_WEBHOOK, ActionType.TELEGRAM_MESSAGE,
    ActionType.SLACK_WEBHOOK, ActionType.IFTTT_WEBHOOK, ActionType.HOME_ASSISTANT_WEBHOOK,
    ActionType.ZAPIER_WEBHOOK, ActionType.MAKE_WEBHOOK, ActionType.NTFY_NOTIFICATION,
    ActionType.PUSHOVER_NOTIFICATION, ActionType.GOOGLE_SHEETS_WEBHOOK, ActionType.NOTION_API,
    ActionType.TRELLO_WEBHOOK, ActionType.HTTP_REQUEST_ADVANCED, ActionType.GET_WEATHER
) + EXTRA_CONNECTOR_TYPES

/** Blocs qui chaînent vers une autre automatisation. */
val CHAIN_TYPES = setOf(ActionType.RUN_AUTOMATION, ActionType.RANDOM_RUN_AUTOMATION, ActionType.PAUSE_AUTOMATION_FOR)

/** Blocs "façon Scratch" qui lisent/écrivent une variable réutilisable par {nom}. */
val VARIABLE_TYPES = setOf(
    ActionType.SET_VARIABLE, ActionType.INCREMENT_VARIABLE, ActionType.RANDOM_NUMBER,
    ActionType.MATH_OPERATION, ActionType.RANDOM_CHOICE_VARIABLE, ActionType.LOAD_GLOBAL_VARIABLE,
    ActionType.JSON_EXTRACT_VARIABLE,
    ActionType.SET_LIST, ActionType.LIST_APPEND, ActionType.LIST_GET_ITEM, ActionType.LIST_LENGTH
) + EXTRA_VARIABLE_TYPES

fun ActionType.category(): BlockCategory = when {
    this in FLOW_CONTROL_TYPES -> BlockCategory.LOGIC
    this in CONNECTOR_TYPES -> BlockCategory.CONNECTOR
    this in CHAIN_TYPES -> BlockCategory.CHAIN
    this in VARIABLE_TYPES -> BlockCategory.VARIABLE
    else -> BlockCategory.ACTION
}

// ============================================================================
// Regroupement "façon Scratch" : dans l'atelier Scratch, la palette de blocs
// est rangée par catégories colorées (Mouvement, Son, Événements, Contrôle...)
// plutôt qu'en une seule liste géante. On reproduit ce rangement ici pour les
// sélecteurs de blocs déclencheurs / actions de l'atelier BlockAuto.
// ============================================================================

/** Groupe visuel d'un bloc déclencheur dans le sélecteur (étape 1 : choisir un groupe). */
enum class TriggerCategory(val label: String) {
    TEMPS("⏰ Temps"),
    BATTERIE("🔋 Batterie & démarrage"),
    RESEAU("📶 Réseau & connectivité"),
    APPAREIL("📱 Appareil & capteurs"),
    APPLICATIONS("🚀 Applications"),
    COMMUNICATION("✉️ Communication"),
    MANUEL("👆 Manuel"),
    FUN("🎉 Fun & insolite")
}

fun TriggerType.paletteCategory(): TriggerCategory = when (this) {
    TriggerType.TIME, TriggerType.INTERVAL, TriggerType.WEEKDAY_TIME,
    TriggerType.RANDOM_DAILY_TIME, TriggerType.COUNTDOWN_ONCE, TriggerType.INTERVAL_LIMITED,
    TriggerType.MONTHLY_DATE, TriggerType.YEARLY_DATE, TriggerType.RANDOM_INTERVAL -> TriggerCategory.TEMPS

    TriggerType.BATTERY_LOW, TriggerType.BATTERY_FULL, TriggerType.BATTERY_LEVEL,
    TriggerType.POWER_DISCONNECTED, TriggerType.BOOT_COMPLETED -> TriggerCategory.BATTERIE

    TriggerType.WIFI_CONNECTED, TriggerType.WIFI_DISCONNECTED, TriggerType.WIFI_CONNECTED_SSID,
    TriggerType.BLUETOOTH_CONNECTED, TriggerType.AIRPLANE_MODE_ON,
    TriggerType.USB_CONNECTED, TriggerType.USB_DISCONNECTED -> TriggerCategory.RESEAU

    TriggerType.SCREEN_ON, TriggerType.SCREEN_OFF, TriggerType.DEVICE_UNLOCKED, TriggerType.SHAKE,
    TriggerType.HEADSET_CONNECTED, TriggerType.HEADSET_DISCONNECTED, TriggerType.RINGER_MODE_CHANGED,
    TriggerType.STORAGE_LOW, TriggerType.MEMORY_LOW, TriggerType.CLIPBOARD_CHANGED,
    TriggerType.DARK_MODE_ON, TriggerType.DARK_MODE_OFF,
    TriggerType.POWER_SAVE_MODE_ON, TriggerType.POWER_SAVE_MODE_OFF,
    TriggerType.LANGUAGE_CHANGED, TriggerType.DATE_TIME_CHANGED,
    TriggerType.DOCK_CONNECTED, TriggerType.DOCK_DISCONNECTED,
    TriggerType.AIRPLANE_MODE_OFF, TriggerType.NFC_TAG_SCANNED -> TriggerCategory.APPAREIL

    TriggerType.APP_OPENED, TriggerType.APP_CLOSED,
    TriggerType.APP_INSTALLED, TriggerType.APP_UNINSTALLED, TriggerType.APP_UPDATED,
    TriggerType.UI_TEXT_APPEARS, TriggerType.UI_TEXT_DISAPPEARS -> TriggerCategory.APPLICATIONS

    TriggerType.NOTIFICATION_RECEIVED, TriggerType.SMS_RECEIVED,
    TriggerType.CALL_INCOMING, TriggerType.CALL_ENDED,
    TriggerType.NOTIFICATION_CONTAINS_TEXT -> TriggerCategory.COMMUNICATION

    TriggerType.EVERY_N_HOURS, TriggerType.TIME_WINDOW_INTERVAL -> TriggerCategory.TEMPS

    TriggerType.FULL_MOON, TriggerType.FRIDAY_13TH, TriggerType.PALINDROME_TIME -> TriggerCategory.FUN

    TriggerType.MANUAL -> TriggerCategory.MANUEL

    else -> EXTRA_TRIGGER_META[this]?.category ?: TriggerCategory.APPAREIL
}

/** Groupe visuel d'un bloc action/logique dans le sélecteur (étape 1 : choisir un groupe). */
enum class ActionCategory(val label: String) {
    COMMUNICATION("✉️ Communication"),
    MULTIMEDIA("🎨 Multimédia & fun"),
    SYSTEME("⚙️ Système & appareil"),
    INTERACTION("📱 Dans les applications"),
    VARIABLES("🔢 Variables & hasard"),
    LOGIQUE("🔀 Logique & contrôle"),
    CONNECTEURS("🌐 Connecteurs web"),
    CHAINAGE("⛓️ Chaînage"),
    FUN("🎉 Fun & surprises"),
    MUSIQUE("🎵 Musique & son"),
    NAVIGATION("🧭 Web & navigation"),
    INFOS("📊 Infos & capteurs"),
    TEXTE("🔤 Texte & fichiers")
}

private val COMMUNICATION_ACTIONS = setOf(
    ActionType.SEND_SMS, ActionType.SEND_MULTIPLE_SMS, ActionType.MAKE_CALL, ActionType.CALL_CONTACT,
    ActionType.SEND_EMAIL, ActionType.SHARE_TEXT, ActionType.SEND_NOTIFICATION,
    ActionType.SEND_MULTIPLE_NOTIFICATIONS, ActionType.SHOW_TOAST, ActionType.SPEAK_TEXT
)

private val MULTIMEDIA_ACTIONS = setOf(
    ActionType.VIBRATE, ActionType.VIBRATE_PATTERN, ActionType.CANCEL_VIBRATION, ActionType.PLAY_BEEP,
    ActionType.SHOW_RANDOM_MESSAGE, ActionType.TAKE_SCREENSHOT, ActionType.RECORD_AUDIO_CLIP,
    ActionType.OPEN_CAMERA, ActionType.CREATE_TIMER, ActionType.CREATE_ALARM, ActionType.TOGGLE_FLASHLIGHT,
    ActionType.RANDOM_DELAY, ActionType.MEDIA_PLAY_PAUSE
)

/** Blocs "fun / surprise" (quatrième vague) : chaotiques par nature, pratiques comme
 *  point de départ d'une vraie chaîne (ex : FLIP_COIN pose une variable qu'un bloc
 *  IF_VARIABLE_EQUALS peut ensuite tester). */
private val FUN_ACTIONS = setOf(
    ActionType.FLIP_COIN, ActionType.TELL_JOKE, ActionType.SET_WALLPAPER_COLOR,
    ActionType.OPEN_RANDOM_APP, ActionType.MYSTERY_BOX
)

fun ActionType.paletteCategory(): ActionCategory = when {
    EXTRA_ACTION_META[this] != null -> EXTRA_ACTION_META.getValue(this).category
    this in CONNECTOR_TYPES -> ActionCategory.CONNECTEURS
    this in CHAIN_TYPES -> ActionCategory.CHAINAGE
    this in FLOW_CONTROL_TYPES -> ActionCategory.LOGIQUE
    this in FUN_ACTIONS -> ActionCategory.FUN
    this in VARIABLE_TYPES -> ActionCategory.VARIABLES
    this in UI_INTERACTION_TYPES -> ActionCategory.INTERACTION
    this in COMMUNICATION_ACTIONS -> ActionCategory.COMMUNICATION
    this in MULTIMEDIA_ACTIONS -> ActionCategory.MULTIMEDIA
    else -> ActionCategory.SYSTEME
}

// ============================================================================
// Couleurs "façon Scratch" : chaque groupe de la palette a sa propre couleur
// vive et reconnaissable (comme Mouvement en bleu, Son en rose, Contrôle en
// orange...). Utilisées pour les logos ronds des listes, les blocs-puzzle et
// les puces de catégorie dans toute l'application.
// ============================================================================

fun TriggerCategory.color(): Int = when (this) {
    TriggerCategory.TEMPS -> 0xFFFFC93C.toInt()
    TriggerCategory.BATTERIE -> 0xFF4CD97B.toInt()
    TriggerCategory.RESEAU -> 0xFF4C97FF.toInt()
    TriggerCategory.APPAREIL -> 0xFF4CC9F0.toInt()
    TriggerCategory.APPLICATIONS -> 0xFF9966FF.toInt()
    TriggerCategory.COMMUNICATION -> 0xFFFF6FB0.toInt()
    TriggerCategory.MANUEL -> 0xFFFFAB19.toInt()
    TriggerCategory.FUN -> 0xFFFF3CAC.toInt()
}

fun ActionCategory.color(): Int = when (this) {
    ActionCategory.COMMUNICATION -> 0xFFFF6FB0.toInt()
    ActionCategory.MULTIMEDIA -> 0xFF9966FF.toInt()
    ActionCategory.SYSTEME -> 0xFF2BE0C9.toInt()
    ActionCategory.INTERACTION -> 0xFF4C97FF.toInt()
    ActionCategory.VARIABLES -> 0xFFFF8C1A.toInt()
    ActionCategory.LOGIQUE -> 0xFFFFC93C.toInt()
    ActionCategory.CONNECTEURS -> 0xFF4CC9F0.toInt()
    ActionCategory.CHAINAGE -> 0xFF7C5CFC.toInt()
    ActionCategory.FUN -> 0xFFFF3CAC.toInt()
    ActionCategory.MUSIQUE -> 0xFFCF63CF.toInt()
    ActionCategory.NAVIGATION -> 0xFF59C059.toInt()
    ActionCategory.INFOS -> 0xFF5CB1D6.toInt()
    ActionCategory.TEXTE -> 0xFF8F7CFF.toInt()
}

/** Petit pictogramme texte pour donner un visage à chaque engrenage, sans assets lourds. */
fun TriggerType.icon(): String = when (this) {
    TriggerType.TIME -> "⏰"
    TriggerType.INTERVAL -> "🔁"
    TriggerType.BOOT_COMPLETED -> "🔌"
    TriggerType.BATTERY_LOW -> "🪫"
    TriggerType.BATTERY_FULL -> "🔋"
    TriggerType.BATTERY_LEVEL -> "📊"
    TriggerType.APP_OPENED -> "📱"
    TriggerType.NOTIFICATION_RECEIVED -> "🔔"
    TriggerType.SMS_RECEIVED -> "✉️"
    TriggerType.WIFI_CONNECTED -> "📶"
    TriggerType.WIFI_DISCONNECTED -> "📴"
    TriggerType.BLUETOOTH_CONNECTED -> "🔷"
    TriggerType.HEADSET_CONNECTED -> "🎧"
    TriggerType.SCREEN_ON -> "🌞"
    TriggerType.SCREEN_OFF -> "🌚"
    TriggerType.DEVICE_UNLOCKED -> "🔓"
    TriggerType.AIRPLANE_MODE_ON -> "✈️"
    TriggerType.SHAKE -> "📳"
    TriggerType.CALL_INCOMING -> "📲"
    TriggerType.CALL_ENDED -> "📴"
    TriggerType.POWER_DISCONNECTED -> "🔌"
    TriggerType.HEADSET_DISCONNECTED -> "🎧"
    TriggerType.USB_CONNECTED -> "🔗"
    TriggerType.USB_DISCONNECTED -> "🔗"
    TriggerType.WIFI_CONNECTED_SSID -> "📶"
    TriggerType.RINGER_MODE_CHANGED -> "🔕"
    TriggerType.STORAGE_LOW -> "💾"
    TriggerType.MANUAL -> "👆"
    TriggerType.APP_CLOSED -> "🚪"
    TriggerType.APP_INSTALLED -> "📥"
    TriggerType.APP_UNINSTALLED -> "🗑️"
    TriggerType.CLIPBOARD_CHANGED -> "📋"
    TriggerType.MEMORY_LOW -> "🧠"
    TriggerType.WEEKDAY_TIME -> "🗓️"
    TriggerType.RANDOM_DAILY_TIME -> "🎲"
    TriggerType.COUNTDOWN_ONCE -> "⏱️"
    TriggerType.INTERVAL_LIMITED -> "🔂"
    TriggerType.MONTHLY_DATE -> "📆"
    TriggerType.YEARLY_DATE -> "🎂"
    TriggerType.RANDOM_INTERVAL -> "🔀"
    TriggerType.DARK_MODE_ON -> "🌑"
    TriggerType.DARK_MODE_OFF -> "☀️"
    TriggerType.POWER_SAVE_MODE_ON -> "🍃"
    TriggerType.POWER_SAVE_MODE_OFF -> "⚡"
    TriggerType.LANGUAGE_CHANGED -> "🌐"
    TriggerType.DATE_TIME_CHANGED -> "🕰️"
    TriggerType.DOCK_CONNECTED -> "🖥️"
    TriggerType.DOCK_DISCONNECTED -> "🖥️"
    TriggerType.AIRPLANE_MODE_OFF -> "✈️"
    TriggerType.APP_UPDATED -> "🆕"
    TriggerType.UI_TEXT_APPEARS -> "🔍"
    TriggerType.EVERY_N_HOURS -> "🕐"
    TriggerType.UI_TEXT_DISAPPEARS -> "🕳️"
    TriggerType.NOTIFICATION_CONTAINS_TEXT -> "🔎"
    TriggerType.TIME_WINDOW_INTERVAL -> "⏲️"
    TriggerType.FULL_MOON -> "🌕"
    TriggerType.FRIDAY_13TH -> "😱"
    TriggerType.PALINDROME_TIME -> "🔮"
    TriggerType.NFC_TAG_SCANNED -> "🏷️"
    else -> EXTRA_TRIGGER_META[this]?.icon ?: "⚙️"
}

fun ActionType.icon(): String = when (this) {
    ActionType.OPEN_APP -> "🚀"
    ActionType.SEND_NOTIFICATION -> "🔔"
    ActionType.SHOW_TOAST -> "💬"
    ActionType.VIBRATE -> "📳"
    ActionType.SET_VOLUME -> "🔊"
    ActionType.SET_BRIGHTNESS -> "🔆"
    ActionType.TOGGLE_FLASHLIGHT -> "🔦"
    ActionType.TOGGLE_WIFI -> "📶"
    ActionType.TOGGLE_BLUETOOTH -> "🔷"
    ActionType.SET_RINGER_MODE -> "🔕"
    ActionType.OPEN_URL -> "🔗"
    ActionType.OPEN_WIFI_SETTINGS -> "⚙️"
    ActionType.OPEN_BLUETOOTH_SETTINGS -> "⚙️"
    ActionType.OPEN_DND_SETTINGS -> "🌙"
    ActionType.SEND_SMS -> "✉️"
    ActionType.MAKE_CALL -> "📞"
    ActionType.SEND_EMAIL -> "📧"
    ActionType.COPY_CLIPBOARD -> "📋"
    ActionType.CREATE_ALARM -> "⏰"
    ActionType.WAKE_SCREEN -> "💡"
    ActionType.LOG_EVENT -> "📝"
    ActionType.WAIT -> "⏳"
    ActionType.CALL_CONTACT -> "📞"
    ActionType.ADD_CALENDAR_EVENT -> "📅"
    ActionType.SHARE_TEXT -> "📤"
    ActionType.TOGGLE_AUTO_ROTATE -> "🔃"
    ActionType.TOGGLE_DND -> "🌙"
    ActionType.TAKE_SCREENSHOT -> "🖼️"
    ActionType.RECORD_AUDIO_CLIP -> "🎙️"
    ActionType.GET_LOCATION -> "📍"
    ActionType.CLEAR_NOTIFICATIONS -> "🧹"
    ActionType.SET_RING_VOLUME -> "🔔"
    ActionType.CANCEL_VIBRATION -> "🚫"
    ActionType.SET_ALARM_VOLUME -> "⏰"
    ActionType.SPEAK_TEXT -> "🗣️"
    ActionType.CREATE_TIMER -> "⏲️"
    ActionType.OPEN_CAMERA -> "📷"
    ActionType.SET_SCREEN_TIMEOUT -> "🌓"
    ActionType.MEDIA_PLAY_PAUSE -> "⏯️"
    ActionType.HTTP_REQUEST -> "🌐"
    ActionType.DISCORD_WEBHOOK -> "🎮"
    ActionType.TELEGRAM_MESSAGE -> "✈️"
    ActionType.SLACK_WEBHOOK -> "💼"
    ActionType.IFTTT_WEBHOOK -> "🧩"
    ActionType.HOME_ASSISTANT_WEBHOOK -> "🏠"
    ActionType.ZAPIER_WEBHOOK -> "⚡"
    ActionType.MAKE_WEBHOOK -> "🧵"
    ActionType.NTFY_NOTIFICATION -> "📣"
    ActionType.PUSHOVER_NOTIFICATION -> "📮"
    ActionType.GOOGLE_SHEETS_WEBHOOK -> "📊"
    ActionType.NOTION_API -> "🗒️"
    ActionType.TRELLO_WEBHOOK -> "🗂️"
    ActionType.HTTP_REQUEST_ADVANCED -> "🛰️"
    ActionType.GET_WEATHER -> "⛅"
    ActionType.IF_BATTERY_ABOVE -> "🔀"
    ActionType.IF_BATTERY_BELOW -> "🔀"
    ActionType.IF_WIFI_CONNECTED -> "🔀"
    ActionType.IF_DAY_OF_WEEK -> "🔀"
    ActionType.IF_TIME_BETWEEN -> "🔀"
    ActionType.IF_APP_INSTALLED -> "🔀"
    ActionType.RANDOM_CHANCE -> "🎲"
    ActionType.REPEAT_START -> "🔄"
    ActionType.REPEAT_END -> "⏹️"
    ActionType.ELSE_BRANCH -> "↩️"
    ActionType.ENDIF -> "🔚"
    ActionType.STOP_AUTOMATION -> "🛑"
    ActionType.RUN_AUTOMATION -> "⛓️"
    ActionType.LOCK_SCREEN -> "🔒"
    ActionType.GO_HOME -> "🏠"
    ActionType.OPEN_RECENT_APPS -> "🗂️"
    ActionType.OPEN_APP_SETTINGS -> "⚙️"
    ActionType.SET_VARIABLE -> "🔢"
    ActionType.INCREMENT_VARIABLE -> "➕"
    ActionType.RANDOM_NUMBER -> "🎰"
    ActionType.SEND_MULTIPLE_SMS -> "📨"
    ActionType.SEND_MULTIPLE_NOTIFICATIONS -> "🔔"
    ActionType.PLAY_BEEP -> "🔊"
    ActionType.VIBRATE_PATTERN -> "📳"
    ActionType.SHOW_RANDOM_MESSAGE -> "🎱"
    ActionType.MATH_OPERATION -> "🧮"
    ActionType.RANDOM_CHOICE_VARIABLE -> "🎡"
    ActionType.LOAD_GLOBAL_VARIABLE -> "🌍"
    ActionType.JSON_EXTRACT_VARIABLE -> "🧩"
    ActionType.SET_LIST -> "📋"
    ActionType.LIST_APPEND -> "➕"
    ActionType.LIST_GET_ITEM -> "🔎"
    ActionType.LIST_LENGTH -> "🔢"
    ActionType.PAUSE_AUTOMATION_FOR -> "⏸️"
    ActionType.RANDOM_DELAY -> "🕰️"
    ActionType.IF_VARIABLE_ABOVE -> "🔀"
    ActionType.IF_VARIABLE_BELOW -> "🔀"
    ActionType.IF_VARIABLE_EQUALS -> "🔀"
    ActionType.REPEAT_WHILE_START -> "🔁"
    ActionType.RANDOM_RUN_AUTOMATION -> "🎯"
    ActionType.UI_CLICK_TEXT -> "👆"
    ActionType.UI_CLICK_DESCRIPTION -> "🎯"
    ActionType.UI_LONG_CLICK_TEXT -> "✋"
    ActionType.UI_INPUT_TEXT -> "⌨️"
    ActionType.UI_SCROLL_DOWN -> "⬇️"
    ActionType.UI_SCROLL_UP -> "⬆️"
    ActionType.UI_SWIPE -> "👉"
    ActionType.UI_PRESS_BACK -> "↩️"
    ActionType.UI_WAIT_FOR_TEXT -> "⏳"
    ActionType.UI_OPEN_APP_AND_CLICK -> "🚀"
    ActionType.IF_TEXT_VISIBLE -> "🔀"
    ActionType.UI_CLICK_INPUT_FIELD -> "🖊️"
    ActionType.UI_SEND_MESSAGE_IN_APP -> "💌"
    ActionType.UI_SEND_MULTIPLE_MESSAGES_IN_APP -> "📩"
    ActionType.UI_OPEN_APP_AND_SEND_MESSAGE -> "🚀"
    ActionType.FLIP_COIN -> "🪙"
    ActionType.TELL_JOKE -> "🤡"
    ActionType.SET_WALLPAPER_COLOR -> "🎨"
    ActionType.OPEN_RANDOM_APP -> "🎰"
    ActionType.MYSTERY_BOX -> "🎁"
    else -> EXTRA_ACTION_META[this]?.icon ?: "🧩"
}

data class TriggerBlock(
    val type: TriggerType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class ActionBlock(
    val type: ActionType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class Automation(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var enabled: Boolean = true,
    var trigger: TriggerBlock? = null,
    var actions: MutableList<ActionBlock> = mutableListOf(),
    // --- Statistiques d'exécution (mises à jour automatiquement par le moteur) ---
    var runCount: Int = 0,
    var lastRunAt: Long = 0L,
    var lastRunSuccess: Boolean = true,
    // --- Mise en pause temporaire (utilisée par le bloc PAUSE_AUTOMATION_FOR) ---
    var pausedUntil: Long = 0L
)
