package com.blockauto.app.model

import java.util.UUID

/**
 * Les blocs "déclencheur" disponibles dans la palette.
 * Chaque bloc est comme une pièce d'engrenage : il ne tourne qu'une fois
 * l'événement réel produit, même app fermée / téléphone verrouillé.
 */
enum class TriggerType(val label: String) {
    TIME("Heure précise"),
    INTERVAL("Toutes les X minutes"),
    BOOT_COMPLETED("Démarrage du téléphone"),
    BATTERY_LOW("Batterie faible (<15%)"),
    BATTERY_FULL("Branché sur secteur"),
    BATTERY_LEVEL("Niveau de batterie précis"),
    APP_OPENED("Application ouverte"),
    NOTIFICATION_RECEIVED("Notification reçue"),
    SMS_RECEIVED("SMS reçu"),
    WIFI_CONNECTED("Wi-Fi connecté"),
    WIFI_DISCONNECTED("Wi-Fi déconnecté"),
    BLUETOOTH_CONNECTED("Appareil Bluetooth connecté"),
    HEADSET_CONNECTED("Écouteurs branchés"),
    SCREEN_ON("Écran allumé"),
    SCREEN_OFF("Écran éteint"),
    DEVICE_UNLOCKED("Téléphone déverrouillé"),
    AIRPLANE_MODE_ON("Mode avion activé"),
    SHAKE("Secousse du téléphone"),
    CALL_INCOMING("Appel entrant"),
    CALL_ENDED("Appel terminé"),
    MANUAL("Déclenchement manuel uniquement")
}

/** Les blocs "action" et "logique" disponibles dans la palette. */
enum class ActionType(val label: String) {
    // --- Actions concrètes ---
    OPEN_APP("Ouvrir une application"),
    SEND_NOTIFICATION("Envoyer une notification"),
    SHOW_TOAST("Afficher un message"),
    VIBRATE("Faire vibrer"),
    SET_VOLUME("Régler le volume média"),
    SET_BRIGHTNESS("Régler la luminosité"),
    TOGGLE_FLASHLIGHT("Lampe torche"),
    TOGGLE_WIFI("Activer / désactiver le Wi-Fi"),
    TOGGLE_BLUETOOTH("Activer / désactiver le Bluetooth"),
    SET_RINGER_MODE("Régler le mode sonnerie"),
    OPEN_URL("Ouvrir un lien"),
    OPEN_WIFI_SETTINGS("Ouvrir réglages Wi-Fi"),
    OPEN_BLUETOOTH_SETTINGS("Ouvrir réglages Bluetooth"),
    OPEN_DND_SETTINGS("Ouvrir Ne pas déranger"),
    SEND_SMS("Envoyer un SMS"),
    MAKE_CALL("Passer un appel"),
    SEND_EMAIL("Envoyer un e-mail"),
    COPY_CLIPBOARD("Copier dans le presse-papiers"),
    CREATE_ALARM("Créer une alarme"),
    WAKE_SCREEN("Réveiller l'écran"),
    LOG_EVENT("Enregistrer dans l'historique"),
    WAIT("Attendre quelques secondes"),
    CALL_CONTACT("Appeler un contact"),
    ADD_CALENDAR_EVENT("Ajouter un événement au calendrier"),
    SHARE_TEXT("Partager du texte (menu de partage)"),
    TOGGLE_AUTO_ROTATE("Activer / désactiver la rotation auto"),
    TOGGLE_DND("Activer / désactiver Ne pas déranger"),
    TAKE_SCREENSHOT("Prendre une capture d'écran"),
    RECORD_AUDIO_CLIP("Enregistrer un extrait audio"),
    GET_LOCATION("Récupérer la position GPS"),

    // --- Blocs connecteurs (services externes) ---
    HTTP_REQUEST("Connecteur : requête HTTP générique"),
    DISCORD_WEBHOOK("Connecteur : webhook Discord"),
    TELEGRAM_MESSAGE("Connecteur : message Telegram (bot)"),
    SLACK_WEBHOOK("Connecteur : webhook Slack"),
    IFTTT_WEBHOOK("Connecteur : webhook IFTTT"),
    HOME_ASSISTANT_WEBHOOK("Connecteur : webhook Home Assistant"),

    // --- Blocs logiques (engrenages de contrôle) ---
    IF_BATTERY_ABOVE("Condition : batterie au-dessus de X%"),
    IF_BATTERY_BELOW("Condition : batterie en dessous de X%"),
    IF_WIFI_CONNECTED("Condition : Wi-Fi connecté"),
    IF_DAY_OF_WEEK("Condition : jour de la semaine"),
    IF_TIME_BETWEEN("Condition : heure comprise entre"),
    RANDOM_CHANCE("Chance aléatoire (%)"),
    REPEAT_START("Répéter les blocs suivants"),
    REPEAT_END("Fin de répétition"),
    STOP_AUTOMATION("Arrêter l'automatisation")
}

/** Catégorie visuelle d'un bloc, utilisée pour la couleur de l'engrenage dans l'atelier. */
enum class BlockCategory { TRIGGER, ACTION, LOGIC, CONNECTOR }

val FLOW_CONTROL_TYPES = setOf(
    ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW, ActionType.IF_WIFI_CONNECTED,
    ActionType.IF_DAY_OF_WEEK, ActionType.IF_TIME_BETWEEN, ActionType.RANDOM_CHANCE,
    ActionType.REPEAT_START, ActionType.REPEAT_END, ActionType.STOP_AUTOMATION
)

/** Blocs qui parlent à un service externe (webhook, bot, requête HTTP...). */
val CONNECTOR_TYPES = setOf(
    ActionType.HTTP_REQUEST, ActionType.DISCORD_WEBHOOK, ActionType.TELEGRAM_MESSAGE,
    ActionType.SLACK_WEBHOOK, ActionType.IFTTT_WEBHOOK, ActionType.HOME_ASSISTANT_WEBHOOK
)

fun ActionType.category(): BlockCategory = when {
    this in FLOW_CONTROL_TYPES -> BlockCategory.LOGIC
    this in CONNECTOR_TYPES -> BlockCategory.CONNECTOR
    else -> BlockCategory.ACTION
}

/** Petit pictogramme texte pour donner un visage à chaque engrenage, sans assets lourds. */
fun TriggerType.icon(): String = when (this) {
    TriggerType.TIME -> "⏰"
    TriggerType.INTERVAL -> "🔁"
    TriggerType.BOOT_COMPLETED -> "🔌"
    TriggerType.BATTERY_LOW -> "🪫"
    TriggerType.BATTERY_FULL -> "🔋"
    TriggerType.BATTERY_LEVEL -> "📊"
    TriggerType.APP_OPENED -> "📱"
    TriggerType.NOTIFICATION_RECEIVED -> "🔔"
    TriggerType.SMS_RECEIVED -> "✉️"
    TriggerType.WIFI_CONNECTED -> "📶"
    TriggerType.WIFI_DISCONNECTED -> "📴"
    TriggerType.BLUETOOTH_CONNECTED -> "🔷"
    TriggerType.HEADSET_CONNECTED -> "🎧"
    TriggerType.SCREEN_ON -> "🌞"
    TriggerType.SCREEN_OFF -> "🌚"
    TriggerType.DEVICE_UNLOCKED -> "🔓"
    TriggerType.AIRPLANE_MODE_ON -> "✈️"
    TriggerType.SHAKE -> "📳"
    TriggerType.CALL_INCOMING -> "📲"
    TriggerType.CALL_ENDED -> "📴"
    TriggerType.MANUAL -> "👆"
}

fun ActionType.icon(): String = when (this) {
    ActionType.OPEN_APP -> "🚀"
    ActionType.SEND_NOTIFICATION -> "🔔"
    ActionType.SHOW_TOAST -> "💬"
    ActionType.VIBRATE -> "📳"
    ActionType.SET_VOLUME -> "🔊"
    ActionType.SET_BRIGHTNESS -> "🔆"
    ActionType.TOGGLE_FLASHLIGHT -> "🔦"
    ActionType.TOGGLE_WIFI -> "📶"
    ActionType.TOGGLE_BLUETOOTH -> "🔷"
    ActionType.SET_RINGER_MODE -> "🔕"
    ActionType.OPEN_URL -> "🔗"
    ActionType.OPEN_WIFI_SETTINGS -> "⚙️"
    ActionType.OPEN_BLUETOOTH_SETTINGS -> "⚙️"
    ActionType.OPEN_DND_SETTINGS -> "🌙"
    ActionType.SEND_SMS -> "✉️"
    ActionType.MAKE_CALL -> "📞"
    ActionType.SEND_EMAIL -> "📧"
    ActionType.COPY_CLIPBOARD -> "📋"
    ActionType.CREATE_ALARM -> "⏰"
    ActionType.WAKE_SCREEN -> "💡"
    ActionType.LOG_EVENT -> "📝"
    ActionType.WAIT -> "⏳"
    ActionType.CALL_CONTACT -> "📞"
    ActionType.ADD_CALENDAR_EVENT -> "📅"
    ActionType.SHARE_TEXT -> "📤"
    ActionType.TOGGLE_AUTO_ROTATE -> "🔃"
    ActionType.TOGGLE_DND -> "🌙"
    ActionType.TAKE_SCREENSHOT -> "🖼️"
    ActionType.RECORD_AUDIO_CLIP -> "🎙️"
    ActionType.GET_LOCATION -> "📍"
    ActionType.HTTP_REQUEST -> "🌐"
    ActionType.DISCORD_WEBHOOK -> "🎮"
    ActionType.TELEGRAM_MESSAGE -> "✈️"
    ActionType.SLACK_WEBHOOK -> "💼"
    ActionType.IFTTT_WEBHOOK -> "🧩"
    ActionType.HOME_ASSISTANT_WEBHOOK -> "🏠"
    ActionType.IF_BATTERY_ABOVE -> "🔀"
    ActionType.IF_BATTERY_BELOW -> "🔀"
    ActionType.IF_WIFI_CONNECTED -> "🔀"
    ActionType.IF_DAY_OF_WEEK -> "🔀"
    ActionType.IF_TIME_BETWEEN -> "🔀"
    ActionType.RANDOM_CHANCE -> "🎲"
    ActionType.REPEAT_START -> "🔄"
    ActionType.REPEAT_END -> "⏹️"
    ActionType.STOP_AUTOMATION -> "🛑"
}

data class TriggerBlock(
    val type: TriggerType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class ActionBlock(
    val type: ActionType,
    val params: MutableMap<String, String> = mutableMapOf()
)

data class Automation(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var enabled: Boolean = true,
    var trigger: TriggerBlock? = null,
    var actions: MutableList<ActionBlock> = mutableListOf()
)
