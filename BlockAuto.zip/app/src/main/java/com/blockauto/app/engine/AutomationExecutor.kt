package com.blockauto.app.engine

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.text.ClipboardManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.storage.HistoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * Exécute une automatisation entière : c'est ici que les "engrenages" s'enclenchent
 * les uns après les autres. Gère aussi les blocs logiques (conditions, répétitions,
 * chance aléatoire, arrêt) pour permettre des scénarios complexes, pas juste une liste
 * plate d'actions.
 */
object AutomationExecutor {

    private const val CHANNEL_ID = "block_auto_channel"

    suspend fun run(context: Context, automation: Automation) {
        ensureChannel(context)
        executeSequence(context, automation.actions, automation)
        HistoryRepository.add(context, automation.name, "Automatisation exécutée avec succès")
    }

    /** Exécute une liste de blocs dans l'ordre, en gérant IF / REPEAT / RANDOM / STOP. */
    private suspend fun executeSequence(context: Context, actions: List<ActionBlock>, automation: Automation) {
        var i = 0
        while (i < actions.size) {
            val action = actions[i]
            when (action.type) {
                ActionType.REPEAT_START -> {
                    val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 100)
                    val endIndex = findMatchingRepeatEnd(actions, i)
                    val inner = actions.subList(i + 1, endIndex.coerceAtMost(actions.size))
                    repeat(count) { executeSequence(context, inner, automation) }
                    i = endIndex
                }
                ActionType.REPEAT_END -> { /* marqueur seulement */ }
                ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW,
                ActionType.IF_WIFI_CONNECTED, ActionType.IF_DAY_OF_WEEK,
                ActionType.IF_TIME_BETWEEN -> {
                    if (!evaluateCondition(context, action)) {
                        HistoryRepository.add(context, automation.name, "Condition non remplie, arrêt")
                        return
                    }
                }
                ActionType.RANDOM_CHANCE -> {
                    val pct = (action.params["percent"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
                    if ((0 until 100).random() >= pct) {
                        HistoryRepository.add(context, automation.name, "Coup de dé perdant ($pct%), arrêt")
                        return
                    }
                }
                ActionType.STOP_AUTOMATION -> return
                else -> {
                    try {
                        executeOne(context, action)
                    } catch (e: Exception) {
                        // On continue les blocs suivants même si l'un d'eux échoue
                    }
                }
            }
            i++
        }
    }

    /** Cherche l'index du REPEAT_END correspondant à un REPEAT_START (gère l'imbrication). */
    private fun findMatchingRepeatEnd(actions: List<ActionBlock>, startIndex: Int): Int {
        var depth = 1
        var j = startIndex + 1
        while (j < actions.size) {
            when (actions[j].type) {
                ActionType.REPEAT_START -> depth++
                ActionType.REPEAT_END -> {
                    depth--
                    if (depth == 0) return j
                }
                else -> {}
            }
            j++
        }
        return actions.size
    }

    private fun evaluateCondition(context: Context, action: ActionBlock): Boolean {
        return when (action.type) {
            ActionType.IF_BATTERY_ABOVE -> currentBatteryLevel(context) >= (action.params["level"]?.toIntOrNull() ?: 0)
            ActionType.IF_BATTERY_BELOW -> currentBatteryLevel(context) <= (action.params["level"]?.toIntOrNull() ?: 100)
            ActionType.IF_WIFI_CONNECTED -> isWifiConnected(context)
            ActionType.IF_DAY_OF_WEEK -> {
                val days = action.params["days"]?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
                val todayCode = when (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
                    Calendar.SUNDAY -> "SU"; Calendar.MONDAY -> "MO"; Calendar.TUESDAY -> "TU"
                    Calendar.WEDNESDAY -> "WE"; Calendar.THURSDAY -> "TH"; Calendar.FRIDAY -> "FR"
                    else -> "SA"
                }
                days.isEmpty() || days.contains(todayCode)
            }
            ActionType.IF_TIME_BETWEEN -> {
                val startH = action.params["start_hour"]?.toIntOrNull() ?: 0
                val startM = action.params["start_minute"]?.toIntOrNull() ?: 0
                val endH = action.params["end_hour"]?.toIntOrNull() ?: 23
                val endM = action.params["end_minute"]?.toIntOrNull() ?: 59
                val now = Calendar.getInstance()
                val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val startMinutes = startH * 60 + startM
                val endMinutes = endH * 60 + endM
                if (startMinutes <= endMinutes) nowMinutes in startMinutes..endMinutes
                else nowMinutes >= startMinutes || nowMinutes <= endMinutes
            }
            else -> true
        }
    }

    fun currentBatteryLevel(context: Context): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        return bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
    }

    fun isWifiConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private suspend fun executeOne(context: Context, action: ActionBlock) {
        when (action.type) {
            ActionType.OPEN_APP -> {
                val pkg = action.params["package"] ?: return
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchIntent?.let { context.startActivity(it) }
            }

            ActionType.SEND_NOTIFICATION -> {
                val title = action.params["title"]?.ifBlank { "Automatisation" } ?: "Automatisation"
                val text = action.params["text"] ?: ""
                val notif = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), notif)
            }

            ActionType.SHOW_TOAST -> withContext(Dispatchers.Main) {
                Toast.makeText(context, action.params["text"] ?: "", Toast.LENGTH_LONG).show()
            }

            ActionType.VIBRATE -> {
                val ms = action.params["duration_ms"]?.toLongOrNull() ?: 500L
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }

            ActionType.SET_VOLUME -> {
                val level = action.params["level"]?.toIntOrNull() ?: 5
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0, max), 0)
            }

            ActionType.SET_BRIGHTNESS -> {
                if (Settings.System.canWrite(context)) {
                    val level = action.params["level"]?.toIntOrNull() ?: 128
                    Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0, 255))
                }
            }

            ActionType.TOGGLE_FLASHLIGHT -> {
                try {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val camId = cm.cameraIdList.firstOrNull()
                    val turnOn = action.params["state"] != "off"
                    if (camId != null) cm.setTorchMode(camId, turnOn)
                } catch (e: Exception) { /* pas de flash disponible */ }
            }

            ActionType.TOGGLE_WIFI -> {
                try {
                    // Depuis Android 10, seul le panneau système peut couper le Wi-Fi :
                    // on ouvre directement le panneau rapide pour laisser l'utilisateur confirmer.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val panel = Intent(Settings.Panel.ACTION_WIFI)
                        panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(panel)
                    } else {
                        @Suppress("DEPRECATION")
                        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                        @Suppress("DEPRECATION")
                        wm.isWifiEnabled = action.params["state"] != "off"
                    }
                } catch (e: Exception) { /* ignoré */ }
            }

            ActionType.TOGGLE_BLUETOOTH -> {
                try {
                    val adapter = BluetoothAdapter.getDefaultAdapter()
                    if (action.params["state"] == "off") adapter?.disable() else adapter?.enable()
                } catch (e: Exception) { /* nécessite BLUETOOTH_CONNECT selon la version */ }
            }

            ActionType.SET_RINGER_MODE -> {
                try {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.ringerMode = when (action.params["mode"]) {
                        "silent" -> AudioManager.RINGER_MODE_SILENT
                        "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                        else -> AudioManager.RINGER_MODE_NORMAL
                    }
                } catch (e: Exception) { /* accès "Ne pas déranger" requis sur certains appareils */ }
            }

            ActionType.OPEN_URL -> {
                val url = action.params["url"] ?: return
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_WIFI_SETTINGS -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_BLUETOOTH_SETTINGS -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.OPEN_DND_SETTINGS -> {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            ActionType.SEND_SMS -> {
                val number = action.params["number"] ?: return
                val text = action.params["text"] ?: ""
                try {
                    val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                        context.getSystemService(SmsManager::class.java)
                    else @Suppress("DEPRECATION") SmsManager.getDefault()
                    sms?.sendTextMessage(number, null, text, null, null)
                    // Rend le message visible dans l'appli Messages par défaut (dossier "Envoyés"),
                    // sinon un SMS envoyé par BlockAuto n'apparaît nulle part ailleurs que dans l'app.
                    insertIntoSentSms(context, number, text)
                } catch (e: Exception) { /* SMS non envoyé (numéro invalide, pas de réseau...) */ }
            }

            ActionType.MAKE_CALL -> {
                val number = action.params["number"] ?: return
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { context.startActivity(intent) } catch (e: SecurityException) { /* permission CALL_PHONE refusée */ }
            }

            ActionType.SEND_EMAIL -> {
                val to = action.params["to"] ?: ""
                val subject = action.params["subject"] ?: ""
                val body = action.params["body"] ?: ""
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$to"))
                intent.putExtra(Intent.EXTRA_SUBJECT, subject)
                intent.putExtra(Intent.EXTRA_TEXT, body)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { context.startActivity(intent) } catch (e: Exception) { /* aucune app mail */ }
            }

            ActionType.COPY_CLIPBOARD -> {
                val text = action.params["text"] ?: ""
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.text = text
            }

            ActionType.CREATE_ALARM -> {
                val hour = action.params["hour"]?.toIntOrNull() ?: return
                val minute = action.params["minute"]?.toIntOrNull() ?: 0
                val label = action.params["label"] ?: "BlockAuto"
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try { context.startActivity(intent) } catch (e: Exception) { /* aucune app horloge */ }
            }

            ActionType.WAKE_SCREEN -> {
                try {
                    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                    @Suppress("DEPRECATION")
                    val wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                        "BlockAuto:wakeScreen"
                    )
                    wl.acquire(10_000)
                    delay(10_000)
                    if (wl.isHeld) wl.release()
                } catch (e: Exception) { /* ignoré */ }
            }

            ActionType.LOG_EVENT -> {
                HistoryRepository.add(context, "Bloc manuel", action.params["text"] ?: "Événement")
            }

            ActionType.WAIT -> {
                val sec = action.params["seconds"]?.toLongOrNull() ?: 1L
                delay(sec * 1000)
            }

            else -> { /* blocs logiques gérés dans executeSequence */ }
        }
    }

    /**
     * Insère le SMS envoyé dans le fournisseur de contenu "Sms.Sent" du système
     * pour qu'il apparaisse dans l'appli Messages par défaut du téléphone,
     * exactement comme si l'utilisateur l'avait tapé lui-même.
     * Sur certains téléphones (selon le fabricant), seule l'appli SMS par défaut
     * peut écrire dans ce fournisseur : l'opération échoue alors silencieusement,
     * mais le SMS part quand même normalement.
     */
    private fun insertIntoSentSms(context: Context, number: String, text: String) {
        try {
            val values = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, number)
                put(Telephony.Sms.BODY, text)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            }
            context.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, values)
        } catch (e: Exception) {
            // Non bloquant : voir commentaire ci-dessus.
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "BlockAuto", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }
}
