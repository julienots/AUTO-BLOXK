package com.blockauto.app.engine

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.content.ClipboardManager
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.CONDITION_TYPES
import com.blockauto.app.model.REPEAT_OPEN_TYPES
import com.blockauto.app.services.AppWatcherAccessibilityService
import com.blockauto.app.storage.AutomationRepository
import com.blockauto.app.storage.HistoryRepository
import com.blockauto.app.storage.VariableStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar

/**
 * Exécute une automatisation entière : c'est ici que les "engrenages" s'enclenchent
 * les uns après les autres. Gère aussi les blocs logiques (conditions, répétitions,
 * chance aléatoire, arrêt) pour permettre des scénarios complexes, pas juste une liste
 * plate d'actions.
 */
class ActionExecutionException(message: String, cause: Throwable? = null) : RuntimeException(message, cause)

object AutomationExecutor {

    private const val CHANNEL_ID = "block_auto_channel"

    /** Profondeur maximale d'une chaîne d'automatisations (A → B → C...) pour éviter
     *  qu'une boucle de chaînage (A relance B qui relance A...) ne tourne à l'infini. */
    private const val MAX_CHAIN_DEPTH = 8

    suspend fun run(
        context: Context,
        automation: Automation,
        chainDepth: Int = 0,
        initialVariables: Map<String, String> = emptyMap()
    ) {
        ensureChannel(context)
        // Variables partagées entre les blocs d'une même exécution (ex: {lat}/{lon}/{location}
        // remplis par le bloc "Récupérer la position GPS", ou {sms_sender}/{sms_body}/{notif_title}/
        // {notif_text}/{opened_package} posés par le déclencheur qui a lancé cette automatisation)
        // et réutilisables dans tous les blocs suivants.
        val variables = mutableMapOf<String, String>().apply { putAll(initialVariables) }
        runWithSharedVariables(context, automation, chainDepth, variables)
    }

    /**
     * Cœur de l'exécution, en prenant directement la map de variables de l'appelant (au lieu
     * d'en recopier une nouvelle comme le faisait [run]). C'est ce qui permet aux blocs
     * "Chaîner vers une automatisation" de faire de VRAIES chaînes à valeurs : une variable
     * modifiée par l'automatisation B (chaînée depuis A) reste visible par A une fois B
     * terminée, comme une valeur de retour de fonction — alors qu'avant ce correctif, B ne
     * recevait qu'une copie figée des variables de A et ses propres changements étaient perdus.
     */
    private suspend fun runWithSharedVariables(
        context: Context,
        automation: Automation,
        chainDepth: Int,
        variables: MutableMap<String, String>
    ) {
        if (chainDepth > MAX_CHAIN_DEPTH) {
            HistoryRepository.add(context, automation.name, "Chaîne d'automatisations trop profonde, arrêt de sécurité")
            return
        }
        try {
            executeSequence(context, automation.actions, automation, variables, chainDepth)
            HistoryRepository.add(context, automation.name, "Automatisation exécutée")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            HistoryRepository.add(context, automation.name, "Échec : ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Exécute une liste de blocs dans l'ordre, en gérant IF / SINON / FIN DE CONDITION,
     * REPEAT / RÉPÉTER TANT QUE, RANDOM, STOP et le chaînage (simple ou aléatoire) vers
     * d'autres automatisations.
     *
     * Pour les blocs "Si..." (IF_*), deux comportements coexistent pour rester
     * compatible avec les automatisations créées avant l'ajout du "Sinon" :
     *  - S'il existe un bloc "Fin de condition" correspondant plus loin, on a un
     *    vrai bloc Si / Sinon / Fin : seule la branche pertinente s'exécute, puis
     *    l'automatisation continue normalement après le "Fin de condition".
     *  - Sinon (ancien style), la condition se comporte comme avant : si elle est
     *    fausse, on arrête l'automatisation entière.
     */
    private suspend fun executeSequence(
        context: Context,
        actions: List<ActionBlock>,
        automation: Automation,
        variables: MutableMap<String, String>,
        chainDepth: Int
    ) {
        var i = 0
        while (i < actions.size) {
            val action = actions[i]
            when (action.type) {
                ActionType.REPEAT_START -> {
                    val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 100)
                    val endIndex = findMatchingEnd(actions, i, REPEAT_OPEN_TYPES, ActionType.REPEAT_END)
                    val inner = actions.subList(i + 1, endIndex.coerceAtMost(actions.size))
                    repeat(count) { executeSequence(context, inner, automation, variables, chainDepth) }
                    i = endIndex
                }
                ActionType.REPEAT_WHILE_START -> {
                    // Boucle "façon Scratch" pilotée par une valeur : tourne tant que la variable
                    // reste au-dessus/en dessous d'un seuil. Bornée à max_iterations (par défaut 50)
                    // pour ne jamais tourner à l'infini si la variable n'évolue jamais.
                    val name = action.params["name"]?.trim().orEmpty()
                    val threshold = action.params["threshold"]?.toDoubleOrNull() ?: 0.0
                    val operator = action.params["operator"] ?: "below"
                    val maxIterations = (action.params["max_iterations"]?.toIntOrNull() ?: 50).coerceIn(1, 500)
                    val endIndex = findMatchingEnd(actions, i, REPEAT_OPEN_TYPES, ActionType.REPEAT_END)
                    val inner = actions.subList(i + 1, endIndex.coerceAtMost(actions.size))
                    var iterations = 0
                    while (iterations < maxIterations) {
                        val current = variables[name]?.toDoubleOrNull() ?: 0.0
                        val conditionTrue = if (operator == "above") current > threshold else current < threshold
                        if (!conditionTrue) break
                        executeSequence(context, inner, automation, variables, chainDepth)
                        iterations++
                    }
                    if (iterations >= maxIterations) {
                        HistoryRepository.add(context, automation.name, "Boucle « tant que » arrêtée après $maxIterations tours (sécurité)")
                    }
                    i = endIndex
                }
                ActionType.REPEAT_END -> { /* marqueur seulement */ }
                ActionType.ELSE_BRANCH, ActionType.ENDIF -> { /* atteints seulement si mal placés : ignorés */ }
                ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW,
                ActionType.IF_WIFI_CONNECTED, ActionType.IF_DAY_OF_WEEK,
                ActionType.IF_TIME_BETWEEN, ActionType.IF_VARIABLE_ABOVE,
                ActionType.IF_VARIABLE_BELOW, ActionType.IF_VARIABLE_EQUALS,
                ActionType.IF_TEXT_VISIBLE -> {
                    val bounds = findIfBlockBounds(actions, i)
                    val conditionTrue = evaluateCondition(context, action, variables)
                    if (bounds == null) {
                        // Ancien style : pas de "Fin de condition" -> on arrête tout si c'est faux.
                        if (!conditionTrue) {
                            HistoryRepository.add(context, automation.name, "Condition non remplie, arrêt")
                            return
                        }
                    } else {
                        val (elseIndex, endIndex) = bounds
                        if (conditionTrue) {
                            val thenEnd = elseIndex ?: endIndex
                            val thenBranch = actions.subList(i + 1, thenEnd.coerceAtMost(actions.size))
                            executeSequence(context, thenBranch, automation, variables, chainDepth)
                        } else if (elseIndex != null) {
                            val elseBranch = actions.subList(elseIndex + 1, endIndex.coerceAtMost(actions.size))
                            executeSequence(context, elseBranch, automation, variables, chainDepth)
                        }
                        i = endIndex
                    }
                }
                ActionType.RANDOM_CHANCE -> {
                    val pct = (action.params["percent"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
                    if ((0 until 100).random() >= pct) {
                        HistoryRepository.add(context, automation.name, "Coup de dé perdant ($pct%), arrêt")
                        return
                    }
                }
                ActionType.STOP_AUTOMATION -> return
                ActionType.RUN_AUTOMATION -> {
                    val targetId = action.params["automation_id"]
                    val target = targetId?.let { AutomationRepository.get(context, it) }
                    if (target != null) {
                        // Bloc "argument" facultatif : pose une variable AVANT de lancer la chaîne,
                        // comme un paramètre passé à une fonction (ex: input_name="mode", input_value="silencieux").
                        val inputName = action.params["input_name"]?.trim()
                        if (!inputName.isNullOrBlank()) {
                            variables[inputName] = subst(action.params["input_value"] ?: "", variables)
                        }
                        HistoryRepository.add(context, automation.name, "Chaîne vers « ${target.name} »")
                        runWithSharedVariables(context, target, chainDepth + 1, variables)
                    }
                }
                ActionType.RANDOM_RUN_AUTOMATION -> {
                    // Chaîne "au hasard" vers l'une des automatisations listées (ids séparés par
                    // des virgules) — fun pour varier un scénario sans dupliquer les blocs.
                    val ids = action.params["automation_ids"]?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }.orEmpty()
                    val targets = ids.mapNotNull { AutomationRepository.get(context, it) }
                    if (targets.isNotEmpty()) {
                        val target = targets.random()
                        HistoryRepository.add(context, automation.name, "Chaîne aléatoire vers « ${target.name} »")
                        runWithSharedVariables(context, target, chainDepth + 1, variables)
                    }
                }
                else -> {
                    try {
                        executeOne(context, action, variables)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Une action défaillante ne doit jamais être annoncée comme réussie.
                        // On journalise le message réel, puis on continue les blocs suivants :
                        // cela permet à une chaîne d'automatisations de rester exploitable même
                        // si une action optionnelle est refusée par Android.
                        HistoryRepository.add(
                            context,
                            automation.name,
                            "Bloc « ${action.type.label} » en échec : ${e.message ?: e.javaClass.simpleName}"
                        )
                    }
                }
            }
            i++
        }
    }

    /** Remplace {nom_variable} par sa valeur connue (ex: {lat}, {lon}, {location}). */
    private fun subst(text: String, variables: Map<String, String>): String {
        var result = text
        for ((key, value) in variables) result = result.replace("{$key}", value)
        return result
    }

    private fun hasPerm(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    /**
     * Depuis Android 10, un service en arrière-plan (donc une automatisation déclenchée
     * app fermée : SMS reçu, batterie faible, démarrage...) n'a PAS le droit d'ouvrir une
     * Activity, sauf exemption. On utilise ici la même astuce que les autres apps
     * d'automatisation (Tasker, MacroDroid) : si la permission "Afficher par-dessus les
     * autres applications" est accordée, on pose une fenêtre overlay invisible d'1 pixel
     * juste avant l'ouverture, ce qui donne à Android la preuve que l'app est "visible"
     * et débloque l'ouverture. Sans cette permission, l'action est tentée quand même
     * (elle marchera si l'app vient d'être utilisée récemment) mais peut être silencieusement
     * ignorée par le système sur un déclenchement 100% arrière-plan.
     */
    private fun startActivityWithBackgroundExemption(context: Context, launch: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && Settings.canDrawOverlays(context)) {
            var wm: WindowManager? = null
            var overlay: View? = null
            try {
                wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                overlay = View(context)
                val params = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.TRANSLUCENT
                )
                wm.addView(overlay, params)
            } catch (e: Exception) {
                wm = null
                overlay = null
            }
            try {
                launch()
            } finally {
                try { if (overlay != null) wm?.removeView(overlay) } catch (e: Exception) { /* déjà retirée */ }
            }
        } else {
            launch()
        }
    }

    /** Cherche l'index du bloc de fin (REPEAT_END, etc.) correspondant à un bloc de début (gère l'imbrication).
     *  [openTypes] regroupe tous les blocs qui augmentent la profondeur (ex: REPEAT_START ET
     *  REPEAT_WHILE_START partagent le même bloc de fermeture REPEAT_END, et peuvent s'imbriquer
     *  l'un dans l'autre). */
    private fun findMatchingEnd(actions: List<ActionBlock>, startIndex: Int, openTypes: Set<ActionType>, closeType: ActionType): Int {
        var depth = 1
        var j = startIndex + 1
        while (j < actions.size) {
            when (actions[j].type) {
                in openTypes -> depth++
                closeType -> {
                    depth--
                    if (depth == 0) return j
                }
                else -> {}
            }
            j++
        }
        return actions.size
    }

    /**
     * Cherche les bornes d'un bloc "Si" à partir de son index : le "Sinon" (optionnel)
     * et le "Fin de condition" correspondants, en gérant l'imbrication de blocs Si / Répéter.
     * Retourne null si aucun "Fin de condition" ne referme ce bloc (automatisation ancien style).
     */
    private fun findIfBlockBounds(actions: List<ActionBlock>, ifIndex: Int): Pair<Int?, Int>? {
        var depth = 1
        var elseIndex: Int? = null
        var j = ifIndex + 1
        while (j < actions.size) {
            when {
                actions[j].type in CONDITION_TYPES || actions[j].type in REPEAT_OPEN_TYPES -> depth++
                actions[j].type == ActionType.ENDIF || actions[j].type == ActionType.REPEAT_END -> {
                    depth--
                    if (depth == 0) return elseIndex to j
                }
                actions[j].type == ActionType.ELSE_BRANCH && depth == 1 -> elseIndex = j
            }
            j++
        }
        return null
    }

    private fun evaluateCondition(context: Context, action: ActionBlock, variables: Map<String, String>): Boolean {
        return when (action.type) {
            ActionType.IF_BATTERY_ABOVE -> currentBatteryLevel(context) >= (action.params["level"]?.toIntOrNull() ?: 0)
            ActionType.IF_BATTERY_BELOW -> currentBatteryLevel(context) <= (action.params["level"]?.toIntOrNull() ?: 100)
            ActionType.IF_WIFI_CONNECTED -> isWifiConnected(context)
            ActionType.IF_TEXT_VISIBLE -> {
                val text = subst(action.params["text"] ?: "", variables)
                text.isNotBlank() && AppWatcherAccessibilityService.isTextVisible(text)
            }
            ActionType.IF_VARIABLE_ABOVE -> {
                val name = action.params["name"]?.trim().orEmpty()
                val threshold = action.params["value"]?.toDoubleOrNull() ?: 0.0
                (variables[name]?.toDoubleOrNull() ?: 0.0) > threshold
            }
            ActionType.IF_VARIABLE_BELOW -> {
                val name = action.params["name"]?.trim().orEmpty()
                val threshold = action.params["value"]?.toDoubleOrNull() ?: 0.0
                (variables[name]?.toDoubleOrNull() ?: 0.0) < threshold
            }
            ActionType.IF_VARIABLE_EQUALS -> {
                val name = action.params["name"]?.trim().orEmpty()
                val expected = action.params["value"] ?: ""
                val actual = variables[name] ?: ""
                // Compare numériquement si les deux valeurs sont des nombres (pour que "5" == "5.0"),
                // sinon compare le texte tel quel (insensible à la casse).
                val aNum = actual.toDoubleOrNull()
                val eNum = expected.toDoubleOrNull()
                if (aNum != null && eNum != null) aNum == eNum else actual.equals(expected, ignoreCase = true)
            }
            ActionType.IF_DAY_OF_WEEK -> {
                val days = action.params["days"]?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
                val todayCode = when (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
                    Calendar.SUNDAY -> "SU"; Calendar.MONDAY -> "MO"; Calendar.TUESDAY -> "TU"
                    Calendar.WEDNESDAY -> "WE"; Calendar.THURSDAY -> "TH"; Calendar.FRIDAY -> "FR"
                    else -> "SA"
                }
                days.isEmpty() || days.contains(todayCode)
            }
            ActionType.IF_TIME_BETWEEN -> {
                val startH = action.params["start_hour"]?.toIntOrNull() ?: 0
                val startM = action.params["start_minute"]?.toIntOrNull() ?: 0
                val endH = action.params["end_hour"]?.toIntOrNull() ?: 23
                val endM = action.params["end_minute"]?.toIntOrNull() ?: 59
                val now = Calendar.getInstance()
                val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val startMinutes = startH * 60 + startM
                val endMinutes = endH * 60 + endM
                if (startMinutes <= endMinutes) nowMinutes in startMinutes..endMinutes
                else nowMinutes >= startMinutes || nowMinutes <= endMinutes
            }
            else -> true
        }
    }

    fun currentBatteryLevel(context: Context): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        return bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
    }

    fun isWifiConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private suspend fun executeOne(context: Context, action: ActionBlock, variables: MutableMap<String, String>) {
        when (action.type) {
            ActionType.OPEN_APP -> {
                val pkg = action.params["package"]?.trim().orEmpty()
                if (pkg.isBlank()) throw ActionExecutionException("Aucune application sélectionnée")
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                    ?: throw ActionExecutionException("Application introuvable ou non lançable : $pkg")
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(launchIntent) }
            }

            ActionType.SEND_NOTIFICATION -> {
                val title = subst(action.params["title"]?.ifBlank { "Automatisation" } ?: "Automatisation", variables)
                val text = subst(action.params["text"] ?: "", variables)
                // "silent" : notification affichée normalement mais sans son ni vibration,
                // pour les automatisations "fun sans bruit" (ex: la nuit, en réunion...).
                // setSilent(true) est la façon recommandée de couper le son d'une notification
                // ponctuelle sans toucher au réglage du canal (qui reste sonore pour les autres).
                val silent = action.params["silent"] == "true"
                val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setPriority(if (silent) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                if (silent) {
                    builder.setSilent(true)
                    builder.setSound(null)
                    builder.setVibrate(longArrayOf(0L))
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPerm(context, Manifest.permission.POST_NOTIFICATIONS)) {
                    throw ActionExecutionException("Autorise les notifications de BlockAuto")
                }
                NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), builder.build())
            }

            ActionType.SHOW_TOAST -> withContext(Dispatchers.Main) {
                Toast.makeText(context, subst(action.params["text"] ?: "", variables), Toast.LENGTH_LONG).show()
            }

            ActionType.VIBRATE -> {
                // coerceIn(100, 20000) : une durée de 0 ou négative ne vibre pas du tout sur
                // certains appareils, et VibrationEffect.createOneShot exige de toute façon un
                // minimum > 0 sinon il lève une IllegalArgumentException.
                val ms = (action.params["duration_ms"]?.toLongOrNull() ?: 500L).coerceIn(100, 20_000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                }
                // BUG CORRIGÉ : vibrate() ne fait que transmettre l'ordre au vibreur et rend la
                // main immédiatement. Sans attendre ici, l'automatisation continuait aussitôt
                // (service arrêté, action suivante lancée...), et sur beaucoup d'appareils Android
                // coupe la vibration en cours dès que le processus est mis en veille juste après —
                // exactement comme WAKE_SCREEN et RECORD_AUDIO_CLIP le font déjà pour leur propre
                // durée. Résultat concret avant ce correctif : une vibration de 500 ms (la valeur
                // par défaut, assez courte pour se terminer avant que ça n'arrive) semblait
                // fonctionner, mais toute durée personnalisée plus longue était tronquée.
                delay(ms)
            }

            ActionType.VIBRATE_PATTERN -> {
                // Motif de vibrations séparées par des virgules, en millisecondes,
                // alternant pause/vibration : "0,150,80,150,80,150" par ex. pour un triple buzz.
                // Un préréglage "sos" est aussi accepté pour un vrai SOS morse (··· −−− ···).
                val raw = action.params["pattern"]?.trim().orEmpty()
                val pattern: LongArray = if (raw.equals("sos", ignoreCase = true)) {
                    val dot = 150L; val dash = 400L; val gap = 200L; val letterGap = 500L
                    listOf(
                        0, dot, gap, dot, gap, dot, letterGap,
                        dash, gap, dash, gap, dash, letterGap,
                        dot, gap, dot, gap, dot
                    ).map { it }.toLongArray()
                } else {
                    val parts = raw.split(",").mapNotNull { it.trim().toLongOrNull()?.coerceIn(0, 20_000) }
                    if (parts.isEmpty()) longArrayOf(0, 200, 100, 200) else parts.toLongArray()
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    @Suppress("DEPRECATION")
                    v.vibrate(pattern, -1)
                }
                // On attend la durée totale du motif pour la même raison que VIBRATE :
                // sans ça, le service peut se terminer et couper la vibration en cours.
                delay(pattern.sum().coerceIn(0, 20_000))
            }

            ActionType.PLAY_BEEP -> {
                // Petit bip système "façon jeu" via ToneGenerator, sans fichier audio à fournir.
                val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 10)
                val toneGen = android.media.ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                try {
                    repeat(count) {
                        toneGen.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 200)
                        delay(280)
                    }
                } finally {
                    toneGen.release()
                }
            }

            ActionType.SHOW_RANDOM_MESSAGE -> withContext(Dispatchers.Main) {
                // Liste de messages séparés par "|", un seul est tiré au hasard et affiché —
                // pratique pour des automatisations "fun" qui ne disent jamais deux fois la même chose.
                val choices = (action.params["messages"] ?: "")
                    .split("|").map { it.trim() }.filter { it.isNotEmpty() }
                val chosen = if (choices.isEmpty()) "" else choices.random()
                variables["random_message"] = chosen
                if (chosen.isNotBlank()) Toast.makeText(context, chosen, Toast.LENGTH_LONG).show()
            }

            ActionType.SET_VARIABLE -> {
                // Bloc "façon Scratch" : crée/écrase une variable réutilisable dans {nom}
                // par tous les blocs suivants de cette exécution (y compris après un chaînage).
                // Si "global"="true", la valeur est aussi persistée sur disque et devient lisible
                // par n'importe quelle autre automatisation via le bloc "Variable globale : charger".
                val name = action.params["name"]?.trim().orEmpty()
                if (name.isBlank()) throw ActionExecutionException("Donne un nom à la variable")
                val value = subst(action.params["value"] ?: "", variables)
                variables[name] = value
                if (action.params["global"] == "true") VariableStore.set(context, name, value)
            }

            ActionType.INCREMENT_VARIABLE -> {
                val name = action.params["name"]?.trim().orEmpty()
                if (name.isBlank()) throw ActionExecutionException("Donne un nom à la variable")
                val amount = action.params["amount"]?.toDoubleOrNull() ?: 1.0
                val isGlobal = action.params["global"] == "true"
                val current = (if (isGlobal) VariableStore.get(context, name) else variables[name])?.toDoubleOrNull() ?: 0.0
                val next = current + amount
                // Affiche un entier propre si le résultat n'a pas de décimales (cas le plus courant :
                // compteurs de type "nombre de fois").
                val nextText = if (next == next.toLong().toDouble()) next.toLong().toString() else next.toString()
                variables[name] = nextText
                if (isGlobal) VariableStore.set(context, name, nextText)
            }

            ActionType.RANDOM_NUMBER -> {
                val name = action.params["name"]?.trim().orEmpty()
                if (name.isBlank()) throw ActionExecutionException("Donne un nom à la variable")
                val min = action.params["min"]?.toIntOrNull() ?: 1
                val max = action.params["max"]?.toIntOrNull() ?: 100
                val lo = minOf(min, max)
                val hi = maxOf(min, max)
                variables[name] = (lo..hi).random().toString()
            }

            ActionType.MATH_OPERATION -> {
                // Calcul simple entre deux valeurs (nombres littéraux ou {variable}) écrit dans
                // une variable résultat — de quoi construire des scores, des compteurs de temps,
                // des conversions, etc. dans une chaîne d'automatisations.
                val resultName = action.params["result_name"]?.trim().orEmpty()
                if (resultName.isBlank()) throw ActionExecutionException("Donne un nom à la variable résultat")
                val a = subst(action.params["a"] ?: "0", variables).toDoubleOrNull() ?: 0.0
                val b = subst(action.params["b"] ?: "0", variables).toDoubleOrNull() ?: 0.0
                val op = action.params["operator"] ?: "+"
                val result = when (op) {
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b == 0.0) 0.0 else a / b
                    "%" -> if (b == 0.0) 0.0 else a % b
                    else -> a + b
                }
                variables[resultName] = if (result == result.toLong().toDouble()) result.toLong().toString() else result.toString()
            }

            ActionType.RANDOM_CHOICE_VARIABLE -> {
                // Comme "Afficher un message au hasard", mais silencieux : stocke le choix dans
                // une variable pour l'utiliser ensuite dans un texte, une condition ou une chaîne.
                val resultName = action.params["result_name"]?.trim().orEmpty()
                if (resultName.isBlank()) throw ActionExecutionException("Donne un nom à la variable résultat")
                val choices = (action.params["choices"] ?: "").split("|").map { it.trim() }.filter { it.isNotEmpty() }
                if (choices.isNotEmpty()) variables[resultName] = choices.random()
            }

            ActionType.LOAD_GLOBAL_VARIABLE -> {
                // Recharge dans une variable "locale" (utilisable par {nom} dans ce bloc et les
                // suivants) une valeur globale posée par n'importe quelle automatisation via
                // "Variable : définir une valeur" avec l'option "globale" activée.
                val name = action.params["name"]?.trim().orEmpty()
                if (name.isBlank()) throw ActionExecutionException("Donne un nom à la variable globale")
                variables[name] = VariableStore.get(context, name) ?: (action.params["default"] ?: "0")
            }

            ActionType.RANDOM_DELAY -> {
                val minSeconds = (action.params["min_seconds"]?.toIntOrNull() ?: 1).coerceAtLeast(0)
                val maxSeconds = (action.params["max_seconds"]?.toIntOrNull() ?: 5).coerceAtLeast(minSeconds)
                val seconds = (minSeconds..maxSeconds).random()
                delay(seconds * 1000L)
            }

            ActionType.SEND_MULTIPLE_SMS -> {
                // Envoie le même message N fois de suite au même numéro, avec une pause entre
                // chaque envoi. {n} dans le texte est remplacé par le numéro d'ordre du message
                // (1, 2, 3...), pratique pour des séries de rappels ("Rappel 1/5", "Rappel 2/5"...).
                val number = subst(action.params["number"] ?: return, variables)
                val rawText = action.params["text"] ?: ""
                val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 20)
                val delaySeconds = (action.params["delay_seconds"]?.toIntOrNull() ?: 2).coerceIn(0, 300)
                val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    context.getSystemService(SmsManager::class.java)
                else @Suppress("DEPRECATION") SmsManager.getDefault()
                for (n in 1..count) {
                    val text = subst(rawText.replace("{n}", n.toString()), variables)
                    try {
                        sms?.sendTextMessage(number, null, text, null, null)
                        insertIntoSentSms(context, number, text)
                    } catch (e: Exception) {
                        throw ActionExecutionException("SMS $n/$count non envoyé : ${e.message ?: e.javaClass.simpleName}", e)
                    }
                    if (n < count && delaySeconds > 0) delay(delaySeconds * 1000L)
                }
            }

            ActionType.SEND_MULTIPLE_NOTIFICATIONS -> {
                val title = subst(action.params["title"]?.ifBlank { "Automatisation" } ?: "Automatisation", variables)
                val rawText = action.params["text"] ?: ""
                val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 20)
                val delaySeconds = (action.params["delay_seconds"]?.toIntOrNull() ?: 2).coerceIn(0, 300)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPerm(context, Manifest.permission.POST_NOTIFICATIONS)) {
                    throw ActionExecutionException("Autorise les notifications de BlockAuto")
                }
                for (n in 1..count) {
                    val text = subst(rawText.replace("{n}", n.toString()), variables)
                    val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setAutoCancel(true)
                    NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt() + n, builder.build())
                    if (n < count && delaySeconds > 0) delay(delaySeconds * 1000L)
                }
            }

            ActionType.CANCEL_VIBRATION -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.cancel()
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    v.cancel()
                }
            }

            ActionType.SET_RING_VOLUME -> {
                val level = action.params["level"]?.toIntOrNull() ?: 5
                try {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_RING)
                    am.setStreamVolume(AudioManager.STREAM_RING, level.coerceIn(0, max), 0)
                } catch (e: Exception) { throw ActionExecutionException("Impossible de régler le volume de sonnerie : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.SET_ALARM_VOLUME -> {
                val level = action.params["level"]?.toIntOrNull() ?: 5
                try {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                    am.setStreamVolume(AudioManager.STREAM_ALARM, level.coerceIn(0, max), 0)
                } catch (e: Exception) { throw ActionExecutionException("Impossible de régler le volume d'alarme : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.SPEAK_TEXT -> {
                val text = subst(action.params["text"] ?: "", variables)
                if (text.isBlank()) return
                // Le moteur de synthèse vocale se prépare de façon asynchrone (onInit) : on
                // attend qu'il soit prêt avant de parler, puis on attend la fin de la lecture
                // (durée estimée, faute d'un vrai callback bloquant côté TextToSpeech classique)
                // pour que le service ne se referme pas avant que la phrase soit terminée —
                // même logique que pour VIBRATE, WAKE_SCREEN et RECORD_AUDIO_CLIP.
                try {
                    val ready = kotlinx.coroutines.CompletableDeferred<Boolean>()
                    val tts = android.speech.tts.TextToSpeech(context) { status ->
                        ready.complete(status == android.speech.tts.TextToSpeech.SUCCESS)
                    }
                    val ok = kotlinx.coroutines.withTimeoutOrNull(4000L) { ready.await() } ?: false
                    if (ok) {
                        tts.language = java.util.Locale.getDefault()
                        tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "blockauto_tts")
                        val estimatedMs = (text.length * 60L).coerceIn(800, 15_000)
                        delay(estimatedMs)
                    }
                    tts.stop()
                    tts.shutdown()
                } catch (e: Exception) { throw ActionExecutionException("Synthèse vocale indisponible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.CREATE_TIMER -> {
                val seconds = (action.params["seconds"]?.toIntOrNull() ?: 60).coerceIn(1, 24 * 3600)
                val label = action.params["label"]?.ifBlank { "BlockAuto" } ?: "BlockAuto"
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: Exception) { throw ActionExecutionException("Aucun minuteur compatible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.OPEN_CAMERA -> {
                val intent = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: Exception) { throw ActionExecutionException("Impossible d'ouvrir l'appareil photo : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.SET_SCREEN_TIMEOUT -> {
                try {
                    if (!Settings.System.canWrite(context)) throw ActionExecutionException("Autorise « Modifier les réglages système »")
                    val minutes = action.params["minutes"]?.toIntOrNull() ?: 2
                    Settings.System.putInt(
                        context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT,
                        (minutes.coerceIn(1, 60)) * 60_000
                    )
                } catch (e: Exception) { throw ActionExecutionException("Impossible de régler la mise en veille : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.SET_VOLUME -> {
                val level = action.params["level"]?.toIntOrNull() ?: 5
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0, max), 0)
            }

            ActionType.SET_BRIGHTNESS -> {
                if (!Settings.System.canWrite(context)) throw ActionExecutionException("Autorise « Modifier les réglages système »")
                val level = action.params["level"]?.toIntOrNull() ?: 128
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0, 255))
            }

            ActionType.TOGGLE_FLASHLIGHT -> {
                try {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val camId = cm.cameraIdList.firstOrNull()
                    val turnOn = action.params["state"] != "off"
                    if (camId != null) cm.setTorchMode(camId, turnOn)
                } catch (e: Exception) { throw ActionExecutionException("Lampe torche indisponible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.TOGGLE_WIFI -> {
                // Android 10+ interdit aux applications classiques d'activer/désactiver
                // directement le Wi‑Fi. Ouvrir le panneau n'est pas une vraie action et
                // casserait les chaînes (l'action suivante partirait immédiatement).
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    throw ActionExecutionException("Android interdit le changement automatique du Wi‑Fi à partir d'Android 10. Utilise « Ouvrir réglages Wi‑Fi ».")
                }
                @Suppress("DEPRECATION")
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wm.isWifiEnabled = action.params["state"] != "off"
            }

            ActionType.TOGGLE_BLUETOOTH -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    !hasPerm(context, Manifest.permission.BLUETOOTH_CONNECT)) {
                    throw ActionExecutionException("Permission Bluetooth à accorder")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    throw ActionExecutionException("Android 13+ interdit l'activation/désactivation automatique du Bluetooth pour les apps classiques. Utilise « Ouvrir réglages Bluetooth ».")
                }
                @Suppress("DEPRECATION")
                val adapter = BluetoothAdapter.getDefaultAdapter()
                @Suppress("DEPRECATION")
                val ok = if (action.params["state"] == "off") adapter?.disable() else adapter?.enable()
                if (ok != true) throw ActionExecutionException("Le changement d'état Bluetooth a été refusé par Android")
            }

            ActionType.SET_RINGER_MODE -> {
                try {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.ringerMode = when (action.params["mode"]) {
                        "silent" -> AudioManager.RINGER_MODE_SILENT
                        "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                        else -> AudioManager.RINGER_MODE_NORMAL
                    }
                } catch (e: Exception) { throw ActionExecutionException("Impossible de changer le mode sonnerie : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.OPEN_URL -> {
                val url = subst(action.params["url"] ?: return, variables)
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
            }

            ActionType.OPEN_WIFI_SETTINGS -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
            }

            ActionType.OPEN_BLUETOOTH_SETTINGS -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
            }

            ActionType.OPEN_DND_SETTINGS -> {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
            }

            ActionType.SEND_SMS -> {
                // BUG CORRIGÉ : le numéro n'était jamais passé par subst(), donc impossible
                // d'utiliser {sms_sender} pour répondre automatiquement à l'expéditeur d'un SMS.
                val number = subst(action.params["number"] ?: return, variables)
                val text = subst(action.params["text"] ?: "", variables)
                try {
                    val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                        context.getSystemService(SmsManager::class.java)
                    else @Suppress("DEPRECATION") SmsManager.getDefault()
                    sms?.sendTextMessage(number, null, text, null, null)
                    // Rend le message visible dans l'appli Messages par défaut (dossier "Envoyés"),
                    // sinon un SMS envoyé par BlockAuto n'apparaît nulle part ailleurs que dans l'app.
                    insertIntoSentSms(context, number, text)
                } catch (e: Exception) { throw ActionExecutionException("SMS non envoyé : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.MAKE_CALL -> {
                val number = subst(action.params["number"] ?: return, variables)
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: SecurityException) { /* permission CALL_PHONE refusée */ }
            }

            ActionType.SEND_EMAIL -> {
                val to = subst(action.params["to"] ?: "", variables)
                val subject = subst(action.params["subject"] ?: "", variables)
                val body = subst(action.params["body"] ?: "", variables)
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$to"))
                intent.putExtra(Intent.EXTRA_SUBJECT, subject)
                intent.putExtra(Intent.EXTRA_TEXT, body)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: Exception) { throw ActionExecutionException("Aucune application e-mail compatible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.COPY_CLIPBOARD -> {
                val text = subst(action.params["text"] ?: "", variables)
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("BlockAuto", text))
            }

            ActionType.CREATE_ALARM -> {
                val hour = action.params["hour"]?.toIntOrNull() ?: return
                val minute = action.params["minute"]?.toIntOrNull() ?: 0
                val label = action.params["label"] ?: "BlockAuto"
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: Exception) { throw ActionExecutionException("Impossible de créer l'alarme : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.WAKE_SCREEN -> {
                try {
                    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                    @Suppress("DEPRECATION")
                    val wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                        "BlockAuto:wakeScreen"
                    )
                    wl.acquire(10_000)
                    delay(10_000)
                    if (wl.isHeld) wl.release()
                } catch (e: Exception) { throw ActionExecutionException("Impossible de réveiller l'écran : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.LOG_EVENT -> {
                HistoryRepository.add(context, "Bloc manuel", action.params["text"] ?: "Événement")
            }

            ActionType.WAIT -> {
                val sec = action.params["seconds"]?.toLongOrNull() ?: 1L
                delay(sec * 1000)
            }

            ActionType.CALL_CONTACT -> {
                val name = subst(action.params["name"] ?: return, variables)
                if (!hasPerm(context, Manifest.permission.READ_CONTACTS)) throw ActionExecutionException("Permission contacts à accorder")
                val number = lookupContactNumber(context, name) ?: return
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: SecurityException) { /* CALL_PHONE refusée */ }
            }

            ActionType.ADD_CALENDAR_EVENT -> {
                try {
                    if (!hasPerm(context, Manifest.permission.WRITE_CALENDAR)) throw ActionExecutionException("Autorise l'accès au calendrier")
                    val title = subst(action.params["title"] ?: "Événement BlockAuto", variables)
                    val minutesFromNow = action.params["minutes_from_now"]?.toLongOrNull() ?: 0L
                    val start = System.currentTimeMillis() + minutesFromNow * 60_000L
                    val durationMin = action.params["duration_minutes"]?.toLongOrNull() ?: 60L
                    val calId = getFirstCalendarId(context) ?: return
                    val values = ContentValues().apply {
                        put(CalendarContract.Events.CALENDAR_ID, calId)
                        put(CalendarContract.Events.TITLE, title)
                        put(CalendarContract.Events.DTSTART, start)
                        put(CalendarContract.Events.DTEND, start + durationMin * 60_000L)
                        put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
                    }
                    context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                } catch (e: Exception) { throw ActionExecutionException("Impossible d'ajouter l'événement : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.SHARE_TEXT -> {
                val text = subst(action.params["text"] ?: "", variables)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivityWithBackgroundExemption(context) {
                        context.startActivity(Intent.createChooser(intent, "Partager via BlockAuto").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                } catch (e: Exception) { throw ActionExecutionException("Impossible d'ouvrir le partage : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.TOGGLE_AUTO_ROTATE -> {
                try {
                    if (!Settings.System.canWrite(context)) throw ActionExecutionException("Autorise « Modifier les réglages système »")
                    val on = action.params["state"] != "off"
                    Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
                } catch (e: Exception) { throw ActionExecutionException("Impossible de modifier la rotation : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.TOGGLE_DND -> {
                try {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (!nm.isNotificationPolicyAccessGranted) throw ActionExecutionException("Autorise l'accès « Ne pas déranger »")
                    val on = action.params["state"] != "off"
                    nm.setInterruptionFilter(
                        if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        else NotificationManager.INTERRUPTION_FILTER_ALL
                    )
                } catch (e: Exception) { throw ActionExecutionException("Impossible de changer le mode Ne pas déranger : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.TAKE_SCREENSHOT -> {
                if (!AppWatcherAccessibilityService.takeScreenshot()) throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
            }

            ActionType.RECORD_AUDIO_CLIP -> {
                if (!hasPerm(context, Manifest.permission.RECORD_AUDIO)) throw ActionExecutionException("Permission micro à accorder")
                val seconds = (action.params["seconds"]?.toLongOrNull() ?: 5L).coerceIn(1, 120)
                try {
                    val outDir = File(context.filesDir, "recordings").apply { mkdirs() }
                    val outFile = File(outDir, "clip_${System.currentTimeMillis()}.m4a")
                    val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
                    recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                    recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    recorder.setOutputFile(outFile.absolutePath)
                    recorder.prepare()
                    recorder.start()
                    delay(seconds * 1000)
                    recorder.stop()
                    recorder.release()
                    HistoryRepository.add(context, "Enregistrement audio", "Extrait sauvegardé : ${outFile.name}")
                } catch (e: Exception) { throw ActionExecutionException("Enregistrement audio impossible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.GET_LOCATION -> {
                if (!hasPerm(context, Manifest.permission.ACCESS_FINE_LOCATION) &&
                    !hasPerm(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                ) throw ActionExecutionException("Permission de localisation à accorder")
                try {
                    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    val providers = lm.getProviders(true)
                    var best: android.location.Location? = null
                    for (p in providers) {
                        val loc = lm.getLastKnownLocation(p) ?: continue
                        if (best == null || loc.accuracy < best.accuracy) best = loc
                    }
                    val location = best ?: throw ActionExecutionException("Aucune position récente disponible. Active la localisation et réessaie.")
                    variables["lat"] = location.latitude.toString()
                    variables["lon"] = location.longitude.toString()
                    variables["location"] = "${location.latitude},${location.longitude}"
                } catch (e: Exception) { throw ActionExecutionException("Position GPS indisponible : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.LOCK_SCREEN -> {
                // Nécessite le service d'accessibilité (voir Réglages BlockAuto) : c'est la
                // seule façon pour une app tierce de verrouiller l'écran sans être l'app
                // Administrateur de l'appareil.
                if (!AppWatcherAccessibilityService.lockScreen()) throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
            }

            ActionType.GO_HOME -> {
                if (!AppWatcherAccessibilityService.goHome()) throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
            }

            ActionType.OPEN_RECENT_APPS -> {
                if (!AppWatcherAccessibilityService.openRecents()) throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
            }

            ActionType.OPEN_APP_SETTINGS -> {
                val pkg = action.params["package"]?.trim().orEmpty()
                if (pkg.isBlank()) throw ActionExecutionException("Aucune application sélectionnée")
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
                } catch (e: Exception) { throw ActionExecutionException("Impossible d'ouvrir les réglages de l'application : ${e.message ?: e.javaClass.simpleName}", e) }
            }

            ActionType.CLEAR_NOTIFICATIONS -> {
                val listener = com.blockauto.app.services.NotifListenerService.instanceOrNull()
                    ?: throw ActionExecutionException("Active l'accès aux notifications de BlockAuto")
                listener.cancelAllNotifications()
            }

            // --- Blocs d'interaction DANS une autre application, via le service d'accessibilité.
            // Tous nécessitent que le service d'accessibilité BlockAuto soit activé ET que
            // l'application ciblée soit déjà au premier plan (généralement ouverte juste avant
            // par un bloc "Ouvrir une application" ou "Ouvrir une appli puis cliquer sur un texte").
            ActionType.UI_CLICK_TEXT -> {
                val text = subst(action.params["text"] ?: return, variables)
                if (!AppWatcherAccessibilityService.clickText(text)) {
                    throw ActionExecutionException("Texte introuvable ou service d'accessibilité inactif : « $text »")
                }
            }

            ActionType.UI_CLICK_DESCRIPTION -> {
                val description = subst(action.params["description"] ?: return, variables)
                if (!AppWatcherAccessibilityService.clickByDescription(description)) {
                    throw ActionExecutionException("Icône introuvable ou service d'accessibilité inactif : « $description »")
                }
            }

            ActionType.UI_LONG_CLICK_TEXT -> {
                val text = subst(action.params["text"] ?: return, variables)
                if (!AppWatcherAccessibilityService.longClickText(text)) {
                    throw ActionExecutionException("Texte introuvable ou service d'accessibilité inactif : « $text »")
                }
            }

            ActionType.UI_INPUT_TEXT -> {
                val text = subst(action.params["text"] ?: "", variables)
                if (!AppWatcherAccessibilityService.inputTextInFocusedField(text)) {
                    throw ActionExecutionException("Aucun champ de saisie actif, ou service d'accessibilité inactif")
                }
            }

            ActionType.UI_SCROLL_DOWN -> {
                if (!AppWatcherAccessibilityService.scroll(forward = true)) {
                    throw ActionExecutionException("Aucun élément défilable trouvé, ou service d'accessibilité inactif")
                }
            }

            ActionType.UI_SCROLL_UP -> {
                if (!AppWatcherAccessibilityService.scroll(forward = false)) {
                    throw ActionExecutionException("Aucun élément défilable trouvé, ou service d'accessibilité inactif")
                }
            }

            ActionType.UI_SWIPE -> {
                val direction = action.params["direction"] ?: "up"
                if (!AppWatcherAccessibilityService.swipe(direction)) {
                    throw ActionExecutionException("Balayage impossible : active le service d'accessibilité BlockAuto")
                }
            }

            ActionType.UI_PRESS_BACK -> {
                if (!AppWatcherAccessibilityService.pressBack()) {
                    throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
                }
            }

            ActionType.UI_WAIT_FOR_TEXT -> {
                val text = subst(action.params["text"] ?: return, variables)
                val timeoutSeconds = (action.params["timeout_seconds"]?.toLongOrNull() ?: 10L).coerceIn(1, 120)
                val deadline = System.currentTimeMillis() + timeoutSeconds * 1000
                var found = false
                while (System.currentTimeMillis() < deadline) {
                    if (AppWatcherAccessibilityService.isTextVisible(text)) { found = true; break }
                    delay(250)
                }
                if (!found) throw ActionExecutionException("Le texte « $text » n'est pas apparu à temps")
            }

            ActionType.UI_OPEN_APP_AND_CLICK -> {
                val pkg = action.params["package"]?.trim().orEmpty()
                val text = subst(action.params["text"] ?: "", variables)
                if (pkg.isBlank()) throw ActionExecutionException("Aucune application sélectionnée")
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                    ?: throw ActionExecutionException("Application introuvable ou non lançable : $pkg")
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(launchIntent) }
                // Laisse le temps à l'application de s'ouvrir et d'afficher son interface
                // avant de chercher le texte à cliquer, sinon l'arbre d'accessibilité lu serait
                // encore celui de l'écran précédent.
                delay(1500)
                if (text.isNotBlank() && !AppWatcherAccessibilityService.clickText(text)) {
                    throw ActionExecutionException("Application ouverte, mais texte introuvable : « $text »")
                }
            }

            // --- Nouveaux blocs "envoyer un message dans une appli" (accessibilité) ---
            // Généraux : ils s'appuient uniquement sur ce qui est réellement affiché à l'écran
            // (champ de saisie, bouton d'envoi), donc utilisables avec Instagram, WhatsApp,
            // Messenger, Telegram, l'appli SMS elle-même, ou toute autre appli de messagerie —
            // à condition que la conversation soit déjà ouverte à l'écran.
            ActionType.UI_CLICK_INPUT_FIELD -> {
                if (!AppWatcherAccessibilityService.clickFirstEditableField()) {
                    throw ActionExecutionException("Aucun champ de saisie trouvé à l'écran, ou service d'accessibilité inactif")
                }
            }

            ActionType.UI_SEND_MESSAGE_IN_APP -> {
                val message = subst(action.params["text"] ?: "", variables)
                if (message.isBlank()) throw ActionExecutionException("Aucun message à envoyer")
                val sendLabel = action.params["send_label"]?.trim()
                if (!AppWatcherAccessibilityService.clickInputFieldAndType(message)) {
                    throw ActionExecutionException("Champ de message introuvable, ou service d'accessibilité inactif")
                }
                delay(400)
                if (!AppWatcherAccessibilityService.clickSendButton(sendLabel)) {
                    throw ActionExecutionException("Message écrit, mais bouton d'envoi introuvable (renseigne son libellé exact si besoin)")
                }
            }

            ActionType.UI_SEND_MULTIPLE_MESSAGES_IN_APP -> {
                // Envoie plusieurs messages à la suite DANS LA CONVERSATION DÉJÀ OUVERTE, avec
                // une pause entre chaque (comme "Envoyer plusieurs SMS", mais pour n'importe
                // quelle appli de messagerie). {n} est remplacé par le numéro d'ordre du message.
                val rawText = action.params["text"] ?: ""
                val sendLabel = action.params["send_label"]?.trim()
                val count = (action.params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 20)
                val delaySeconds = (action.params["delay_seconds"]?.toIntOrNull() ?: 3).coerceIn(1, 300)
                for (n in 1..count) {
                    val text = subst(rawText.replace("{n}", n.toString()), variables)
                    if (text.isBlank()) continue
                    if (!AppWatcherAccessibilityService.clickInputFieldAndType(text)) {
                        throw ActionExecutionException("Message $n/$count : champ de saisie introuvable, ou service d'accessibilité inactif")
                    }
                    delay(400)
                    if (!AppWatcherAccessibilityService.clickSendButton(sendLabel)) {
                        throw ActionExecutionException("Message $n/$count écrit, mais bouton d'envoi introuvable")
                    }
                    if (n < count) delay(delaySeconds * 1000L)
                }
            }

            ActionType.UI_OPEN_APP_AND_SEND_MESSAGE -> {
                // Combo complet : ouvrir l'appli, éventuellement ouvrir une conversation en
                // cliquant sur un nom de contact affiché dans la liste, puis écrire et envoyer.
                val pkg = action.params["package"]?.trim().orEmpty()
                val contactText = subst(action.params["contact_text"] ?: "", variables)
                val message = subst(action.params["text"] ?: "", variables)
                val sendLabel = action.params["send_label"]?.trim()
                if (pkg.isBlank()) throw ActionExecutionException("Aucune application sélectionnée")
                if (message.isBlank()) throw ActionExecutionException("Aucun message à envoyer")
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                    ?: throw ActionExecutionException("Application introuvable ou non lançable : $pkg")
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivityWithBackgroundExemption(context) { context.startActivity(launchIntent) }
                // Laisse le temps à l'application (et sa liste de conversations) de s'afficher.
                delay(1800)
                if (contactText.isNotBlank()) {
                    if (!AppWatcherAccessibilityService.clickText(contactText)) {
                        throw ActionExecutionException("Application ouverte, mais conversation introuvable : « $contactText »")
                    }
                    // Laisse le temps à la conversation de s'ouvrir avant de chercher le champ.
                    delay(1200)
                }
                if (!AppWatcherAccessibilityService.clickInputFieldAndType(message)) {
                    throw ActionExecutionException("Conversation ouverte, mais champ de message introuvable")
                }
                delay(400)
                if (!AppWatcherAccessibilityService.clickSendButton(sendLabel)) {
                    throw ActionExecutionException("Message écrit, mais bouton d'envoi introuvable (renseigne son libellé exact si besoin)")
                }
            }

            ActionType.HTTP_REQUEST -> {
                val url = subst(action.params["url"] ?: return, variables)
                val method = (action.params["method"] ?: "GET").uppercase()
                val body = subst(action.params["body"] ?: "", variables)
                val result = sendHttpRequest(url, method, body)
                variables["http_code"] = result.first.toString()
                variables["http_body"] = result.second
            }

            ActionType.DISCORD_WEBHOOK -> {
                val webhookUrl = action.params["webhook_url"] ?: return
                val message = subst(action.params["message"] ?: "", variables)
                val json = "{\"content\":\"${jsonEscape(message)}\"}"
                sendHttpRequest(webhookUrl, "POST", json, "application/json")
            }

            ActionType.SLACK_WEBHOOK -> {
                val webhookUrl = action.params["webhook_url"] ?: return
                val message = subst(action.params["message"] ?: "", variables)
                val json = "{\"text\":\"${jsonEscape(message)}\"}"
                sendHttpRequest(webhookUrl, "POST", json, "application/json")
            }

            ActionType.IFTTT_WEBHOOK -> {
                val event = action.params["event_name"] ?: return
                val key = action.params["key"] ?: return
                val value1 = subst(action.params["value1"] ?: "", variables)
                val url = "https://maker.ifttt.com/trigger/${Uri.encode(event)}/with/key/$key"
                val json = "{\"value1\":\"${jsonEscape(value1)}\"}"
                sendHttpRequest(url, "POST", json, "application/json")
            }

            ActionType.HOME_ASSISTANT_WEBHOOK -> {
                val baseUrl = action.params["base_url"]?.trimEnd('/') ?: return
                val webhookId = action.params["webhook_id"] ?: return
                val payload = subst(action.params["payload"] ?: "{}", variables)
                sendHttpRequest("$baseUrl/api/webhook/$webhookId", "POST", payload, "application/json")
            }

            ActionType.TELEGRAM_MESSAGE -> {
                val botToken = action.params["bot_token"] ?: return
                val chatId = action.params["chat_id"] ?: return
                val message = subst(action.params["message"] ?: "", variables)
                val url = "https://api.telegram.org/bot$botToken/sendMessage" +
                    "?chat_id=${URLEncoder.encode(chatId, "UTF-8")}" +
                    "&text=${URLEncoder.encode(message, "UTF-8")}"
                sendHttpRequest(url, "GET", "")
            }

            else -> { /* blocs logiques gérés dans executeSequence */ }
        }
    }

    /** Requête HTTP générique utilisée par tous les blocs "connecteur" (webhook, API, bot...). */
    private suspend fun sendHttpRequest(
        urlString: String,
        method: String,
        body: String,
        contentType: String = "application/x-www-form-urlencoded"
    ): Pair<Int, String> = withContext(Dispatchers.IO) {
        val cleanUrl = urlString.trim()
        if (!(cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))) {
            throw ActionExecutionException("URL HTTP invalide : $cleanUrl")
        }
        val normalizedMethod = method.uppercase()
        if (normalizedMethod !in setOf("GET", "POST", "PUT", "PATCH", "DELETE")) {
            throw ActionExecutionException("Méthode HTTP non supportée : $method")
        }
        try {
            val connection = URL(cleanUrl).openConnection() as HttpURLConnection
            connection.requestMethod = normalizedMethod
            connection.connectTimeout = 15_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "application/json, text/plain, */*")
            if (normalizedMethod != "GET" && normalizedMethod != "DELETE") {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", contentType)
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
            }
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code !in 200..299) {
                throw ActionExecutionException("Requête HTTP échouée (HTTP $code)${if (response.isNotBlank()) " : ${response.take(300)}" else ""}")
            }
            code to response
        } catch (e: ActionExecutionException) {
            throw e
        } catch (e: Exception) {
            throw ActionExecutionException("Impossible de joindre le serveur : ${e.message ?: e.javaClass.simpleName}", e)
        }
    }

    private fun jsonEscape(text: String): String =
        text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")

    private fun lookupContactNumber(context: Context, name: String): String? {
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, selection, arrayOf("%$name%"), null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    private fun getFirstCalendarId(context: Context): Long? {
        val projection = arrayOf(CalendarContract.Calendars._ID)
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getLong(0)
        }
        return null
    }

    /**
     * Insère le SMS envoyé dans le fournisseur de contenu "Sms.Sent" du système
     * pour qu'il apparaisse dans l'appli Messages par défaut du téléphone,
     * exactement comme si l'utilisateur l'avait tapé lui-même.
     * Sur certains téléphones (selon le fabricant), seule l'appli SMS par défaut
     * peut écrire dans ce fournisseur : l'opération échoue alors silencieusement,
     * mais le SMS part quand même normalement.
     */
    private fun insertIntoSentSms(context: Context, number: String, text: String) {
        try {
            val values = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, number)
                put(Telephony.Sms.BODY, text)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            }
            context.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, values)
        } catch (e: Exception) {
            // Non bloquant : voir commentaire ci-dessus.
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "BlockAuto", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }
}
