package com.blockauto.app.nfc

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Build

/**
 * Petite couche autour de l'API NFC d'Android, pour deux usages dans BlockAuto :
 *  - "Apprendre" un tag existant (lire son identifiant) pour l'utiliser comme déclencheur
 *    d'une automatisation (bloc "Tag NFC scanné").
 *  - "Écrire" un tag vierge ou réinscriptible avec un lien `blockauto://run/<id>` : au
 *    contact, Android ouvre BlockAuto (même appli fermée) qui lance directement
 *    l'automatisation visée, sans que le téléphone ait besoin d'avoir appris ce tag au
 *    préalable.
 */
object NfcHelper {

    /** Schéma d'URI utilisé sur les tags écrits par BlockAuto (voir l'intent-filter du
     *  manifeste sur MainActivity) : blockauto://run/<automation_id> */
    private const val SCHEME = "blockauto"
    private const val HOST = "run"

    fun adapter(activity: Activity): NfcAdapter? = NfcAdapter.getDefaultAdapter(activity)

    fun isAvailable(activity: Activity): Boolean = adapter(activity) != null

    fun isEnabled(activity: Activity): Boolean = adapter(activity)?.isEnabled == true

    /**
     * Active la détection NFC au premier plan pour que CETTE activité (et pas une autre
     * appli, ni un simple lancement système) reçoive tout tag approché tant qu'elle est
     * visible. Indispensable aussi bien pour "apprendre" un tag que pour l'écrire.
     */
    fun enableForegroundDispatch(activity: Activity) {
        val nfcAdapter = adapter(activity) ?: return
        val intent = Intent(activity, activity.javaClass).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_MUTABLE
        } else 0
        val pendingIntent = PendingIntent.getActivity(activity, 0, intent, flags)
        val filters = arrayOf(
            IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED),
            IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED),
            IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED)
        )
        try {
            nfcAdapter.enableForegroundDispatch(activity, pendingIntent, filters, null)
        } catch (e: Exception) { /* activité pas au premier plan, ignorable */ }
    }

    fun disableForegroundDispatch(activity: Activity) {
        try {
            adapter(activity)?.disableForegroundDispatch(activity)
        } catch (e: Exception) { /* déjà désactivé, ignorable */ }
    }

    /** Extrait le [Tag] transporté par un intent de découverte NFC, ou null si l'intent
     *  n'en contient pas (cas d'un intent "normal" de lancement d'appli). */
    @Suppress("DEPRECATION")
    fun extractTag(intent: Intent): Tag? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        }

    /** Identifiant matériel du tag (numéro de série), sous forme hexadécimale stable —
     *  utilisé pour associer un tag existant à un déclencheur "Tag NFC scanné". */
    fun tagUid(tag: Tag): String = tag.id.joinToString("") { "%02X".format(it) }

    /** Si l'intent correspond à un lien `blockauto://run/<id>` écrit par cette appli sur un
     *  tag, renvoie l'identifiant de l'automatisation à lancer. */
    fun extractRunAutomationId(intent: Intent): String? {
        val data = intent.data ?: return null
        return if (data.scheme == SCHEME && data.host == HOST) data.lastPathSegment else null
    }

    /** Construit le message NDEF à écrire sur un tag pour qu'il lance automatiquement
     *  l'automatisation [automationId] : un enregistrement URI custom, suivi d'un
     *  "Android Application Record" qui garantit que c'est bien BlockAuto qui s'ouvre
     *  même si une autre appli sait aussi lire des liens NDEF. */
    fun buildRunMessage(packageName: String, automationId: String): NdefMessage {
        val uriRecord = NdefRecord.createUri("$SCHEME://$HOST/$automationId")
        val appRecord = NdefRecord.createApplicationRecord(packageName)
        return NdefMessage(arrayOf(uriRecord, appRecord))
    }

    /** Construit un tag NFC "libre" contenant un texte quelconque (note, code, mot de
     *  passe Wi-Fi à recopier, etc.) — fonctionnalité premium "Tags NFC personnalisés" :
     *  un tag lu par n'importe quel téléphone (pas seulement avec BlockAuto installé)
     *  affichera ce texte via le lecteur NFC du système. */
    fun buildTextMessage(text: String, locale: String = "fr"): NdefMessage {
        val textRecord = NdefRecord.createTextRecord(locale, text)
        return NdefMessage(arrayOf(textRecord))
    }

    /** Construit un tag NFC contenant un lien web classique (pas un lien BlockAuto) :
     *  approché par n'importe quel téléphone, il ouvre ce lien dans le navigateur. */
    fun buildUriMessage(url: String): NdefMessage {
        val uriRecord = NdefRecord.createUri(url)
        return NdefMessage(arrayOf(uriRecord))
    }

    /** Résultat de tentative d'écriture, avec un message d'échec lisible le cas échéant. */
    sealed class WriteResult {
        object Success : WriteResult()
        data class Failure(val reason: String) : WriteResult()
    }

    /** Écrit [message] sur [tag] : réutilise le formatage NDEF existant s'il y en a un,
     *  ou formate un tag vierge compatible (NdefFormatable) à la volée. */
    fun write(tag: Tag, message: NdefMessage): WriteResult {
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return try {
                ndef.connect()
                if (!ndef.isWritable) return WriteResult.Failure("Ce tag est en lecture seule.")
                if (ndef.maxSize < message.toByteArray().size) {
                    return WriteResult.Failure("Ce tag est trop petit pour ces données.")
                }
                ndef.writeNdefMessage(message)
                WriteResult.Success
            } catch (e: Exception) {
                WriteResult.Failure(e.message ?: "Écriture impossible.")
            } finally {
                try { ndef.close() } catch (_: Exception) {}
            }
        }
        val formatable = NdefFormatable.get(tag)
            ?: return WriteResult.Failure("Ce tag n'est pas compatible NDEF.")
        return try {
            formatable.connect()
            formatable.format(message)
            WriteResult.Success
        } catch (e: Exception) {
            WriteResult.Failure(e.message ?: "Formatage impossible.")
        } finally {
            try { formatable.close() } catch (_: Exception) {}
        }
    }
}
