package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("automation_id") ?: return
        AutomationExecutionService.start(context, id)
        // On reprogramme : le lendemain à la même heure pour un déclencheur "Heure précise",
        // ou après le même intervalle pour un déclencheur "Toutes les X minutes".
        val automation = AutomationRepository.get(context, id) ?: return
        val trigger = automation.trigger ?: return
        when (trigger.type) {
            TriggerType.COUNTDOWN_ONCE -> {
                // "Une seule fois" : on marque le bloc comme consommé et on désactive
                // l'automatisation plutôt que de la reprogrammer indéfiniment.
                trigger.params["consumed"] = "true"
                automation.enabled = false
                AutomationRepository.save(context, automation)
            }
            TriggerType.INTERVAL_LIMITED -> {
                val timesLeft = (trigger.params["times_left"]?.toIntOrNull()
                    ?: trigger.params["times"]?.toIntOrNull() ?: 1) - 1
                trigger.params["times_left"] = timesLeft.toString()
                if (timesLeft <= 0) automation.enabled = false
                AutomationRepository.save(context, automation)
                if (timesLeft > 0) TriggerScheduler.schedule(context, automation)
            }
            else -> TriggerScheduler.schedule(context, automation)
        }
    }
}
