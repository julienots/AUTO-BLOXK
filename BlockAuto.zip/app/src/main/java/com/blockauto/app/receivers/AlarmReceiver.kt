package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("automation_id") ?: return
        AutomationExecutionService.start(context, id)
        // On reprogramme : le lendemain à la même heure pour un déclencheur "Heure précise",
        // ou après le même intervalle pour un déclencheur "Toutes les X minutes".
        val automation = AutomationRepository.get(context, id)
        if (automation != null) TriggerScheduler.schedule(context, automation)
    }
}
