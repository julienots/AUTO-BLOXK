package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class BatteryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val targetType = when (intent.action) {
            Intent.ACTION_BATTERY_LOW -> TriggerType.BATTERY_LOW
            Intent.ACTION_POWER_CONNECTED -> TriggerType.BATTERY_FULL
            else -> return
        }
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == targetType) {
                AutomationExecutionService.start(context, a.id)
            }
        }
    }
}
