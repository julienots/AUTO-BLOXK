package com.blockauto.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.blockauto.app.engine.AutomationExecutor
import com.blockauto.app.storage.AutomationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AutomationExecutionService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("automation_id")
        startForegroundIfNeeded()
        if (id != null) {
            val automation = AutomationRepository.get(this, id)
            if (automation != null && automation.enabled) {
                scope.launch {
                    AutomationExecutor.run(this@AutomationExecutionService, automation)
                    stopSelf(startId)
                }
                return START_NOT_STICKY
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }

    private fun startForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "exec_channel"
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Exécution", NotificationManager.IMPORTANCE_MIN)
                )
            }
            val notif = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Automatisation en cours")
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build()
            startForeground(1, notif)
        }
    }

    companion object {
        fun start(context: Context, automationId: String) {
            val intent = Intent(context, AutomationExecutionService::class.java)
            intent.putExtra("automation_id", automationId)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
