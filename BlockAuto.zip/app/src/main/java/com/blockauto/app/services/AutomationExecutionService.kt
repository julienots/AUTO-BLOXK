package com.blockauto.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.blockauto.app.engine.AutomationExecutor
import com.blockauto.app.storage.AutomationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class AutomationExecutionService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val executionMutex = Mutex()
    @Volatile private var activeExecutions = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("automation_id")
        startForegroundIfNeeded()
        if (id != null) {
            val automation = AutomationRepository.get(this, id)
            if (automation != null && automation.enabled) {
                // BUG CORRIGÉ : les déclencheurs qui portent une information utile (numéro de
                // l'expéditeur d'un SMS, app qui vient de s'ouvrir, contenu d'une notification...)
                // ne transmettaient jamais cette info aux blocs actions. Résultat : impossible de
                // créer "réponds automatiquement à l'expéditeur du SMS" ou "notifie-moi avec le
                // texte de la notification reçue", même si le bloc SMS/notification déclenchait
                // bien l'automatisation. On lit maintenant les extras posés par le receiver/service
                // à l'origine du déclenchement et on les injecte comme variables {xxx} disponibles
                // dans tous les blocs suivants (voir subst() dans AutomationExecutor).
                @Suppress("UNCHECKED_CAST")
                val extraVars = (intent.getSerializableExtra("trigger_vars") as? HashMap<String, String>) ?: hashMapOf()
                activeExecutions++
                scope.launch {
                    try {
                        // Une seule exécution à la fois : évite que deux déclencheurs simultanés
                        // se marchent dessus (volume, TTS, SMS, variables, chaînes A→B, etc.).
                        executionMutex.withLock {
                            AutomationExecutor.run(this@AutomationExecutionService, automation, initialVariables = extraVars)
                        }
                    } finally {
                        activeExecutions--
                        if (activeExecutions <= 0) stopSelf()
                    }
                }
                return START_NOT_STICKY
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }

    private fun startForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "exec_channel"
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Exécution", NotificationManager.IMPORTANCE_MIN)
                )
            }
            val notif = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Automatisation en cours")
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build()
            startForeground(1, notif)
        }
    }

    companion object {
        fun start(context: Context, automationId: String, triggerVars: Map<String, String> = emptyMap()) {
            val intent = Intent(context, AutomationExecutionService::class.java)
            intent.putExtra("automation_id", automationId)
            if (triggerVars.isNotEmpty()) {
                intent.putExtra("trigger_vars", HashMap(triggerVars))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
