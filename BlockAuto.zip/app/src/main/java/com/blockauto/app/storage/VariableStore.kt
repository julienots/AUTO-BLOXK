package com.blockauto.app.storage

import android.content.Context

/**
 * Stockage minuscule pour les "variables globales" : contrairement aux variables normales
 * (créées par le bloc "Variable : définir une valeur"), qui ne vivent que le temps d'une
 * exécution — et de ses chaînages directs —, une variable globale est écrite sur le disque
 * et reste donc lisible par N'IMPORTE QUELLE automatisation, même sans lien de chaînage entre
 * elles. Ça permet des scénarios comme un compteur partagé ("combien de fois débloqué
 * aujourd'hui") incrémenté par une automatisation et lu par une autre complètement séparée.
 */
object VariableStore {
    private const val PREFS = "block_auto_global_variables"

    fun get(context: Context, name: String): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(name, null)

    fun set(context: Context, name: String, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(name, value).apply()
    }
}
