package com.blockauto.app.nfc

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blockauto.app.R
import com.blockauto.app.databinding.ActivityNfcWriteBinding
import com.blockauto.app.store.PremiumManager
import com.blockauto.app.store.StoreActivity
import com.google.android.material.snackbar.Snackbar

/**
 * Écran "Tags NFC personnalisés" (fonctionnalité premium — voir [PremiumManager]) :
 * écrit du texte libre ou une URL classique sur un tag, indépendamment du système
 * d'automatisations (n'importe quel téléphone pourra lire ce tag, pas seulement un
 * appareil avec BlockAuto installé).
 */
class NfcWriteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNfcWriteBinding
    private var waitingDialog: AlertDialog? = null
    private var pendingMessage: android.nfc.NdefMessage? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNfcWriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        if (!PremiumManager.isUnlocked(this, PremiumManager.FeatureId.NFC_CUSTOM_TAGS)) {
            AlertDialog.Builder(this)
                .setTitle(R.string.store_locked_title)
                .setMessage(getString(R.string.store_locked_message, PremiumManager.FeatureId.NFC_CUSTOM_TAGS.displayName))
                .setPositiveButton(R.string.store_locked_open_store) { _, _ ->
                    startActivity(Intent(this, StoreActivity::class.java))
                    finish()
                }
                .setNegativeButton(android.R.string.cancel) { _, _ -> finish() }
                .setCancelable(false)
                .show()
            return
        }

        if (!NfcHelper.isAvailable(this)) {
            Snackbar.make(binding.root, R.string.nfc_not_available, Snackbar.LENGTH_LONG).show()
        }

        binding.btnStartWrite.setOnClickListener {
            val content = binding.inputContent.text?.toString()?.trim().orEmpty()
            if (content.isEmpty()) {
                Snackbar.make(binding.root, R.string.nfc_write_content_missing, Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pendingMessage = if (binding.radioUrl.isChecked) {
                NfcHelper.buildUriMessage(if (content.contains("://")) content else "https://$content")
            } else {
                NfcHelper.buildTextMessage(content)
            }
            waitingDialog = AlertDialog.Builder(this)
                .setTitle(R.string.nfc_waiting_title)
                .setMessage(R.string.nfc_write_custom_waiting_message)
                .setNegativeButton(android.R.string.cancel) { _, _ -> pendingMessage = null }
                .setCancelable(true)
                .show()
            NfcHelper.enableForegroundDispatch(this)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val message = pendingMessage ?: return
        val tag = NfcHelper.extractTag(intent) ?: return
        pendingMessage = null
        waitingDialog?.dismiss()
        when (val result = NfcHelper.write(tag, message)) {
            NfcHelper.WriteResult.Success ->
                Snackbar.make(binding.root, R.string.nfc_write_custom_success, Snackbar.LENGTH_LONG).show()
            is NfcHelper.WriteResult.Failure ->
                Snackbar.make(binding.root, getString(R.string.nfc_write_error) + " (${result.reason})", Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        super.onPause()
        NfcHelper.disableForegroundDispatch(this)
    }
}
