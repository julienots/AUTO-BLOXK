package com.blockauto.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Une ligne de l'historique : preuve visible que l'app a bien tourné, app fermée ou non. */
data class HistoryEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val automationName: String,
    val message: String
)

/**
 * Journal local de toutes les exécutions. Sert à vérifier que les automatisations
 * se déclenchent bien même quand l'app est fermée / le téléphone verrouillé :
 * ce journal continue de se remplir en arrière-plan, indépendamment de l'app ouverte.
 */
object HistoryRepository {
    private const val PREFS = "block_auto_history"
    private const val KEY = "entries_json"
    private const val MAX_ENTRIES = 200
    private val gson = Gson()

    fun add(context: Context, automationName: String, message: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val list = getAll(context)
        list.add(0, HistoryEntry(System.currentTimeMillis(), automationName, message))
        while (list.size > MAX_ENTRIES) list.removeAt(list.size - 1)
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
    }

    fun getAll(context: Context): MutableList<HistoryEntry> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<HistoryEntry>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun formatTime(timestamp: Long): String =
        SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRANCE).format(Date(timestamp))
}
