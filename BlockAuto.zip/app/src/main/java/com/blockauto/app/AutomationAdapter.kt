package com.blockauto.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.databinding.ItemAutomationBinding
import com.blockauto.app.model.Automation
import com.blockauto.app.model.color
import com.blockauto.app.model.icon
import com.blockauto.app.model.paletteCategory
import com.blockauto.app.model.requiredAccess
import com.blockauto.app.ui.BadgeStyle

class AutomationAdapter(
    private val onClick: (Automation) -> Unit,
    private val onToggle: (Automation, Boolean) -> Unit,
    private val onRun: (Automation) -> Unit,
    private val onDelete: (Automation) -> Unit,
    private val onDuplicate: (Automation) -> Unit,
    private val onExport: (Automation) -> Unit
) : RecyclerView.Adapter<AutomationAdapter.VH>() {

    private var items: List<Automation> = emptyList()

    fun submitList(list: List<Automation>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemAutomationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemAutomationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        holder.binding.textName.text = item.name.ifBlank { "Sans nom" }
        val triggerLabel = item.trigger?.type?.label ?: "Aucun déclencheur"
        holder.binding.badgeTriggerIcon.text = item.trigger?.type?.icon() ?: "⚙️"
        holder.binding.textTrigger.text = "Quand : $triggerLabel"

        // Aperçu de la chaîne façon "rouages" : déclencheur ➜ blocs, en icônes.
        val icons = item.actions.map { it.type.icon() }
        val shown = icons.take(9).joinToString("  ")
        val more = if (icons.size > 9) "  +${icons.size - 9}" else ""
        holder.binding.textBlocksPreview.text = if (icons.isEmpty()) {
            "${holder.binding.badgeTriggerIcon.text}  ➜  aucun bloc"
        } else {
            "${holder.binding.badgeTriggerIcon.text}  ➜  $shown$more"
        }
        // Les automatisations désactivées restent lisibles mais passent au second plan.
        holder.binding.root.alpha = if (item.enabled) 1f else 0.62f

        // Logo rond + barre d'accent + puce, tous teintés selon la couleur "façon Scratch"
        // de la catégorie du déclencheur : reconnaissable d'un coup d'œil dans la liste.
        val category = item.trigger?.type?.paletteCategory()
        val categoryColor = category?.color() ?: androidx.core.content.ContextCompat.getColor(context, R.color.accent_violet)
        BadgeStyle.applyLogo(holder.binding.badgeTriggerIcon, categoryColor)
        BadgeStyle.applyAccentBar(holder.binding.viewAccentBar, categoryColor)
        BadgeStyle.applyCategoryChip(
            holder.binding.textCategoryChip,
            categoryColor,
            category?.label ?: "Non configuré"
        )
        holder.binding.root.strokeColor = android.graphics.Color.argb(
            0x55,
            android.graphics.Color.red(categoryColor),
            android.graphics.Color.green(categoryColor),
            android.graphics.Color.blue(categoryColor)
        )

        val access = item.requiredAccess()
        holder.binding.textPermissions.text = if (access.isEmpty()) "Aucun accès particulier"
            else "Prend : ${access.joinToString(", ")}"

        // Statistiques d'exécution : combien de fois, la dernière fois, et si elle est
        // actuellement en pause temporaire (bloc "Mettre en pause pendant X minutes").
        holder.binding.textStats.text = when {
            item.pausedUntil > System.currentTimeMillis() -> {
                val remainingMin = (item.pausedUntil - System.currentTimeMillis()) / 60_000L + 1
                "⏸️ En pause encore ${remainingMin} min"
            }
            item.runCount == 0 -> "${item.actions.size} bloc(s) • jamais exécutée"
            else -> {
                val date = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.FRANCE).format(java.util.Date(item.lastRunAt))
                val statusIcon = if (item.lastRunSuccess) "✅" else "⚠️"
                "$statusIcon ${item.runCount}× • ${item.actions.size} bloc(s) • $date"
            }
        }

        holder.binding.switchEnabled.setOnCheckedChangeListener(null)
        holder.binding.switchEnabled.isChecked = item.enabled
        holder.binding.switchEnabled.setOnCheckedChangeListener { _, checked ->
            holder.binding.root.animate().alpha(if (checked) 1f else 0.62f).setDuration(180).start()
            onToggle(item, checked)
        }
        holder.binding.root.setOnClickListener { onClick(item) }
        holder.binding.btnRun.setOnClickListener { onRun(item) }
        holder.binding.btnDuplicate.setOnClickListener { onDuplicate(item) }
        holder.binding.btnExport.setOnClickListener { onExport(item) }
        holder.binding.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size
}
