package com.blockauto.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.databinding.ItemAutomationBinding
import com.blockauto.app.model.Automation
import com.blockauto.app.model.icon

class AutomationAdapter(
    private val onClick: (Automation) -> Unit,
    private val onToggle: (Automation, Boolean) -> Unit,
    private val onRun: (Automation) -> Unit,
    private val onDelete: (Automation) -> Unit
) : RecyclerView.Adapter<AutomationAdapter.VH>() {

    private var items: List<Automation> = emptyList()

    fun submitList(list: List<Automation>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemAutomationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemAutomationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.textName.text = item.name.ifBlank { "Sans nom" }
        val triggerLabel = item.trigger?.type?.label ?: "Aucun déclencheur"
        holder.binding.badgeTriggerIcon.text = item.trigger?.type?.icon() ?: "⚙️"
        holder.binding.textTrigger.text = "Déclencheur : $triggerLabel • ${item.actions.size} bloc(s)"
        holder.binding.switchEnabled.setOnCheckedChangeListener(null)
        holder.binding.switchEnabled.isChecked = item.enabled
        holder.binding.switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(item, checked) }
        holder.binding.root.setOnClickListener { onClick(item) }
        holder.binding.btnRun.setOnClickListener { onRun(item) }
        holder.binding.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size
}
