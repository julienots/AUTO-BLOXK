package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

/**
 * Déclenche "Application installée" / "Application désinstallée". ACTION_PACKAGE_ADDED et
 * ACTION_PACKAGE_REMOVED font partie des rares diffusions implicites exemptées des restrictions
 * en arrière-plan d'Android 8+, donc une déclaration statique dans le manifeste suffit (pas
 * besoin du service de veille pour celles-ci).
 */
class PackageReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pkg = intent.data?.schemeSpecificPart ?: return
        if (pkg == context.packageName) return
        // EXTRA_REPLACING = true signifie "mise à jour d'une app déjà installée", pas une
        // vraie installation/désinstallation : on l'ignore pour ne déclencher que sur de
        // vrais ajouts/retraits, comme s'y attend l'utilisateur.
        if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return

        val targetType = when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED -> TriggerType.APP_INSTALLED
            Intent.ACTION_PACKAGE_REMOVED -> TriggerType.APP_UNINSTALLED
            else -> return
        }
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == targetType) {
                val filterPkg = a.trigger?.params?.get("package")
                if (filterPkg.isNullOrBlank() || filterPkg == pkg) {
                    AutomationExecutionService.start(context, a.id, mapOf("package" to pkg))
                }
            }
        }
    }
}
