package com.blockauto.app.builder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.R
import com.blockauto.app.databinding.ItemActionBlockBinding
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.BlockCategory
import com.blockauto.app.model.category
import com.blockauto.app.model.icon

class ActionBlockAdapter(
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<ActionBlockAdapter.VH>() {

    private var items: MutableList<ActionBlock> = mutableListOf()

    fun submitList(list: MutableList<ActionBlock>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemActionBlockBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemActionBlockBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.textBlockLabel.text = "${position + 1}. ${item.type.label}"
        holder.binding.badgeIcon.text = item.type.icon()
        val badgeRes = when (item.type.category()) {
            BlockCategory.LOGIC -> R.drawable.bg_badge_logic
            BlockCategory.CONNECTOR -> R.drawable.bg_badge_connector
            else -> R.drawable.bg_badge_action
        }
        holder.binding.badgeIcon.setBackgroundResource(badgeRes)
        val detail = item.params.entries.joinToString(", ") { "${it.key} = ${it.value}" }
        holder.binding.textBlockDetail.text = detail
        holder.binding.textBlockDetail.visibility = if (detail.isBlank()) View.GONE else View.VISIBLE
        holder.binding.btnRemoveBlock.setOnClickListener { onRemove(position) }
    }

    override fun getItemCount() = items.size
}
