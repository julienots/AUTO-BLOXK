package com.blockauto.app.builder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.R
import com.blockauto.app.databinding.ItemActionBlockBinding
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.BlockCategory
import com.blockauto.app.model.category
import com.blockauto.app.model.icon

class ActionBlockAdapter(
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<ActionBlockAdapter.VH>() {

    private var items: MutableList<ActionBlock> = mutableListOf()

    fun submitList(list: MutableList<ActionBlock>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemActionBlockBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemActionBlockBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        holder.binding.textBlockLabel.text = "${position + 1}. ${item.type.label}"
        holder.binding.badgeIcon.text = item.type.icon()

        val (badgeRes, accentColorRes) = when (item.type.category()) {
            BlockCategory.LOGIC -> R.drawable.bg_badge_logic to R.color.accent_amber
            BlockCategory.CONNECTOR -> R.drawable.bg_badge_connector to R.color.accent_blue
            BlockCategory.CHAIN -> R.drawable.bg_badge_chain to R.color.accent_teal
            BlockCategory.VARIABLE -> R.drawable.bg_badge_variable to R.color.accent_success
            else -> R.drawable.bg_badge_action to R.color.accent_violet
        }
        holder.binding.badgeIcon.setBackgroundResource(badgeRes)

        // Chaque bloc s'emboîte dans le suivant : encoche en haut (reçoit la languette du
        // bloc précédent), languette en bas (s'emboîte dans le bloc suivant) — un vrai bloc
        // de chaîne plutôt qu'une carte isolée, sur toute la pile d'actions.
        val puzzle = holder.itemView as PuzzleBlockView
        puzzle.hasTopNotch = true
        puzzle.hasBottomTab = true
        puzzle.setColors(
            accent = ContextCompat.getColor(context, accentColorRes),
            fill = ContextCompat.getColor(context, R.color.bg_surface_elevated)
        )

        val detail = item.params.entries.joinToString(", ") { "${it.key} = ${it.value}" }
        holder.binding.textBlockDetail.text = detail
        holder.binding.textBlockDetail.visibility = if (detail.isBlank()) View.GONE else View.VISIBLE
        holder.binding.btnRemoveBlock.setOnClickListener { onRemove(position) }
    }

    override fun getItemCount() = items.size
}
