package com.blockauto.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerType
import com.blockauto.app.receivers.AlarmReceiver
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/** Codes de jour (Calendar) utilisés par le bloc "Heure précise, certains jours". */
private val DAY_CODES = mapOf(
    "SU" to Calendar.SUNDAY, "MO" to Calendar.MONDAY, "TU" to Calendar.TUESDAY,
    "WE" to Calendar.WEDNESDAY, "TH" to Calendar.THURSDAY, "FR" to Calendar.FRIDAY, "SA" to Calendar.SATURDAY
)

/** Programme / annule les alarmes système pour tous les déclencheurs basés sur le temps
 *  (Heure précise, Intervalle, et les variantes avancées : jours précis, heure aléatoire,
 *  compte à rebours unique, intervalle limité dans le temps). */
object TriggerScheduler {

    fun schedule(context: Context, automation: Automation) {
        cancel(context, automation.id)
        val trigger = automation.trigger ?: return
        if (!automation.enabled) return

        when (trigger.type) {
            TriggerType.TIME -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: return
                val minute = trigger.params["minute"]?.toIntOrNull() ?: return
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.INTERVAL -> {
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.WEEKDAY_TIME -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: return
                val minute = trigger.params["minute"]?.toIntOrNull() ?: return
                val wantedDays = trigger.params["days"]?.split(",")?.mapNotNull { DAY_CODES[it.trim()] }?.toSet().orEmpty()
                var cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }
                // Avance jour par jour (jusqu'à 8 pour couvrir une semaine entière + marge) tant
                // que ce n'est pas un jour choisi ou que l'heure est déjà passée aujourd'hui.
                var guard = 0
                while (guard < 8 && (cal.before(Calendar.getInstance()) ||
                        (wantedDays.isNotEmpty() && cal.get(Calendar.DAY_OF_WEEK) !in wantedDays))) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                    guard++
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.RANDOM_DAILY_TIME -> {
                val startH = trigger.params["start_hour"]?.toIntOrNull() ?: 8
                val startM = trigger.params["start_minute"]?.toIntOrNull() ?: 0
                val endH = trigger.params["end_hour"]?.toIntOrNull() ?: 20
                val endM = trigger.params["end_minute"]?.toIntOrNull() ?: 0
                val startTotal = startH * 60 + startM
                val endTotal = (endH * 60 + endM).coerceAtLeast(startTotal + 1)
                val randomMinuteOfDay = (startTotal..endTotal).random()
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, randomMinuteOfDay / 60)
                    set(Calendar.MINUTE, randomMinuteOfDay % 60)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.COUNTDOWN_ONCE -> {
                // Bloc "une seule fois" : une fois consommé (voir AlarmReceiver), on ne
                // reprogramme plus rien — l'automatisation reste visible mais désactivée.
                if (trigger.params["consumed"] == "true") return
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.INTERVAL_LIMITED -> {
                // "Toutes les X minutes, N fois" : un compteur "times_left" est décrémenté par
                // AlarmReceiver à chaque déclenchement ; une fois à 0, plus rien n'est reprogrammé.
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val timesLeft = trigger.params["times_left"]?.toIntOrNull()
                    ?: trigger.params["times"]?.toIntOrNull() ?: 1
                if (timesLeft <= 0) return
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.MONTHLY_DATE -> {
                val day = (trigger.params["day"]?.toIntOrNull() ?: 1).coerceIn(1, 28)
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.MONTH, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.YEARLY_DATE -> {
                val day = trigger.params["day"]?.toIntOrNull() ?: return
                val month = trigger.params["month"]?.toIntOrNull() ?: return
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.MONTH, (month - 1).coerceIn(0, 11))
                    set(Calendar.DAY_OF_MONTH, day.coerceIn(1, 28))
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.RANDOM_INTERVAL -> {
                // "Toutes les X à Y minutes" : à chaque tour, on retire un délai différent au
                // hasard dans la fourchette — donne un rythme moins mécanique qu'un intervalle fixe.
                val minMinutes = (trigger.params["min_minutes"]?.toIntOrNull() ?: 15).coerceAtLeast(1)
                val maxMinutes = (trigger.params["max_minutes"]?.toIntOrNull() ?: 45).coerceAtLeast(minMinutes)
                val minutes = (minMinutes..maxMinutes).random()
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            else -> { /* les autres déclencheurs sont gérés par des receivers / le service de veille */ }
        }
    }

    private fun scheduleExact(context: Context, automationId: String, atMillis: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("automation_id", automationId)
        }
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                // Sans accès aux alarmes exactes, on conserve l'automatisation avec une alarme
                // inexacte plutôt que de la perdre silencieusement.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    fun cancel(context: Context, automationId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** Types de déclencheurs gérés par des alarmes système (par opposition aux
     *  receivers / au service de veille pour tous les autres types). */
    private val ALARM_BASED_TYPES = setOf(
        TriggerType.TIME, TriggerType.INTERVAL, TriggerType.WEEKDAY_TIME,
        TriggerType.RANDOM_DAILY_TIME, TriggerType.COUNTDOWN_ONCE, TriggerType.INTERVAL_LIMITED,
        TriggerType.MONTHLY_DATE, TriggerType.YEARLY_DATE, TriggerType.RANDOM_INTERVAL
    )

    fun scheduleAll(context: Context) {
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            val type = a.trigger?.type
            if (a.enabled && type != null && type in ALARM_BASED_TYPES) {
                schedule(context, a)
            }
        }
    }
}
