package com.blockauto.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerType
import com.blockauto.app.receivers.AlarmReceiver
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/** Codes de jour (Calendar) utilisés par le bloc "Heure précise, certains jours". */
private val DAY_CODES = mapOf(
    "SU" to Calendar.SUNDAY, "MO" to Calendar.MONDAY, "TU" to Calendar.TUESDAY,
    "WE" to Calendar.WEDNESDAY, "TH" to Calendar.THURSDAY, "FR" to Calendar.FRIDAY, "SA" to Calendar.SATURDAY
)

/** Programme / annule les alarmes système pour tous les déclencheurs basés sur le temps
 *  (Heure précise, Intervalle, et les variantes avancées : jours précis, heure aléatoire,
 *  compte à rebours unique, intervalle limité dans le temps). */
object TriggerScheduler {

    fun schedule(context: Context, automation: Automation) {
        cancel(context, automation.id)
        val trigger = automation.trigger ?: return
        if (!automation.enabled) return

        when (trigger.type) {
            TriggerType.TIME -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: return
                val minute = trigger.params["minute"]?.toIntOrNull() ?: return
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.INTERVAL -> {
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.WEEKDAY_TIME -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: return
                val minute = trigger.params["minute"]?.toIntOrNull() ?: return
                val wantedDays = trigger.params["days"]?.split(",")?.mapNotNull { DAY_CODES[it.trim()] }?.toSet().orEmpty()
                var cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }
                // Avance jour par jour (jusqu'à 8 pour couvrir une semaine entière + marge) tant
                // que ce n'est pas un jour choisi ou que l'heure est déjà passée aujourd'hui.
                var guard = 0
                while (guard < 8 && (cal.before(Calendar.getInstance()) ||
                        (wantedDays.isNotEmpty() && cal.get(Calendar.DAY_OF_WEEK) !in wantedDays))) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                    guard++
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.RANDOM_DAILY_TIME -> {
                val startH = trigger.params["start_hour"]?.toIntOrNull() ?: 8
                val startM = trigger.params["start_minute"]?.toIntOrNull() ?: 0
                val endH = trigger.params["end_hour"]?.toIntOrNull() ?: 20
                val endM = trigger.params["end_minute"]?.toIntOrNull() ?: 0
                val startTotal = startH * 60 + startM
                val endTotal = (endH * 60 + endM).coerceAtLeast(startTotal + 1)
                val randomMinuteOfDay = (startTotal..endTotal).random()
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, randomMinuteOfDay / 60)
                    set(Calendar.MINUTE, randomMinuteOfDay % 60)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.COUNTDOWN_ONCE -> {
                // Bloc "une seule fois" : une fois consommé (voir AlarmReceiver), on ne
                // reprogramme plus rien — l'automatisation reste visible mais désactivée.
                if (trigger.params["consumed"] == "true") return
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.INTERVAL_LIMITED -> {
                // "Toutes les X minutes, N fois" : un compteur "times_left" est décrémenté par
                // AlarmReceiver à chaque déclenchement ; une fois à 0, plus rien n'est reprogrammé.
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val timesLeft = trigger.params["times_left"]?.toIntOrNull()
                    ?: trigger.params["times"]?.toIntOrNull() ?: 1
                if (timesLeft <= 0) return
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.MONTHLY_DATE -> {
                val day = (trigger.params["day"]?.toIntOrNull() ?: 1).coerceIn(1, 28)
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.MONTH, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.YEARLY_DATE -> {
                val day = trigger.params["day"]?.toIntOrNull() ?: return
                val month = trigger.params["month"]?.toIntOrNull() ?: return
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.MONTH, (month - 1).coerceIn(0, 11))
                    set(Calendar.DAY_OF_MONTH, day.coerceIn(1, 28))
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.EVERY_N_HOURS -> {
                // Variante en heures de "Toutes les X minutes" : plus pratique pour les
                // rappels espacés (toutes les 2h, 6h, 12h...) sans avoir à convertir en minutes.
                val hours = (trigger.params["hours"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + hours * 3_600_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.RANDOM_INTERVAL -> {
                // "Toutes les X à Y minutes" : à chaque tour, on retire un délai différent au
                // hasard dans la fourchette — donne un rythme moins mécanique qu'un intervalle fixe.
                val minMinutes = (trigger.params["min_minutes"]?.toIntOrNull() ?: 15).coerceAtLeast(1)
                val maxMinutes = (trigger.params["max_minutes"]?.toIntOrNull() ?: 45).coerceAtLeast(minMinutes)
                val minutes = (minMinutes..maxMinutes).random()
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            TriggerType.TIME_WINDOW_INTERVAL -> {
                // "Toutes les X minutes, seulement entre HH:MM et HH:MM" : un intervalle classique,
                // mais qui reste silencieux hors de sa fenêtre horaire (utile pour des rappels
                // fréquents la journée sans jamais sonner la nuit, par ex.).
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val startH = trigger.params["start_hour"]?.toIntOrNull() ?: 8
                val startM = trigger.params["start_minute"]?.toIntOrNull() ?: 0
                val endH = trigger.params["end_hour"]?.toIntOrNull() ?: 22
                val endM = trigger.params["end_minute"]?.toIntOrNull() ?: 0
                val windowStart = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, startH); set(Calendar.MINUTE, startM); set(Calendar.SECOND, 0)
                }
                val windowEnd = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, endH); set(Calendar.MINUTE, endM); set(Calendar.SECOND, 0)
                }
                var candidate = Calendar.getInstance().apply { add(Calendar.MINUTE, minutes) }
                if (candidate.before(windowStart)) {
                    candidate = windowStart.clone() as Calendar
                } else if (candidate.after(windowEnd)) {
                    candidate = windowStart.clone() as Calendar
                    if (candidate.before(Calendar.getInstance())) candidate.add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, candidate.timeInMillis)
            }
            TriggerType.FULL_MOON -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
                }
                if (cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR, 1)
                var guard = 0
                while (guard < 40 && !isFullMoon(cal)) { cal.add(Calendar.DAY_OF_YEAR, 1); guard++ }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.FRIDAY_13TH -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
                }
                if (cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR, 1)
                var guard = 0
                while (guard < 400 && !isFriday13(cal)) { cal.add(Calendar.DAY_OF_YEAR, 1); guard++ }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.PALINDROME_TIME -> {
                // Se déclenche automatiquement à chaque heure "palindrome" de la journée
                // (11:11, 12:21, 13:31, 20:02...), sans aucun réglage à faire.
                val cal = Calendar.getInstance().apply { set(Calendar.SECOND, 0) }
                var guard = 0
                do {
                    cal.add(Calendar.MINUTE, 1)
                    guard++
                } while (guard < 1441 && !isPalindromeTime(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)))
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.SUNRISE, TriggerType.SUNSET -> {
                val lat = trigger.params["lat"]?.replace(',', '.')?.toDoubleOrNull() ?: 48.8566
                val lon = trigger.params["lon"]?.replace(',', '.')?.toDoubleOrNull() ?: 2.3522
                val offsetMs = (trigger.params["offset"]?.toLongOrNull() ?: 0L) * 60_000L
                val isSunrise = trigger.type == TriggerType.SUNRISE
                val threshold = System.currentTimeMillis() + 30_000L
                val day = Calendar.getInstance()
                for (i in 0 until 3) {
                    val at = sunEventMillis(day, lat, lon, isSunrise)?.plus(offsetMs)
                    if (at != null && at > threshold) {
                        scheduleExact(context, automation.id, at)
                        return
                    }
                    day.add(Calendar.DAY_OF_YEAR, 1)
                }
            }
            TriggerType.MULTI_TIMES_DAILY -> {
                val times = (trigger.params["times"] ?: "").split(",", ";", " ")
                    .mapNotNull { raw ->
                        val parts = raw.trim().replace('h', ':').split(":")
                        val h = parts.getOrNull(0)?.toIntOrNull()
                        val m = parts.getOrNull(1)?.takeIf { it.isNotBlank() }?.toIntOrNull() ?: 0
                        if (h != null && h in 0..23 && m in 0..59) h to m else null
                    }
                if (times.isEmpty()) return
                val threshold = System.currentTimeMillis() + 30_000L
                val next = (0..1).flatMap { dayOffset ->
                    times.map { (h, m) ->
                        Calendar.getInstance().apply {
                            add(Calendar.DAY_OF_YEAR, dayOffset)
                            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
                            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    }
                }.filter { it > threshold }.minOrNull() ?: return
                scheduleExact(context, automation.id, next)
            }
            TriggerType.HOURLY_CHIME -> {
                val start = (trigger.params["start_hour"]?.toIntOrNull() ?: 8).coerceIn(0, 23)
                val end = (trigger.params["end_hour"]?.toIntOrNull() ?: 22).coerceIn(0, 23)
                val cal = Calendar.getInstance().apply {
                    add(Calendar.HOUR_OF_DAY, 1)
                    set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                var guard = 0
                while (guard < 48 && !hourInRange(cal.get(Calendar.HOUR_OF_DAY), start, end)) {
                    cal.add(Calendar.HOUR_OF_DAY, 1)
                    guard++
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.LAST_DAY_OF_MONTH -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: 9
                val minute = trigger.params["minute"]?.toIntOrNull() ?: 0
                fun lastDayOf(monthOffset: Int) = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    add(Calendar.MONTH, monthOffset)
                    set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                var cal = lastDayOf(0)
                if (cal.timeInMillis <= System.currentTimeMillis() + 30_000L) cal = lastDayOf(1)
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            else -> { /* les autres déclencheurs sont gérés par des receivers / le service de veille */ }
        }
    }

    private fun hourInRange(hour: Int, start: Int, end: Int): Boolean =
        if (start <= end) hour in start..end else hour >= start || hour <= end

    /**
     * Heure (UTC, en millisecondes) du lever ou du coucher du soleil pour une date et une
     * position données — algorithme classique de l'almanach nautique (précision ≈ 1–2 min),
     * calculé localement sans aucun service en ligne. Retourne null les jours sans lever ou
     * sans coucher (nuit/jour polaire).
     */
    private fun sunEventMillis(day: Calendar, lat: Double, lon: Double, sunrise: Boolean): Long? {
        fun rad(d: Double) = Math.toRadians(d)
        fun deg(r: Double) = Math.toDegrees(r)
        fun norm(v: Double, max: Double) = ((v % max) + max) % max
        val dayOfYear = day.get(Calendar.DAY_OF_YEAR)
        val lngHour = lon / 15.0
        val t = dayOfYear + ((if (sunrise) 6.0 else 18.0) - lngHour) / 24.0
        val meanAnomaly = 0.9856 * t - 3.289
        val trueLong = norm(meanAnomaly + 1.916 * Math.sin(rad(meanAnomaly)) + 0.020 * Math.sin(rad(2 * meanAnomaly)) + 282.634, 360.0)
        var rightAsc = norm(deg(Math.atan(0.91764 * Math.tan(rad(trueLong)))), 360.0)
        rightAsc += Math.floor(trueLong / 90.0) * 90.0 - Math.floor(rightAsc / 90.0) * 90.0
        rightAsc /= 15.0
        val sinDec = 0.39782 * Math.sin(rad(trueLong))
        val cosDec = Math.cos(Math.asin(sinDec))
        val cosH = (Math.cos(rad(90.833)) - sinDec * Math.sin(rad(lat))) / (cosDec * Math.cos(rad(lat)))
        if (cosH > 1 || cosH < -1) return null
        val hourAngle = (if (sunrise) 360.0 - deg(Math.acos(cosH)) else deg(Math.acos(cosH))) / 15.0
        val localMeanTime = hourAngle + rightAsc - 0.06571 * t - 6.622
        val utcHours = norm(localMeanTime - lngHour, 24.0)
        val utc = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(day.get(Calendar.YEAR), day.get(Calendar.MONTH), day.get(Calendar.DAY_OF_MONTH), 0, 0, 0)
        }
        return utc.timeInMillis + (utcHours * 3_600_000).toLong()
    }

    /** Approximation classique du cycle synodique lunaire (≈29,53 jours) à partir d'une
     *  nouvelle lune de référence connue (6 janvier 2000, 18:14 UTC) : suffisant pour un
     *  déclencheur "pour le fun", sans dépendre d'un service en ligne. */
    private fun isFullMoon(cal: Calendar): Boolean {
        val synodicMonth = 29.53058867
        val knownNewMoon = java.util.GregorianCalendar(2000, 0, 6, 18, 14).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }.timeInMillis
        val diffDays = (cal.timeInMillis - knownNewMoon) / 86_400_000.0
        val phase = (diffDays % synodicMonth + synodicMonth) % synodicMonth
        return kotlin.math.abs(phase - synodicMonth / 2) < 1.0
    }

    private fun isFriday13(cal: Calendar): Boolean =
        cal.get(Calendar.DAY_OF_MONTH) == 13 && cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY

    private fun isPalindromeTime(hour: Int, minute: Int): Boolean {
        val s = String.format("%02d%02d", hour, minute)
        return s == s.reversed()
    }

    private fun scheduleExact(context: Context, automationId: String, atMillis: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("automation_id", automationId)
        }
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                // Sans accès aux alarmes exactes, on conserve l'automatisation avec une alarme
                // inexacte plutôt que de la perdre silencieusement.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    fun cancel(context: Context, automationId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** Types de déclencheurs gérés par des alarmes système (par opposition aux
     *  receivers / au service de veille pour tous les autres types). */
    private val ALARM_BASED_TYPES = setOf(
        TriggerType.TIME, TriggerType.INTERVAL, TriggerType.WEEKDAY_TIME,
        TriggerType.RANDOM_DAILY_TIME, TriggerType.COUNTDOWN_ONCE, TriggerType.INTERVAL_LIMITED,
        TriggerType.MONTHLY_DATE, TriggerType.YEARLY_DATE, TriggerType.RANDOM_INTERVAL,
        TriggerType.EVERY_N_HOURS, TriggerType.TIME_WINDOW_INTERVAL, TriggerType.FULL_MOON,
        TriggerType.FRIDAY_13TH, TriggerType.PALINDROME_TIME,
        TriggerType.SUNRISE, TriggerType.SUNSET, TriggerType.MULTI_TIMES_DAILY,
        TriggerType.HOURLY_CHIME, TriggerType.LAST_DAY_OF_MONTH
    )

    fun scheduleAll(context: Context) {
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            val type = a.trigger?.type
            if (a.enabled && type != null && type in ALARM_BASED_TYPES) {
                schedule(context, a)
            }
        }
    }
}
