package com.blockauto.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerType
import com.blockauto.app.receivers.AlarmReceiver
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/** Programme / annule les alarmes système pour les déclencheurs "Heure précise" et "Intervalle". */
object TriggerScheduler {

    fun schedule(context: Context, automation: Automation) {
        cancel(context, automation.id)
        val trigger = automation.trigger ?: return
        if (!automation.enabled) return

        when (trigger.type) {
            TriggerType.TIME -> {
                val hour = trigger.params["hour"]?.toIntOrNull() ?: return
                val minute = trigger.params["minute"]?.toIntOrNull() ?: return
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleExact(context, automation.id, cal.timeInMillis)
            }
            TriggerType.INTERVAL -> {
                val minutes = (trigger.params["minutes"]?.toIntOrNull() ?: 30).coerceAtLeast(1)
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                scheduleExact(context, automation.id, triggerAt)
            }
            else -> { /* les autres déclencheurs sont gérés par des receivers / le service de veille */ }
        }
    }

    private fun scheduleExact(context: Context, automationId: String, atMillis: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("automation_id", automationId)
        }
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    fun cancel(context: Context, automationId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, automationId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun scheduleAll(context: Context) {
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && (a.trigger?.type == TriggerType.TIME || a.trigger?.type == TriggerType.INTERVAL)) {
                schedule(context, a)
            }
        }
    }
}
