package com.blockauto.app.builder

import android.app.Activity
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.blockauto.app.R
import com.blockauto.app.model.BlockField
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Formulaire généré automatiquement à partir d'une liste de [BlockField] : un seul écran
 * pour tous les champs texte / nombre (avec libellé, valeur par défaut et bornes), puis un
 * choix par liste pour chaque champ [BlockField.Choice] et un sélecteur d'appli pour chaque
 * [BlockField.App]. Évite d'écrire une boîte de dialogue sur mesure pour chaque bloc.
 */
class BlockFieldForm(
    private val activity: Activity,
    private val pickApp: (onPicked: (String) -> Unit) -> Unit
) {

    fun ask(title: String, help: String?, fields: List<BlockField>, onDone: (MutableMap<String, String>) -> Unit) {
        val result = mutableMapOf<String, String>()
        val inputs = fields.filter { it is BlockField.Text || it is BlockField.Number }
        val rest = fields.filter { it is BlockField.Choice || it is BlockField.App }
        if (inputs.isEmpty() && help == null) {
            askSequential(rest, 0, result, onDone)
            return
        }
        if (inputs.isEmpty()) {
            MaterialAlertDialogBuilder(activity)
                .setTitle(title)
                .setMessage(help)
                .setPositiveButton("Continuer") { _, _ -> askSequential(rest, 0, result, onDone) }
                .setNegativeButton("Annuler", null)
                .show()
            return
        }

        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(4))
        }
        if (help != null) {
            container.addView(TextView(activity).apply {
                text = help
                setTextColor(ContextCompat.getColor(activity, R.color.text_secondary))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(0, 0, 0, dp(10))
            })
        }
        val editors = inputs.map { field ->
            container.addView(TextView(activity).apply {
                text = field.label
                setTextColor(ContextCompat.getColor(activity, R.color.text_secondary))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(4), dp(10), 0, dp(4))
            })
            val edit = EditText(activity).apply {
                background = ContextCompat.getDrawable(activity, R.drawable.bg_input_field)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setTextColor(ContextCompat.getColor(activity, R.color.text_primary))
                setHintTextColor(ContextCompat.getColor(activity, R.color.text_muted))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                when (field) {
                    is BlockField.Number -> {
                        inputType = InputType.TYPE_CLASS_NUMBER or
                            (if (field.min < 0) InputType.TYPE_NUMBER_FLAG_SIGNED else 0)
                        setText(field.default.toString())
                        hint = "${field.min} – ${field.max}"
                    }
                    is BlockField.Text -> {
                        inputType = if (field.multiline) {
                            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        } else {
                            InputType.TYPE_CLASS_TEXT
                        }
                        if (field.multiline) minLines = 3
                        setText(field.default)
                        hint = "Texte ou {variable}"
                    }
                    else -> {}
                }
            }
            container.addView(edit, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            edit
        }
        val scroll = ScrollView(activity).apply { addView(container) }
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER

        MaterialAlertDialogBuilder(activity)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton(if (rest.isEmpty()) "Ajouter" else "Suivant") { _, _ ->
                var hadInvalid = false
                inputs.forEachIndexed { index, field ->
                    val typed = editors[index].text.toString()
                    val stored = if (field is BlockField.Number) {
                        val value = typed.trim().toLongOrNull()
                        if (value == null) hadInvalid = true
                        (value ?: field.default).coerceIn(field.min, field.max).toString()
                    } else {
                        typed
                    }
                    result[field.key] = stored
                }
                if (hadInvalid) {
                    Toast.makeText(activity, "Valeur invalide remplacée par la valeur par défaut", Toast.LENGTH_SHORT).show()
                }
                askSequential(rest, 0, result, onDone)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun askSequential(
        fields: List<BlockField>, index: Int, result: MutableMap<String, String>, onDone: (MutableMap<String, String>) -> Unit
    ) {
        if (index >= fields.size) {
            onDone(result)
            return
        }
        when (val field = fields[index]) {
            is BlockField.Choice -> MaterialAlertDialogBuilder(activity)
                .setTitle(field.label)
                .setItems(field.options.map { it.first }.toTypedArray()) { _, which ->
                    result[field.key] = field.options[which].second
                    askSequential(fields, index + 1, result, onDone)
                }
                .setNegativeButton("Annuler", null)
                .show()
            is BlockField.App -> pickApp { pkg ->
                result[field.key] = pkg
                askSequential(fields, index + 1, result, onDone)
            }
            else -> askSequential(fields, index + 1, result, onDone)
        }
    }
}
