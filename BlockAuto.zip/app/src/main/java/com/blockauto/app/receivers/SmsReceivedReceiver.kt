package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val sender = messages.firstOrNull()?.originatingAddress
        // Concatène les segments si le SMS a été envoyé en plusieurs morceaux (message long).
        val body = messages.joinToString("") { it.messageBody ?: "" }
        // Code de validation éventuel (4 à 8 chiffres), exposé à tous les blocs via {sms_code}.
        val code = Regex("(?<![\\d])\\d{4,8}(?![\\d])").find(body)?.value.orEmpty()
        val vars = mapOf("sms_sender" to (sender ?: ""), "sms_body" to body, "sms_code" to code)
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (!a.enabled) continue
            when (a.trigger?.type) {
                TriggerType.SMS_RECEIVED -> {
                    val filter = a.trigger?.params?.get("sender")
                    if (filter.isNullOrBlank() || filter == sender) {
                        // L'expéditeur, le texte et le code sont transmis aux blocs suivants
                        // ({sms_sender}, {sms_body}, {sms_code}).
                        AutomationExecutionService.start(context, a.id, vars)
                    }
                }
                TriggerType.SMS_CONTAINS_TEXT -> {
                    val keyword = a.trigger?.params?.get("keyword")?.trim().orEmpty()
                    if (keyword.isNotEmpty() && body.contains(keyword, ignoreCase = true)) {
                        AutomationExecutionService.start(context, a.id, vars)
                    }
                }
                else -> {}
            }
        }
    }
}
