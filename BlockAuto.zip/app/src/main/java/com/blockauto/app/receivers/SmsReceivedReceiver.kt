package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val sender = messages.firstOrNull()?.originatingAddress
        // Concatène les segments si le SMS a été envoyé en plusieurs morceaux (message long).
        val body = messages.joinToString("") { it.messageBody ?: "" }
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.SMS_RECEIVED) {
                val filter = a.trigger?.params?.get("sender")
                if (filter.isNullOrBlank() || filter == sender) {
                    // BUG CORRIGÉ : l'expéditeur et le texte du SMS n'étaient jamais transmis à
                    // l'automatisation, rendant impossible un scénario "réponds automatiquement
                    // à qui vient de m'écrire" (bloc "Envoyer un SMS" avec {sms_sender} comme
                    // numéro). Voir AutomationExecutionService/AutomationExecutor pour la suite.
                    AutomationExecutionService.start(
                        context, a.id,
                        mapOf("sms_sender" to (sender ?: ""), "sms_body" to body)
                    )
                }
            }
        }
    }
}
