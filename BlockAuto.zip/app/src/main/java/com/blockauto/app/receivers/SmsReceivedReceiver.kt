package com.blockauto.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.blockauto.app.model.TriggerType
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.storage.AutomationRepository

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val sender = messages.firstOrNull()?.originatingAddress
        val list = AutomationRepository.getAll(context)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.SMS_RECEIVED) {
                val filter = a.trigger?.params?.get("sender")
                if (filter.isNullOrBlank() || filter == sender) {
                    AutomationExecutionService.start(context, a.id)
                }
            }
        }
    }
}
