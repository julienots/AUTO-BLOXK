package com.blockauto.app.builder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.R

/**
 * Dessine, entre chaque bloc de la liste, un petit engrenage relié par un trait :
 * l'idée visuelle est que les blocs "s'enclenchent" les uns dans les autres,
 * comme des rouages d'une mécanique d'automatisation.
 */
class GearConnectorDecoration(context: Context) : RecyclerView.ItemDecoration() {

    private val gear: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_gear_connector)
    private val gearSizePx = (18 * context.resources.displayMetrics.density).toInt()
    private val linePaint = Paint().apply {
        color = ContextCompat.getColor(context, R.color.bg_stroke)
        strokeWidth = 3f
        isAntiAlias = true
    }
    private val extraSpacePx = (22 * context.resources.displayMetrics.density).toInt()

    override fun getItemOffsets(
        outRect: android.graphics.Rect,
        view: android.view.View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        val position = parent.getChildAdapterPosition(view)
        if (position > 0) outRect.top = extraSpacePx
    }

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val centerX = parent.paddingLeft + 26 * parent.resources.displayMetrics.density
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            val position = parent.getChildAdapterPosition(child)
            if (position <= 0) continue
            val gapTop = child.top - extraSpacePx
            val gapBottom = child.top
            // Trait vertical reliant le bloc précédent au suivant
            c.drawLine(centerX, gapTop.toFloat(), centerX, gapBottom.toFloat(), linePaint)
            // Petit engrenage centré dans l'espace
            gear?.let {
                val cy = (gapTop + gapBottom) / 2
                it.setBounds(
                    (centerX - gearSizePx / 2).toInt(),
                    cy - gearSizePx / 2,
                    (centerX + gearSizePx / 2).toInt(),
                    cy + gearSizePx / 2
                )
                it.draw(c)
            }
        }
    }
}
