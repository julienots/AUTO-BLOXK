package com.blockauto.app.engine

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.app.PendingIntent
import android.app.SearchManager
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.services.AppWatcherAccessibilityService
import com.blockauto.app.storage.VariableStore
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.roundToLong
import kotlin.math.sin

/**
 * Exécution des blocs ajoutés en version 3. Séparé d'[AutomationExecutor] (déjà très long)
 * pour garder chaque famille de blocs lisible : musique, système, communication,
 * navigation, infos, texte/fichiers, connecteurs et fun.
 *
 * Règle commune à tous les blocs : une erreur est signalée par [ActionExecutionException]
 * avec un message clair, qui apparaît dans l'historique au lieu d'un échec silencieux.
 */
object ExtraActions {

    private val FR = Locale.FRANCE

    suspend fun execute(context: Context, action: ActionBlock, variables: MutableMap<String, String>) {
        val p = action.params
        fun text(key: String, default: String = ""): String = AutomationExecutor.subst(p[key] ?: default, variables)
        fun int(key: String, default: Int): Int = p[key]?.trim()?.toIntOrNull() ?: default
        fun result(default: String): String = p["result_name"]?.trim().orEmpty().ifBlank { default }

        when (action.type) {
            // ================= Musique & son =================
            ActionType.MEDIA_NEXT -> mediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT)
            ActionType.MEDIA_PREVIOUS -> mediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            ActionType.MEDIA_PAUSE -> mediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE)
            ActionType.MEDIA_PLAY -> mediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY)
            ActionType.MEDIA_STOP -> mediaKey(context, KeyEvent.KEYCODE_MEDIA_STOP)
            ActionType.VOLUME_UP, ActionType.VOLUME_DOWN -> {
                val am = audio(context)
                val direction = if (action.type == ActionType.VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                try {
                    am.adjustStreamVolume(streamOf(p["stream"]), direction, AudioManager.FLAG_SHOW_UI)
                } catch (e: SecurityException) {
                    throw ActionExecutionException("Android refuse ce changement de volume (mode Ne pas déranger actif ?)")
                }
            }
            ActionType.MUTE_MEDIA -> {
                val mute = p["state"] != "off"
                audio(context).adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0
                )
            }
            ActionType.SET_NOTIFICATION_VOLUME -> setVolume(context, AudioManager.STREAM_NOTIFICATION, int("level", 5))
            ActionType.SET_CALL_VOLUME -> setVolume(context, AudioManager.STREAM_VOICE_CALL, int("level", 5))
            ActionType.PLAY_RINGTONE -> playRingtone(context, int("seconds", 10).coerceIn(1, 60), p["sound"] ?: "ringtone")
            ActionType.PLAY_MELODY -> playNotes(MELODIES[p["melody"]] ?: MELODIES.getValue("victory"))
            ActionType.PLAY_MEDIA_SEARCH -> {
                val query = text("query")
                if (query.isBlank()) throw ActionExecutionException("Indique ce qu'il faut jouer")
                startActivity(context, Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                }, "Aucune appli de musique ne gère la recherche vocale")
            }
            ActionType.SPEAK_TIME -> {
                val now = Calendar.getInstance()
                speak(context, "Il est ${now.get(Calendar.HOUR_OF_DAY)} heures ${now.get(Calendar.MINUTE).let { if (it == 0) "pile" else it.toString() }}")
            }
            ActionType.SPEAK_BATTERY -> {
                val level = AutomationExecutor.currentBatteryLevel(context)
                val charging = (context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).isCharging
                speak(context, "La batterie est à $level pour cent${if (charging) ", en charge" else ""}.")
            }
            ActionType.SPEAK_SUMMARY -> {
                val now = Calendar.getInstance()
                val name = text("name").trim()
                val greeting = when (now.get(Calendar.HOUR_OF_DAY)) {
                    in 5..11 -> "Bonjour"
                    in 12..17 -> "Bon après-midi"
                    else -> "Bonsoir"
                }
                val date = SimpleDateFormat("EEEE d MMMM", FR).format(now.time)
                val sentence = "$greeting${if (name.isNotEmpty()) " $name" else ""}. Nous sommes $date, il est " +
                    "${now.get(Calendar.HOUR_OF_DAY)} heures ${now.get(Calendar.MINUTE)}. " +
                    "La batterie est à ${AutomationExecutor.currentBatteryLevel(context)} pour cent."
                variables["briefing"] = sentence
                speak(context, sentence)
            }

            // ================= Système =================
            ActionType.FLASHLIGHT_BLINK -> {
                val count = int("count", 5).coerceIn(1, 50)
                val interval = int("interval_ms", 250).toLong().coerceIn(50, 2000)
                torchSequence(context, List(count) { interval to interval })
            }
            ActionType.FLASHLIGHT_SOS -> {
                val dot = 200L; val dash = 600L; val gap = 200L
                val letterGap = 600L
                val s = listOf(dot to gap, dot to gap, dot to letterGap)
                val o = listOf(dash to gap, dash to gap, dash to letterGap)
                torchSequence(context, s + o + s)
            }
            ActionType.SET_AUTO_BRIGHTNESS -> {
                if (!Settings.System.canWrite(context)) throw ActionExecutionException("Autorise « Modifier les réglages système »")
                Settings.System.putInt(
                    context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    if (p["state"] == "off") Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    else Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                )
            }
            ActionType.OPEN_SETTINGS_PAGE -> {
                val settingsAction = SETTINGS_PAGES[p["page"]] ?: Settings.ACTION_SETTINGS
                try {
                    startActivity(context, Intent(settingsAction), "Page de réglages introuvable")
                } catch (e: ActionExecutionException) {
                    startActivity(context, Intent(Settings.ACTION_SETTINGS), "Réglages introuvables")
                }
            }
            ActionType.OPEN_NOTIFICATION_SHADE -> globalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            ActionType.OPEN_QUICK_SETTINGS -> globalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            ActionType.OPEN_POWER_MENU -> globalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            ActionType.TOGGLE_SPLIT_SCREEN -> globalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            ActionType.CLEAR_BLOCKAUTO_NOTIFICATIONS -> NotificationManagerCompat.from(context).cancelAll()

            // ================= Communication =================
            ActionType.SEND_BIG_NOTIFICATION -> {
                val body = text("text")
                notify(context, buildNotification(context, text("title", "BlockAuto"), body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body)))
            }
            ActionType.SEND_NOTIFICATION_WITH_LINK -> {
                val url = text("url").trim()
                if (!url.startsWith("http://") && !url.startsWith("https://")) throw ActionExecutionException("Lien invalide : $url")
                val requestCode = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                val pending = PendingIntent.getActivity(
                    context, requestCode,
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                notify(context, buildNotification(context, text("title", "BlockAuto"), text("text")).setContentIntent(pending))
            }
            ActionType.WHATSAPP_PREFILL -> {
                val number = text("number").filter { it.isDigit() }
                val message = URLEncoder.encode(text("text"), "UTF-8")
                startActivity(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=$message")),
                    "WhatsApp introuvable")
            }
            ActionType.SMS_COMPOSE -> startActivity(
                context,
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(text("number").trim())}")).putExtra("sms_body", text("text")),
                "Aucune appli SMS trouvée"
            )
            ActionType.OPEN_DIALER -> startActivity(
                context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(text("number").trim())}")), "Aucun composeur trouvé"
            )

            // ================= Web & navigation =================
            ActionType.OPEN_MAPS_NAVIGATION -> {
                val destination = text("destination").trim()
                if (destination.isBlank()) throw ActionExecutionException("Indique une destination")
                val mode = when (p["mode"]) { "w" -> "walking"; "b" -> "bicycling"; "transit" -> "transit"; else -> "driving" }
                val url = "https://www.google.com/maps/dir/?api=1&destination=${enc(destination)}&travelmode=$mode&dir_action=navigate"
                startActivity(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Aucune appli de cartes trouvée")
            }
            ActionType.OPEN_MAPS_SEARCH -> startActivity(
                context, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${enc(text("query"))}")), "Aucune appli de cartes trouvée"
            )
            ActionType.WEB_SEARCH -> {
                val query = text("query")
                try {
                    startActivity(context, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query), "")
                } catch (e: ActionExecutionException) {
                    startActivity(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(query)}")),
                        "Aucun navigateur trouvé")
                }
            }
            ActionType.YOUTUBE_SEARCH -> startActivity(
                context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(text("query"))}")),
                "Aucune appli pour ouvrir YouTube"
            )
            ActionType.OPEN_PLAY_STORE -> {
                val pkg = p["package"].orEmpty()
                try {
                    startActivity(context, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")), "")
                } catch (e: ActionExecutionException) {
                    startActivity(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")),
                        "Aucun navigateur trouvé")
                }
            }
            ActionType.WIKIPEDIA_SUMMARY -> {
                val subject = text("subject").trim()
                if (subject.isBlank()) throw ActionExecutionException("Indique un sujet")
                val slug = URLEncoder.encode(subject.replace(' ', '_'), "UTF-8").replace("+", "_")
                val (_, body) = http("https://fr.wikipedia.org/api/rest_v1/page/summary/$slug", "GET")
                val json = JSONObject(body)
                variables[result("wiki")] = json.optString("extract")
                variables["wiki_titre"] = json.optString("title")
            }

            // ================= Infos & capteurs =================
            ActionType.GET_BATTERY_INFO -> {
                val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
                val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                val health = when (intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
                    BatteryManager.BATTERY_HEALTH_GOOD -> "bonne"
                    BatteryManager.BATTERY_HEALTH_OVERHEAT -> "surchauffe"
                    BatteryManager.BATTERY_HEALTH_DEAD -> "hors service"
                    BatteryManager.BATTERY_HEALTH_COLD -> "trop froide"
                    else -> "inconnue"
                }
                variables["batterie"] = AutomationExecutor.currentBatteryLevel(context).toString()
                variables["batterie_temp"] = String.format(Locale.US, "%.1f", temp)
                variables["en_charge"] = if (plugged != 0) "oui" else "non"
                variables["batterie_sante"] = health
            }
            ActionType.GET_DEVICE_INFO -> {
                val stat = StatFs(Environment.getDataDirectory().path)
                val mem = ActivityManager.MemoryInfo()
                (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem)
                variables["appareil"] = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
                variables["android"] = Build.VERSION.RELEASE
                variables["stockage_libre_go"] = String.format(Locale.US, "%.1f", stat.availableBytes / 1_000_000_000.0)
                variables["ram_libre_mo"] = (mem.availMem / (1024 * 1024)).toString()
            }
            ActionType.GET_DATE_TIME -> {
                val now = Date()
                val cal = Calendar.getInstance()
                variables["date"] = SimpleDateFormat("dd/MM/yyyy", FR).format(now)
                variables["heure"] = SimpleDateFormat("HH:mm", FR).format(now)
                variables["jour"] = SimpleDateFormat("EEEE", FR).format(now)
                variables["mois"] = SimpleDateFormat("MMMM", FR).format(now)
                variables["annee"] = cal.get(Calendar.YEAR).toString()
                variables["semaine"] = cal.get(Calendar.WEEK_OF_YEAR).toString()
                val custom = p["format"]?.trim().orEmpty()
                if (custom.isNotEmpty()) {
                    variables["date_perso"] = try {
                        SimpleDateFormat(custom, FR).format(now)
                    } catch (e: IllegalArgumentException) {
                        throw ActionExecutionException("Format de date invalide : $custom")
                    }
                }
            }
            ActionType.GET_NETWORK_INFO -> {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                variables["reseau"] = when {
                    caps == null -> "aucun"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
                    else -> "autre"
                }
                variables["internet"] = if (ExtraConditions.hasInternet(context)) "oui" else "non"
            }
            ActionType.GET_CLIPBOARD -> {
                val clip = withContext(Dispatchers.Main) {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()
                }
                // Android 10+ ne donne le presse-papiers qu'à l'appli au premier plan.
                variables[result("presse_papiers")] = clip ?: throw ActionExecutionException(
                    "Presse-papiers vide ou illisible en arrière-plan (restriction Android 10+)"
                )
            }
            ActionType.GET_PUBLIC_IP -> variables[result("ip")] = http("https://api.ipify.org", "GET").second.trim()
            ActionType.GET_CRYPTO_PRICE -> {
                val coin = text("coin", "bitcoin").trim().lowercase()
                val currency = p["currency"] ?: "eur"
                val (_, body) = http("https://api.coingecko.com/api/v3/simple/price?ids=${enc(coin)}&vs_currencies=$currency", "GET")
                val price = JSONObject(body).optJSONObject(coin)?.optDouble(currency)
                    ?: throw ActionExecutionException("Crypto inconnue : $coin")
                variables[result("crypto")] = formatNumber(price)
            }
            ActionType.GET_EXCHANGE_RATE -> {
                val from = text("from", "EUR").trim().uppercase()
                val to = text("to", "USD").trim().uppercase()
                val (_, body) = http("https://open.er-api.com/v6/latest/${enc(from)}", "GET")
                val rates = JSONObject(body).optJSONObject("rates") ?: throw ActionExecutionException("Devise inconnue : $from")
                if (!rates.has(to)) throw ActionExecutionException("Devise inconnue : $to")
                variables[result("taux")] = formatNumber(rates.getDouble(to))
            }
            ActionType.GET_LIGHT_LEVEL -> variables[result("lumiere")] = readLightLevel(context)
            ActionType.COUNT_DAYS_UNTIL -> {
                val today = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                val target = (today.clone() as Calendar).apply {
                    set(Calendar.MONTH, int("month", 12).coerceIn(1, 12) - 1)
                    set(Calendar.DAY_OF_MONTH, int("day", 25).coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
                    if (before(today)) add(Calendar.YEAR, 1)
                }
                variables[result("jours_restants")] =
                    ((target.timeInMillis - today.timeInMillis) / 86_400_000.0).roundToLong().toString()
            }

            // ================= Texte & fichiers =================
            ActionType.TEXT_TRANSFORM -> {
                val input = text("input")
                variables[result("texte")] = when (p["mode"]) {
                    "upper" -> input.uppercase(FR)
                    "lower" -> input.lowercase(FR)
                    "capitalize" -> input.lowercase(FR).replaceFirstChar { it.titlecase(FR) }
                    "reverse" -> input.reversed()
                    "trim" -> input.trim().replace(Regex("\\s+"), " ")
                    "length" -> input.length.toString()
                    "words" -> input.trim().split(Regex("\\s+")).count { it.isNotEmpty() }.toString()
                    else -> input
                }
            }
            ActionType.TEXT_REPLACE -> {
                val search = text("search")
                if (search.isEmpty()) throw ActionExecutionException("Indique le texte à rechercher")
                variables[result("texte")] = text("input").replace(search, text("replace"))
            }
            ActionType.TEXT_EXTRACT_REGEX -> {
                val regex = try {
                    Regex(p["pattern"].orEmpty())
                } catch (e: Exception) {
                    throw ActionExecutionException("Expression régulière invalide")
                }
                val match = regex.find(text("input"))
                variables[result("extrait")] = when {
                    match == null -> ""
                    match.groupValues.size > 1 -> match.groupValues[1]
                    else -> match.value
                }
            }
            ActionType.EXTRACT_CODE -> {
                val code = Regex("(?<![\\d])\\d{4,8}(?![\\d])").find(text("input", "{sms_body}"))?.value.orEmpty()
                variables[result("code")] = code
            }
            ActionType.ROUND_NUMBER -> {
                val number = text("input").replace(',', '.').trim().toDoubleOrNull()
                    ?: throw ActionExecutionException("« ${text("input")} » n'est pas un nombre")
                val decimals = int("decimals", 0).coerceIn(0, 6)
                variables[result("arrondi")] = String.format(Locale.US, "%.${decimals}f", number)
            }
            ActionType.DELETE_GLOBAL_VARIABLE -> {
                val name = p["name"]?.trim().orEmpty()
                if (name.isBlank()) throw ActionExecutionException("Donne le nom de la variable")
                VariableStore.remove(context, name)
                variables.remove(name)
            }
            ActionType.LIST_RANDOM_ITEM -> {
                val name = p["name"]?.trim().orEmpty().ifBlank { "liste" }
                val raw = variables[name] ?: VariableStore.get(context, name) ?: "[]"
                val array = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
                if (array.length() == 0) throw ActionExecutionException("La liste « $name » est vide")
                variables[result("element")] = array.optString((0 until array.length()).random())
            }
            ActionType.FILE_APPEND_LINE -> withContext(Dispatchers.IO) {
                val file = userFile(context, p["file"] ?: "journal.txt")
                val prefix = if (p["timestamp"] != "false") SimpleDateFormat("dd/MM/yyyy HH:mm:ss", FR).format(Date()) + " — " else ""
                file.appendText(prefix + text("text") + "\n")
            }
            ActionType.FILE_WRITE -> withContext(Dispatchers.IO) {
                userFile(context, p["file"] ?: "note.txt").writeText(text("text"))
            }
            ActionType.FILE_READ -> {
                val file = userFile(context, p["file"] ?: "note.txt")
                if (!file.exists()) throw ActionExecutionException("Fichier introuvable : ${file.name}")
                variables[result("contenu")] = withContext(Dispatchers.IO) { file.readText().take(100_000) }
            }

            // ================= Connecteurs =================
            ActionType.TEAMS_WEBHOOK -> http(
                text("url"), "POST", JSONObject().put("text", text("text")).toString(), "application/json"
            )
            ActionType.GOTIFY_NOTIFICATION -> {
                val server = text("server").trim().trimEnd('/')
                val body = JSONObject()
                    .put("title", text("title", "BlockAuto"))
                    .put("message", text("message"))
                    .put("priority", 5)
                http("$server/message?token=${enc(text("token").trim())}", "POST", body.toString(), "application/json")
            }
            ActionType.MASTODON_POST -> {
                val instance = text("instance", "https://mastodon.social").trim().trimEnd('/')
                val token = text("token").trim()
                if (token.isBlank()) throw ActionExecutionException("Jeton d'accès Mastodon manquant")
                http(
                    "$instance/api/v1/statuses", "POST", "status=${enc(text("text"))}",
                    "application/x-www-form-urlencoded", mapOf("Authorization" to "Bearer $token")
                )
            }
            ActionType.WEBHOOK_JSON -> {
                val (code, response) = http(text("url"), "POST", text("body", "{}"), "application/json")
                variables["http_code"] = code.toString()
                variables["http_body"] = response
            }

            // ================= Fun & surprises =================
            ActionType.ROLL_DICE -> {
                val faces = int("faces", 6).coerceIn(2, 100)
                val value = (1..faces).random()
                variables[p["name"]?.trim().orEmpty().ifBlank { "de" }] = value.toString()
                toast(context, "🎲 $value")
            }
            ActionType.MAGIC_8_BALL -> {
                val answer = EIGHT_BALL.random()
                variables["boule_magique"] = answer
                toast(context, "🎱 $answer")
            }
            ActionType.RANDOM_COMPLIMENT -> sayRandom(context, variables, "compliment", "💖", COMPLIMENTS)
            ActionType.RANDOM_QUOTE -> sayRandom(context, variables, "citation", "💡", QUOTES)
            ActionType.RANDOM_FACT -> sayRandom(context, variables, "anecdote", "🧠", FACTS)
            ActionType.TRUTH_OR_DARE -> {
                val truth = (0..1).random() == 0
                val challenge = if (truth) "Vérité : " + TRUTHS.random() else "Action : " + DARES.random()
                variables["defi"] = challenge
                toast(context, "😈 $challenge")
            }
            ActionType.ROCK_PAPER_SCISSORS -> {
                val choice = listOf("✊ Pierre", "✋ Feuille", "✌️ Ciseaux").random()
                variables[p["name"]?.trim().orEmpty().ifBlank { "chifoumi" }] = choice.substringAfter(' ')
                toast(context, choice)
            }
            ActionType.RANDOM_WALLPAPER_COLOR -> {
                val color = Color.HSVToColor(floatArrayOf((0..359).random().toFloat(), 0.65f, 0.75f))
                setWallpaper(context, solidBitmap(color))
                variables["couleur"] = String.format("#%06X", 0xFFFFFF and color)
            }
            ActionType.GRADIENT_WALLPAPER -> {
                val key = p["preset"]?.takeIf { it != "random" && it in GRADIENTS } ?: GRADIENTS.keys.random()
                setWallpaper(context, gradientBitmap(context, GRADIENTS.getValue(key)))
            }
            ActionType.DISCO_MODE -> {
                toast(context, "🪩 Mode disco !")
                val end = SystemClock.elapsedRealtime() + int("seconds", 8).coerceIn(3, 30) * 1000L
                val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val camId = cm.cameraIdList.firstOrNull()
                var on = false
                try {
                    while (SystemClock.elapsedRealtime() < end) {
                        on = !on
                        camId?.let { runCatching { cm.setTorchMode(it, on) } }
                        if (on) vibrate(context, 60)
                        delay(listOf(90L, 140L, 200L).random())
                    }
                } finally {
                    camId?.let { runCatching { cm.setTorchMode(it, false) } }
                }
            }
            ActionType.RANDOM_PASSWORD -> {
                val length = int("length", 16).coerceIn(6, 64)
                val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?-_+="
                val random = SecureRandom()
                val password = (1..length).map { chars[random.nextInt(chars.length)] }.joinToString("")
                variables["mot_de_passe"] = password
                if (p["copy"] != "false") {
                    withContext(Dispatchers.Main) {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("BlockAuto", password))
                        Toast.makeText(context, "🔐 Mot de passe copié", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            ActionType.BREATHING_EXERCISE -> {
                val cycles = int("cycles", 4).coerceIn(1, 10)
                repeat(cycles) { i ->
                    toast(context, "🧘 ${i + 1}/$cycles — Inspire…")
                    vibrate(context, 400)
                    delay(4000)
                    toast(context, "🧘 Bloque…")
                    delay(4000)
                    toast(context, "🧘 Expire doucement…")
                    vibrate(context, 150)
                    delay(6000)
                }
                toast(context, "✨ Bravo, c'est terminé")
            }

            else -> { /* blocs logiques gérés dans executeSequence */ }
        }
    }

    // ============================================================================
    // Utilitaires
    // ============================================================================

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun formatNumber(value: Double): String =
        if (value == value.toLong().toDouble()) value.toLong().toString() else String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')

    private fun audio(context: Context) = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun streamOf(key: String?): Int = when (key) {
        "ring" -> AudioManager.STREAM_RING
        "notification" -> AudioManager.STREAM_NOTIFICATION
        "alarm" -> AudioManager.STREAM_ALARM
        else -> AudioManager.STREAM_MUSIC
    }

    private fun setVolume(context: Context, stream: Int, level: Int) {
        val am = audio(context)
        try {
            am.setStreamVolume(stream, level.coerceIn(0, am.getStreamMaxVolume(stream)), 0)
        } catch (e: SecurityException) {
            throw ActionExecutionException("Android refuse ce changement de volume (mode Ne pas déranger actif ?)")
        }
    }

    private fun mediaKey(context: Context, keyCode: Int) {
        val am = audio(context)
        val time = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(time, time, KeyEvent.ACTION_DOWN, keyCode, 0))
        am.dispatchMediaKeyEvent(KeyEvent(time, time, KeyEvent.ACTION_UP, keyCode, 0))
    }

    private fun globalAction(id: Int) {
        if (!AppWatcherAccessibilityService.performGlobal(id)) {
            throw ActionExecutionException("Active le service d'accessibilité BlockAuto")
        }
    }

    private fun startActivity(context: Context, intent: Intent, errorMessage: String) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) == null) throw ActionExecutionException(errorMessage)
        try {
            AutomationExecutor.startActivityWithBackgroundExemption(context) { context.startActivity(intent) }
        } catch (e: Exception) {
            throw ActionExecutionException(errorMessage.ifBlank { e.message ?: "Ouverture impossible" }, e)
        }
    }

    private suspend fun toast(context: Context, message: String) = withContext(Dispatchers.Main) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    private suspend fun sayRandom(
        context: Context, variables: MutableMap<String, String>, key: String, emoji: String, pool: List<String>
    ) {
        val chosen = pool.random()
        variables[key] = chosen
        toast(context, "$emoji $chosen")
    }

    private fun vibrate(context: Context, ms: Long) {
        val effect = VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(effect)
        }
    }

    private fun buildNotification(context: Context, title: String, body: String): NotificationCompat.Builder {
        AutomationExecutor.ensureChannel(context)
        return NotificationCompat.Builder(context, AutomationExecutor.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
    }

    private fun notify(context: Context, builder: NotificationCompat.Builder) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !AutomationExecutor.hasPerm(context, Manifest.permission.POST_NOTIFICATIONS)
        ) {
            throw ActionExecutionException("Autorise les notifications de BlockAuto")
        }
        NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
    }

    /** Synthèse vocale bloquante : attend que le moteur soit prêt, puis la fin estimée de la phrase. */
    private suspend fun speak(context: Context, text: String) {
        val ready = CompletableDeferred<Boolean>()
        val tts = android.speech.tts.TextToSpeech(context) { status ->
            ready.complete(status == android.speech.tts.TextToSpeech.SUCCESS)
        }
        try {
            val ok = withTimeoutOrNull(4000L) { ready.await() } ?: false
            if (!ok) throw ActionExecutionException("Synthèse vocale indisponible")
            tts.language = Locale.getDefault()
            tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "blockauto_tts_v3")
            delay((text.length * 65L).coerceIn(1000, 20_000))
        } finally {
            tts.stop()
            tts.shutdown()
        }
    }

    /** Allume/éteint la lampe selon une suite de paires (durée allumée, pause éteinte). */
    private suspend fun torchSequence(context: Context, steps: List<Pair<Long, Long>>) {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val camId = cm.cameraIdList.firstOrNull() ?: throw ActionExecutionException("Aucune lampe torche sur cet appareil")
        try {
            for ((onMs, offMs) in steps) {
                cm.setTorchMode(camId, true)
                delay(onMs)
                cm.setTorchMode(camId, false)
                delay(offMs)
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            throw ActionExecutionException("Lampe torche indisponible : ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            runCatching { cm.setTorchMode(camId, false) }
        }
    }

    private suspend fun playRingtone(context: Context, seconds: Int, sound: String) {
        val type = when (sound) {
            "alarm" -> RingtoneManager.TYPE_ALARM
            "notification" -> RingtoneManager.TYPE_NOTIFICATION
            else -> RingtoneManager.TYPE_RINGTONE
        }
        val uri = RingtoneManager.getDefaultUri(type)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: throw ActionExecutionException("Aucun son disponible")
        val am = audio(context)
        val previous = am.getStreamVolume(AudioManager.STREAM_ALARM)
        runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            player.setDataSource(context, uri)
            player.isLooping = true
            player.prepare()
            player.start()
            delay(seconds * 1000L)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            throw ActionExecutionException("Lecture du son impossible : ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            runCatching { player.stop() }
            player.release()
            runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, previous, 0) }
        }
    }

    /** Joue une suite de notes (fréquence en Hz, durée en ms ; 0 Hz = silence) en synthétisant
     *  une onde sinusoïdale : aucun fichier audio à embarquer. */
    private suspend fun playNotes(notes: List<Pair<Double, Int>>) {
        val sampleRate = 22_050
        val total = notes.sumOf { it.second } * sampleRate / 1000
        val samples = ShortArray(total.coerceAtLeast(1))
        var offset = 0
        for ((freq, ms) in notes) {
            val count = ms * sampleRate / 1000
            val fade = (sampleRate * 0.01).toInt().coerceAtMost(count / 2).coerceAtLeast(1)
            for (i in 0 until count) {
                if (offset + i >= samples.size) break
                val envelope = when {
                    i < fade -> i / fade.toDouble()
                    i > count - fade -> (count - i) / fade.toDouble()
                    else -> 1.0
                }
                val value = if (freq <= 0.0) 0.0 else sin(2 * PI * freq * i / sampleRate) * envelope * 0.6
                samples[offset + i] = (value * Short.MAX_VALUE).toInt().toShort()
            }
            offset += count
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(samples.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        try {
            track.write(samples, 0, samples.size)
            track.play()
            delay(notes.sumOf { it.second }.toLong() + 150)
        } finally {
            runCatching { track.stop() }
            track.release()
        }
    }

    private suspend fun readLightLevel(context: Context): String {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT) ?: throw ActionExecutionException("Pas de capteur de luminosité")
        val value = CompletableDeferred<Float>()
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.values?.firstOrNull()?.let { value.complete(it) }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        withContext(Dispatchers.Main) { sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL) }
        try {
            val lux = withTimeoutOrNull(3000L) { value.await() }
                ?: throw ActionExecutionException("Le capteur de luminosité n'a pas répondu")
            return lux.toInt().toString()
        } finally {
            sm.unregisterListener(listener)
        }
    }

    private fun userFile(context: Context, rawName: String): File {
        val name = rawName.trim().replace(Regex("[^A-Za-z0-9._-]"), "_").trimStart('.').ifBlank { "fichier.txt" }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: File(context.filesDir, "Documents")
        dir.mkdirs()
        return File(dir, name)
    }

    private suspend fun setWallpaper(context: Context, bitmap: Bitmap) = withContext(Dispatchers.IO) {
        try {
            WallpaperManager.getInstance(context).setBitmap(bitmap)
        } catch (e: Exception) {
            throw ActionExecutionException("Impossible de changer le fond d'écran : ${e.message ?: e.javaClass.simpleName}", e)
        }
    }

    private fun solidBitmap(color: Int): Bitmap =
        Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888).apply { eraseColor(color) }

    private fun gradientBitmap(context: Context, colors: IntArray): Bitmap {
        val metrics = context.resources.displayMetrics
        val width = (metrics.widthPixels / 2).coerceAtLeast(64)
        val height = (metrics.heightPixels / 2).coerceAtLeast(64)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), colors, null, Shader.TileMode.CLAMP)
        }
        Canvas(bitmap).drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        return bitmap
    }

    /** Petite requête HTTP avec en-têtes personnalisés (Authorization...). */
    private suspend fun http(
        url: String, method: String, body: String = "", contentType: String = "application/json",
        headers: Map<String, String> = emptyMap()
    ): Pair<Int, String> = withContext(Dispatchers.IO) {
        val clean = url.trim()
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) throw ActionExecutionException("URL invalide : $clean")
        try {
            val connection = URL(clean).openConnection() as HttpURLConnection
            try {
                connection.requestMethod = method
                connection.connectTimeout = 15_000
                connection.readTimeout = 15_000
                connection.setRequestProperty("Accept", "application/json, text/plain, */*")
                connection.setRequestProperty("User-Agent", "BlockAuto/3.0 (Android)")
                headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
                if (method != "GET") {
                    connection.doOutput = true
                    connection.setRequestProperty("Content-Type", "$contentType; charset=utf-8")
                    OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
                }
                val code = connection.responseCode
                val stream = if (code >= 400) connection.errorStream else connection.inputStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw ActionExecutionException("Requête échouée (HTTP $code) ${text.take(200)}")
                code to text
            } finally {
                connection.disconnect()
            }
        } catch (e: ActionExecutionException) {
            throw e
        } catch (e: Exception) {
            throw ActionExecutionException("Impossible de joindre le serveur : ${e.message ?: e.javaClass.simpleName}", e)
        }
    }

    // ============================================================================
    // Données intégrées (fonctionnent sans réseau)
    // ============================================================================

    private val SETTINGS_PAGES = mapOf(
        "battery" to Intent.ACTION_POWER_USAGE_SUMMARY,
        "display" to Settings.ACTION_DISPLAY_SETTINGS,
        "sound" to Settings.ACTION_SOUND_SETTINGS,
        "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "data" to Settings.ACTION_DATA_ROAMING_SETTINGS,
        "nfc" to Settings.ACTION_NFC_SETTINGS,
        "apps" to Settings.ACTION_APPLICATION_SETTINGS,
        "date" to Settings.ACTION_DATE_SETTINGS,
        "accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "security" to Settings.ACTION_SECURITY_SETTINGS,
        "locale" to Settings.ACTION_LOCALE_SETTINGS,
        "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "about" to Settings.ACTION_DEVICE_INFO_SETTINGS
    )

    private const val C5 = 523.25; private const val D5 = 587.33; private const val E5 = 659.25
    private const val F5 = 698.46; private const val G5 = 783.99; private const val A5 = 880.0
    private const val B5 = 987.77; private const val C6 = 1046.5

    private val MELODIES: Map<String, List<Pair<Double, Int>>> = mapOf(
        "victory" to listOf(C5 to 120, E5 to 120, G5 to 120, C6 to 300, 0.0 to 60, G5 to 120, C6 to 450),
        "alert" to List(6) { i -> (if (i % 2 == 0) A5 else E5) to 180 },
        "doorbell" to listOf(E5 to 400, C5 to 600),
        "rise" to listOf(C5 to 120, D5 to 120, E5 to 120, F5 to 120, G5 to 120, A5 to 120, B5 to 120, C6 to 300),
        "fall" to listOf(C6 to 120, B5 to 120, A5 to 120, G5 to 120, F5 to 120, E5 to 120, D5 to 120, C5 to 300),
        "phone" to List(8) { i -> (if (i % 2 == 0) 1400.0 else 0.0) to 60 } + listOf(0.0 to 400) +
            List(8) { i -> (if (i % 2 == 0) 1400.0 else 0.0) to 60 }
    )

    private val GRADIENTS: Map<String, IntArray> = mapOf(
        "sunset" to intArrayOf(0xFFFF5F6D.toInt(), 0xFFFFC371.toInt()),
        "ocean" to intArrayOf(0xFF2E3192.toInt(), 0xFF1BFFFF.toInt()),
        "aurora" to intArrayOf(0xFF0F2027.toInt(), 0xFF2C5364.toInt(), 0xFF00F5A0.toInt()),
        "peach" to intArrayOf(0xFFFFDDE1.toInt(), 0xFFEE9CA7.toInt()),
        "night" to intArrayOf(0xFF0D1021.toInt(), 0xFF3A1C71.toInt()),
        "forest" to intArrayOf(0xFF134E5E.toInt(), 0xFF71B280.toInt())
    )

    private val EIGHT_BALL = listOf(
        "C'est certain.", "Sans aucun doute.", "Tu peux compter dessus.", "Très probablement.",
        "Les signes disent oui.", "Réessaie plus tard.", "Mieux vaut ne pas te le dire maintenant.",
        "Concentre-toi et redemande.", "N'y compte pas.", "Ma réponse est non.", "Peu probable.", "Oui !"
    )

    private val COMPLIMENTS = listOf(
        "Tu es plus fort(e) que tu ne le crois.", "Ton énergie illumine la journée.",
        "Tu fais du super boulot, continue !", "Ta curiosité est une vraie qualité.",
        "Tu as un sourire contagieux.", "Tu gères, vraiment.", "Le monde est meilleur avec toi dedans.",
        "Tes idées valent de l'or.", "Tu progresses chaque jour, même quand tu ne le vois pas."
    )

    private val QUOTES = listOf(
        "« Le succès, c'est d'aller d'échec en échec sans perdre son enthousiasme. » — W. Churchill",
        "« La simplicité est la sophistication suprême. » — L. de Vinci",
        "« Ils ne savaient pas que c'était impossible, alors ils l'ont fait. » — M. Twain",
        "« Le meilleur moment pour planter un arbre était il y a 20 ans. Le deuxième meilleur moment est maintenant. »",
        "« Fais de ta vie un rêve, et d'un rêve, une réalité. » — A. de Saint-Exupéry",
        "« Ce n'est pas parce que les choses sont difficiles que nous n'osons pas. » — Sénèque",
        "« La seule façon de faire du bon travail est d'aimer ce que vous faites. » — S. Jobs",
        "« Petit à petit, l'oiseau fait son nid. »"
    )

    private val FACTS = listOf(
        "Les pieuvres ont trois cœurs et le sang bleu.",
        "Le miel ne se périme jamais : on en a trouvé de comestible dans des tombes égyptiennes.",
        "Une journée sur Vénus dure plus longtemps qu'une année sur Vénus.",
        "Les loutres se tiennent la main en dormant pour ne pas dériver.",
        "La tour Eiffel grandit d'environ 15 cm en été à cause de la chaleur.",
        "Les bananes sont légèrement radioactives (potassium 40).",
        "Un éclair est environ cinq fois plus chaud que la surface du Soleil.",
        "Les vaches ont des meilleures amies et stressent quand on les sépare.",
        "Le cœur d'une crevette se trouve dans sa tête."
    )

    private val TRUTHS = listOf(
        "Quelle est la chose la plus gênante qui te soit arrivée ?", "Quel est ton plus grand rêve ?",
        "Quelle appli utilises-tu le plus en cachette ?", "Quel est ton talent caché ?",
        "Quelle est la dernière chose que tu as cherchée sur Internet ?"
    )

    private val DARES = listOf(
        "Fais 10 pompes maintenant.", "Envoie un compliment à la 3e personne de tes contacts.",
        "Chante le refrain de ta chanson préférée.", "Parle avec un accent pendant 2 minutes.",
        "Fais ta meilleure imitation d'un animal."
    )
}
