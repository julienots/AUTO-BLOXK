package com.blockauto.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.builder.AutomationBuilderActivity
import com.blockauto.app.databinding.ActivityMainBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.services.WatchdogService
import com.blockauto.app.storage.AutomationPresets
import com.blockauto.app.storage.AutomationRepository
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AutomationAdapter

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerAutomations.layoutManager = LinearLayoutManager(this)
        adapter = AutomationAdapter(
            onClick = { automation ->
                val intent = Intent(this, AutomationBuilderActivity::class.java)
                intent.putExtra("automation_id", automation.id)
                startActivity(intent)
            },
            onToggle = { automation, enabled ->
                automation.enabled = enabled
                AutomationRepository.save(this, automation)
                TriggerScheduler.schedule(this, automation)
            },
            onRun = { automation ->
                AutomationExecutionService.start(this, automation.id)
                Snackbar.make(binding.root, "Exécution de « ${automation.name} »", Snackbar.LENGTH_SHORT).show()
            },
            onDelete = { automation ->
                AutomationRepository.delete(this, automation.id)
                TriggerScheduler.cancel(this, automation.id)
                refresh()
            }
        )
        binding.recyclerAutomations.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AutomationBuilderActivity::class.java))
        }

        binding.btnPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnPresets.setOnClickListener {
            showPresetsDialog()
        }

        requestNeededPermissions()
        // Démarre (ou relance) le service de veille qui permet à BlockAuto
        // de continuer à fonctionner même une fois l'app fermée.
        WatchdogService.start(this)
        maybeAskBatteryOptimizationExemption()
        maybeAskOverlayPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val list = AutomationRepository.getAll(this)
        adapter.submitList(list)
        binding.emptyState.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    /**
     * Affiche la liste des automatisations prêtes à l'emploi (dont l'ampoule connectée)
     * et ajoute celles cochées par l'utilisateur en un tap.
     */
    private fun showPresetsDialog() {
        val presets = AutomationPresets.all()
        val labels = presets.map { "${it.title}\n${it.description}" }.toTypedArray()
        val checked = BooleanArray(presets.size)

        AlertDialog.Builder(this)
            .setTitle(R.string.suggestions_title)
            .setMessage(R.string.suggestions_explanation)
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.add_automation) { dialog, _ ->
                var addedCount = 0
                presets.forEachIndexed { index, preset ->
                    if (checked[index]) {
                        val automation = preset.build()
                        AutomationRepository.save(this, automation)
                        TriggerScheduler.schedule(this, automation)
                        addedCount++
                    }
                }
                if (addedCount > 0) {
                    Snackbar.make(binding.root, getString(R.string.preset_added), Snackbar.LENGTH_LONG).show()
                    refresh()
                }
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        perms.add(Manifest.permission.SEND_SMS)
        perms.add(Manifest.permission.RECEIVE_SMS)
        perms.add(Manifest.permission.READ_SMS)
        perms.add(Manifest.permission.CALL_PHONE)
        perms.add(Manifest.permission.READ_CONTACTS)
        perms.add(Manifest.permission.READ_CALENDAR)
        perms.add(Manifest.permission.WRITE_CALENDAR)
        perms.add(Manifest.permission.RECORD_AUDIO)
        perms.add(Manifest.permission.READ_PHONE_STATE)
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
        }
        val toRequest = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) permLauncher.launch(toRequest.toTypedArray())
    }

    /**
     * Demande automatiquement, dès le premier lancement, d'ignorer l'optimisation
     * de batterie : c'est le réglage le plus important pour garantir que les
     * automatisations continuent de tourner quand le téléphone est en veille.
     */
    private fun maybeAskBatteryOptimizationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) { /* certains constructeurs bloquent cet intent */ }
        }
    }

    /**
     * Demande, dès le premier lancement, "Afficher par-dessus les autres applications" :
     * c'est ce qui permet aux blocs qui ouvrent une appli/URL/appel de fonctionner même
     * quand l'automatisation est déclenchée app totalement fermée (restriction Android 10+).
     */
    private fun maybeAskOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) { /* certains constructeurs bloquent cet intent */ }
        }
    }
}
