package com.blockauto.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.builder.AutomationBuilderActivity
import com.blockauto.app.databinding.ActivityMainBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.Automation
import com.blockauto.app.services.AutomationExecutionService
import com.blockauto.app.services.WatchdogService
import com.blockauto.app.storage.AutomationPresets
import com.blockauto.app.storage.AutomationRepository
import com.google.android.material.snackbar.Snackbar
import java.io.BufferedReader
import java.io.OutputStreamWriter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AutomationAdapter

    /** Terme de recherche courant (nom ou déclencheur), appliqué en plus du tri habituel. */
    private var searchQuery: String = ""

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) performExport(uri)
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) performImport(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerAutomations.layoutManager = LinearLayoutManager(this)
        adapter = AutomationAdapter(
            onClick = { automation ->
                val intent = Intent(this, AutomationBuilderActivity::class.java)
                intent.putExtra("automation_id", automation.id)
                startActivity(intent)
            },
            onToggle = { automation, enabled ->
                automation.enabled = enabled
                AutomationRepository.save(this, automation)
                TriggerScheduler.schedule(this, automation)
            },
            onRun = { automation ->
                AutomationExecutionService.start(this, automation.id)
                Snackbar.make(binding.root, "Exécution de « ${automation.name} »", Snackbar.LENGTH_SHORT).show()
            },
            onDelete = { automation ->
                confirmAndDelete(automation)
            },
            onDuplicate = { automation ->
                val copy = AutomationRepository.duplicate(this, automation)
                // Pas de TriggerScheduler.schedule() ici : la copie est créée désactivée
                // exprès, donc rien à programmer tant que l'utilisateur ne l'active pas.
                Snackbar.make(binding.root, getString(R.string.automation_duplicated, copy.name), Snackbar.LENGTH_LONG).show()
                refresh()
            }
        )
        binding.recyclerAutomations.adapter = adapter

        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString().orEmpty()
                refresh()
            }
        })

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AutomationBuilderActivity::class.java))
        }

        binding.btnPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnPresets.setOnClickListener {
            showPresetsDialog()
        }

        binding.btnBackup.setOnClickListener {
            showBackupDialog()
        }

        requestNeededPermissions()
        // Démarre (ou relance) le service de veille qui permet à BlockAuto
        // de continuer à fonctionner même une fois l'app fermée.
        WatchdogService.start(this)
        maybeAskBatteryOptimizationExemption()
        maybeAskOverlayPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        // Rangées : actives d'abord, puis groupées par type de déclencheur, puis par nom —
        // pour repérer d'un coup d'œil ce qui tourne vraiment et regrouper les automatisations
        // qui réagissent au même événement.
        val all = AutomationRepository.getAll(this)
        val query = searchQuery.trim().lowercase()
        val filtered = if (query.isBlank()) all else all.filter { automation ->
            automation.name.lowercase().contains(query) ||
                (automation.trigger?.type?.label?.lowercase()?.contains(query) == true)
        }
        val list = filtered.sortedWith(
            compareByDescending<Automation> { it.enabled }
                .thenBy { it.trigger?.type?.ordinal ?: Int.MAX_VALUE }
                .thenBy { it.name.lowercase() }
        )
        adapter.submitList(list)
        val noResultsFromSearch = list.isEmpty() && all.isNotEmpty()
        binding.emptyState.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.emptyStateText.text = if (noResultsFromSearch) {
            getString(R.string.no_search_results, searchQuery.trim())
        } else {
            getString(R.string.no_automation_yet)
        }
    }

    /**
     * Supprimer une automatisation est définitif et sans confirmation était le comportement
     * d'origine : un appui accidentel sur le bouton (liste qui défile, doigt qui glisse...)
     * perdait la configuration entière sans recours. On demande maintenant confirmation,
     * ET on garde 6 secondes pour annuler après coup, au cas où l'automatisation était
     * en fait la bonne mais que l'utilisateur change d'avis.
     */
    private fun confirmAndDelete(automation: Automation) {
        AlertDialog.Builder(this)
            .setTitle(R.string.confirm_delete_title)
            .setMessage(getString(R.string.confirm_delete_message, automation.name.ifBlank { "Sans nom" }))
            .setPositiveButton(R.string.delete) { _, _ -> deleteWithUndo(automation) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun deleteWithUndo(automation: Automation) {
        AutomationRepository.delete(this, automation.id)
        TriggerScheduler.cancel(this, automation.id)
        refresh()
        Snackbar.make(binding.root, getString(R.string.automation_deleted, automation.name.ifBlank { "Sans nom" }), Snackbar.LENGTH_LONG)
            .setAction(R.string.undo) {
                AutomationRepository.save(this, automation)
                if (automation.enabled) TriggerScheduler.schedule(this, automation)
                refresh()
            }
            .show()
    }

    /** Propose d'exporter la liste actuelle vers un fichier JSON, ou d'en importer une. */
    private fun showBackupDialog() {
        val options = arrayOf(getString(R.string.backup_export), getString(R.string.backup_import))
        AlertDialog.Builder(this)
            .setTitle(R.string.backup_title)
            .setItems(options) { _, which ->
                if (which == 0) {
                    val filename = "blockauto_sauvegarde_${System.currentTimeMillis()}.json"
                    exportLauncher.launch(filename)
                } else {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun performExport(uri: Uri) {
        try {
            val json = AutomationRepository.exportJson(this)
            val count = AutomationRepository.getAll(this).size
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(json) }
            } ?: throw IllegalStateException("Impossible d'ouvrir le fichier de destination")
            Snackbar.make(binding.root, getString(R.string.backup_export_success, count), Snackbar.LENGTH_LONG).show()
        } catch (e: Exception) {
            Snackbar.make(binding.root, getString(R.string.backup_export_error, e.message ?: e.javaClass.simpleName), Snackbar.LENGTH_LONG).show()
        }
    }

    private fun performImport(uri: Uri) {
        try {
            val json = contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(stream.reader(Charsets.UTF_8)).readText()
            } ?: throw IllegalStateException("Impossible de lire le fichier")
            val added = AutomationRepository.importJson(this, json)
            when {
                added < 0 -> Snackbar.make(binding.root, getString(R.string.backup_import_error), Snackbar.LENGTH_LONG).show()
                added == 0 -> Snackbar.make(binding.root, getString(R.string.backup_import_empty), Snackbar.LENGTH_LONG).show()
                else -> {
                    // Reprogramme les déclencheurs des automatisations nouvellement importées
                    // (celles-ci n'existaient pas encore côté AlarmManager/WatchdogService).
                    AutomationRepository.getAll(this).forEach { TriggerScheduler.schedule(this, it) }
                    Snackbar.make(binding.root, getString(R.string.backup_import_success, added), Snackbar.LENGTH_LONG).show()
                    refresh()
                }
            }
        } catch (e: Exception) {
            Snackbar.make(binding.root, getString(R.string.backup_import_error), Snackbar.LENGTH_LONG).show()
        }
    }

    /**
     * Affiche la liste des automatisations prêtes à l'emploi (dont l'ampoule connectée)
     * et ajoute celles cochées par l'utilisateur en un tap.
     */
    private fun showPresetsDialog() {
        val presets = AutomationPresets.all()

        // Dialog personnalisé : le MultiChoiceItems d'AlertDialog Material peut devenir
        // invisible/illisible selon le thème Android du téléphone. On construit donc
        // directement une liste de cases à cocher, avec texte et description séparés.
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }

        val scroll = android.widget.ScrollView(this)
        scroll.addView(container)

        val checks = mutableListOf<android.widget.CheckBox>()

        presets.forEach { preset ->
            val check = android.widget.CheckBox(this).apply {
                text = preset.title
                isChecked = false
                setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text_primary))
                textSize = 16f
                setPadding(0, 10, 0, 4)
            }

            val description = android.widget.TextView(this).apply {
                text = preset.description
                setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text_secondary))
                textSize = 12f
                setPadding(48, 0, 0, 10)
            }

            container.addView(check)
            container.addView(description)
            checks.add(check)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.suggestions_title)
            .setMessage("Coche les automatisations que tu veux ajouter.")
            .setView(scroll)
            .setPositiveButton(R.string.add_automation, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var addedCount = 0

                presets.forEachIndexed { index, preset ->
                    if (!checks[index].isChecked) return@forEachIndexed

                    val automations = preset.build()

                    // Sauvegarde d'abord toutes les automatisations du preset.
                    // C'est important pour les presets qui créent une chaîne A -> B :
                    // toutes les cibles existent alors déjà dans le Repository.
                    automations.forEach { automation ->
                        AutomationRepository.save(this, automation)
                    }

                    // Puis programmation des déclencheurs.
                    automations.forEach { automation ->
                        TriggerScheduler.schedule(this, automation)
                    }

                    addedCount += automations.size
                }

                if (addedCount > 0) {
                    Snackbar.make(
                        binding.root,
                        "$addedCount automatisation(s) ajoutée(s) ✅",
                        Snackbar.LENGTH_LONG
                    ).show()
                    refresh()
                } else {
                    Snackbar.make(
                        binding.root,
                        "Aucune automatisation sélectionnée.",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }

                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        perms.add(Manifest.permission.SEND_SMS)
        perms.add(Manifest.permission.RECEIVE_SMS)
        perms.add(Manifest.permission.READ_SMS)
        perms.add(Manifest.permission.CALL_PHONE)
        perms.add(Manifest.permission.READ_CONTACTS)
        perms.add(Manifest.permission.READ_CALENDAR)
        perms.add(Manifest.permission.WRITE_CALENDAR)
        perms.add(Manifest.permission.RECORD_AUDIO)
        perms.add(Manifest.permission.READ_PHONE_STATE)
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
        }
        val toRequest = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) permLauncher.launch(toRequest.toTypedArray())
    }

    /**
     * Demande automatiquement, dès le premier lancement, d'ignorer l'optimisation
     * de batterie : c'est le réglage le plus important pour garantir que les
     * automatisations continuent de tourner quand le téléphone est en veille.
     */
    private fun maybeAskBatteryOptimizationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) { /* certains constructeurs bloquent cet intent */ }
        }
    }

    /**
     * Demande, dès le premier lancement, "Afficher par-dessus les autres applications" :
     * c'est ce qui permet aux blocs qui ouvrent une appli/URL/appel de fonctionner même
     * quand l'automatisation est déclenchée app totalement fermée (restriction Android 10+).
     */
    private fun maybeAskOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) { /* certains constructeurs bloquent cet intent */ }
        }
    }
}
