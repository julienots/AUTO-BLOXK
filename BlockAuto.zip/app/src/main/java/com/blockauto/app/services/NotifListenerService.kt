package com.blockauto.app.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class NotifListenerService : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        // BUG CORRIGÉ : BlockAuto affiche lui-même des notifications (bloc "Envoyer une
        // notification", notification du service de veille, notification d'exécution en
        // cours...). Sans ce filtre, une automatisation "Notification reçue (n'importe
        // laquelle)" combinée à une action "Envoyer une notification" se redéclenchait
        // elle-même en boucle infinie dès qu'elle s'exécutait une première fois — chaque
        // notification posée par BlockAuto étant elle-même vue comme un événement "notification
        // reçue". On ignore donc toujours les notifications qui viennent de BlockAuto lui-même.
        if (pkg == packageName) return
        val extras = sbn.notification?.extras
        val title = extras?.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras?.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString() ?: ""
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.NOTIFICATION_RECEIVED) {
                val targetPkg = a.trigger?.params?.get("package")
                if (targetPkg.isNullOrBlank() || targetPkg == pkg) {
                    // Expose le titre/texte de la notification et l'app d'origine comme variables
                    // {notif_title}/{notif_text}/{notif_package} réutilisables dans les blocs suivants.
                    AutomationExecutionService.start(
                        this, a.id,
                        mapOf("notif_package" to pkg, "notif_title" to title, "notif_text" to text)
                    )
                }
            }
        }
    }

    companion object {
        @Volatile private var instance: NotifListenerService? = null
        fun instanceOrNull(): NotifListenerService? = instance
    }
}
