package com.blockauto.app.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class NotifListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.NOTIFICATION_RECEIVED) {
                val targetPkg = a.trigger?.params?.get("package")
                if (targetPkg.isNullOrBlank() || targetPkg == pkg) {
                    AutomationExecutionService.start(this, a.id)
                }
            }
        }
    }
}
