package com.blockauto.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blockauto.app.databinding.ActivityHistoryBinding
import com.blockauto.app.databinding.ItemHistoryBinding
import com.blockauto.app.storage.HistoryEntry
import com.blockauto.app.storage.HistoryRepository

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        refresh()

        binding.btnClearHistory.setOnClickListener {
            HistoryRepository.clear(this)
            refresh()
        }
    }

    private fun refresh() {
        val entries = HistoryRepository.getAll(this)
        binding.recyclerHistory.adapter = HistoryAdapter(entries)
        binding.emptyHistory.visibility = if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private class HistoryAdapter(private val items: List<HistoryEntry>) :
        RecyclerView.Adapter<HistoryAdapter.VH>() {

        inner class VH(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
            val binding = ItemHistoryBinding.inflate(
                android.view.LayoutInflater.from(parent.context), parent, false
            )
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.binding.textHistoryTitle.text = item.automationName
            holder.binding.textHistoryMessage.text = item.message
            holder.binding.textHistoryTime.text = HistoryRepository.formatTime(item.timestamp)

            // Petit logo d'état déduit du message : rouge/⚠️ si une erreur est mentionnée,
            // vert/✅ sinon — donne un repère visuel immédiat sur chaque ligne de la liste.
            val context = holder.itemView.context
            val isError = item.message.contains("erreur", ignoreCase = true) ||
                item.message.contains("échec", ignoreCase = true)
            val statusColor = androidx.core.content.ContextCompat.getColor(
                context, if (isError) com.blockauto.app.R.color.accent_danger else com.blockauto.app.R.color.accent_success
            )
            holder.binding.badgeHistoryStatus.text = if (isError) "⚠️" else "✅"
            holder.binding.badgeHistoryStatus.backgroundTintList =
                android.content.res.ColorStateList.valueOf(statusColor)
        }

        override fun getItemCount() = items.size
    }
}
