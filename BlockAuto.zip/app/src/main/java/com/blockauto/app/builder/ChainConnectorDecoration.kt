package com.blockauto.app.builder

import android.content.Context
import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * Fait légèrement chevaucher chaque bloc avec le précédent, de la hauteur exacte de la
 * languette/encoche dessinée par [PuzzleBlockView]. Le bloc suivant est dessiné par-dessus
 * (RecyclerView dessine ses enfants dans l'ordre des positions), donc son encoche vient
 * recouvrir exactement la languette du bloc au-dessus : les deux pièces de puzzle
 * s'emboîtent visuellement, comme de vrais maillons de chaîne, sans trait ni icône
 * décorative superposée en plus.
 */
class ChainConnectorDecoration(context: Context) : RecyclerView.ItemDecoration() {

    /** Doit rester identique au rayon de languette/encoche utilisé par PuzzleBlockView. */
    private val overlapPx = (11f * context.resources.displayMetrics.density * 1.1f).toInt()

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        val position = parent.getChildAdapterPosition(view)
        if (position > 0) outRect.top = -overlapPx
    }
}
