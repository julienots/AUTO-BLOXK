package com.blockauto.app.services

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class AppWatcherAccessibilityService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPackage) return
        lastPackage = pkg
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.APP_OPENED) {
                val targetPkg = a.trigger?.params?.get("package")
                if (targetPkg == pkg) {
                    AutomationExecutionService.start(this, a.id)
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    companion object {
        /** Référence vive du service, utilisée par le bloc "Capture d'écran" du moteur. */
        private var instance: AppWatcherAccessibilityService? = null

        /** Retourne false si le service d'accessibilité n'est pas activé par l'utilisateur. */
        fun takeScreenshot(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }
}
