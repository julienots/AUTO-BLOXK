package com.blockauto.app.services

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class AppWatcherAccessibilityService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // On ignore BlockAuto lui-même (ex: quand une boîte de dialogue du bâtisseur
        // passe au premier plan), sinon "app ouverte" / "app fermée" se déclenchaient
        // pour n'importe quelle app dès qu'on rouvrait BlockAuto par-dessus.
        if (pkg == packageName) return
        if (pkg == lastPackage) return
        val previousPkg = lastPackage
        lastPackage = pkg
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled) continue
            when (a.trigger?.type) {
                TriggerType.APP_OPENED -> {
                    val targetPkg = a.trigger?.params?.get("package")
                    if (targetPkg == pkg) {
                        AutomationExecutionService.start(this, a.id, mapOf("opened_package" to pkg))
                    }
                }
                // "Application fermée" : se déclenche quand on QUITTE l'app ciblée pour une
                // autre (previousPkg == l'app surveillée, pkg == ce qui vient au premier plan).
                TriggerType.APP_CLOSED -> {
                    val targetPkg = a.trigger?.params?.get("package")
                    if (targetPkg != null && targetPkg == previousPkg) {
                        AutomationExecutionService.start(this, a.id, mapOf("closed_package" to targetPkg))
                    }
                }
                else -> {}
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    companion object {
        /** Référence vive du service, utilisée par plusieurs blocs du moteur qui ont besoin
         *  d'une "action globale" système (capture d'écran, verrouillage, accueil, récents). */
        private var instance: AppWatcherAccessibilityService? = null

        /** Retourne false si le service d'accessibilité n'est pas activé par l'utilisateur. */
        fun takeScreenshot(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }

        /** Verrouille l'écran. Nécessite Android 9+ (GLOBAL_ACTION_LOCK_SCREEN). */
        fun lockScreen(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }

        fun goHome(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_HOME)
        }

        fun openRecents(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }
}
