package com.blockauto.app.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class AppWatcherAccessibilityService : AccessibilityService() {

    private var lastPackage: String? = null

    // Pour le déclencheur "Un texte apparaît à l'écran" : on ne veut déclencher qu'UNE fois
    // par apparition (pas à chaque micro-changement de la page tant que le texte reste visible),
    // donc on retient quels blocs ont déjà tiré pour ce texte, et on les "réarme" dès qu'il disparaît.
    private val uiTextAlreadyFired = mutableSetOf<String>()
    // Pour "Un texte disparaît de l'écran" : on ne veut tirer qu'après avoir réellement
    // VU le texte au moins une fois, pas dès le premier scan si le texte était déjà
    // absent (sinon l'automatisation se déclencherait immédiatement à l'activation).
    private val uiTextSeenVisible = mutableSetOf<String>()
    private var lastUiScanAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            handleWindowStateChanged(event)
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            // Limite les scans de l'arbre d'accessibilité (potentiellement coûteux) à un
            // maximum de ~3 fois par seconde, même si l'appli au premier plan envoie des
            // dizaines d'événements de contenu par seconde (listes qui défilent, animations...).
            val now = System.currentTimeMillis()
            if (now - lastUiScanAt >= 300) {
                lastUiScanAt = now
                checkUiTextTriggers(event.packageName?.toString())
            }
        }
    }

    private fun handleWindowStateChanged(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        // On ignore BlockAuto lui-même (ex: quand une boîte de dialogue du bâtisseur
        // passe au premier plan), sinon "app ouverte" / "app fermée" se déclenchaient
        // pour n'importe quelle app dès qu'on rouvrait BlockAuto par-dessus.
        if (pkg == packageName) return
        if (pkg == lastPackage) return
        val previousPkg = lastPackage
        lastPackage = pkg
        uiTextAlreadyFired.clear()
        uiTextSeenVisible.clear()
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled) continue
            when (a.trigger?.type) {
                TriggerType.APP_OPENED -> {
                    val targetPkg = a.trigger?.params?.get("package")
                    if (targetPkg == pkg) {
                        AutomationExecutionService.start(this, a.id, mapOf("opened_package" to pkg))
                    }
                }
                // "Application fermée" : se déclenche quand on QUITTE l'app ciblée pour une
                // autre (previousPkg == l'app surveillée, pkg == ce qui vient au premier plan).
                TriggerType.APP_CLOSED -> {
                    val targetPkg = a.trigger?.params?.get("package")
                    if (targetPkg != null && targetPkg == previousPkg) {
                        AutomationExecutionService.start(this, a.id, mapOf("closed_package" to targetPkg))
                    }
                }
                else -> {}
            }
        }
    }

    /** Cherche, parmi les automatisations en attente d'un texte précis à l'écran, celles
     *  dont le texte vient d'apparaître (ou de disparaître, pour pouvoir se redéclencher). */
    private fun checkUiTextTriggers(currentPkg: String?) {
        val list = AutomationRepository.getAll(this)
        val relevant = list.filter {
            it.enabled && (it.trigger?.type == TriggerType.UI_TEXT_APPEARS || it.trigger?.type == TriggerType.UI_TEXT_DISAPPEARS)
        }
        if (relevant.isEmpty()) return
        for (a in relevant) {
            val targetPkg = a.trigger?.params?.get("package")
            if (!targetPkg.isNullOrBlank() && targetPkg != currentPkg) continue
            val text = a.trigger?.params?.get("text")?.trim().orEmpty()
            if (text.isBlank()) continue
            val visible = findNodeByText(text, exact = false) != null
            val wantsDisappear = a.trigger?.type == TriggerType.UI_TEXT_DISAPPEARS
            if (visible) uiTextSeenVisible.add(a.id)
            // "Apparaît" : on tire au moment où le texte devient visible, puis on se
            // réarme quand il disparaît. "Disparaît" : c'est l'inverse — on tire au
            // moment où un texte auparavant VU disparaît (ex : un badge "En ligne" qui
            // s'efface), et on se réarme dès qu'il revient.
            val shouldFireNow = if (wantsDisappear) (!visible && uiTextSeenVisible.contains(a.id)) else visible
            if (shouldFireNow && uiTextAlreadyFired.add(a.id)) {
                if (wantsDisappear) uiTextSeenVisible.remove(a.id)
                AutomationExecutionService.start(this, a.id, mapOf("ui_text" to text))
            } else if (!shouldFireNow) {
                uiTextAlreadyFired.remove(a.id)
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    // ---------------------------------------------------------------------
    // Recherche de nœuds dans l'arbre d'accessibilité de l'application au
    // premier plan, utilisée par tous les blocs "Dans l'appli : ..." (clic,
    // appui long, condition "texte visible").
    // ---------------------------------------------------------------------

    private fun findNodeByText(text: String, exact: Boolean): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (matches.isNullOrEmpty()) return null
        return if (exact) matches.firstOrNull { it.text?.toString().equals(text, ignoreCase = true) } ?: matches.firstOrNull()
        else matches.firstOrNull()
    }

    private fun findNodeByDescription(description: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return findByDescriptionRecursive(root, description)
    }

    private fun findByDescriptionRecursive(node: AccessibilityNodeInfo, description: String): AccessibilityNodeInfo? {
        if (node.contentDescription?.toString()?.contains(description, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByDescriptionRecursive(child, description)
            if (found != null) return found
        }
        return null
    }

    /** Remonte l'arbre jusqu'à trouver un ancêtre cliquable (souvent le texte visé est
     *  porté par un TextView interne à un bouton/une rangée qui, elle, est cliquable). */
    private fun clickableSelfOrAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 8) {
            if (current.isClickable) return current
            current = current.parent
            hops++
        }
        return null
    }

    private fun longClickableSelfOrAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 8) {
            if (current.isLongClickable) return current
            current = current.parent
            hops++
        }
        return null
    }

    companion object {
        /** Référence vive du service, utilisée par plusieurs blocs du moteur qui ont besoin
         *  d'une "action globale" système (capture d'écran, verrouillage, accueil, récents)
         *  ou d'une interaction directe avec le contenu d'une autre application. */
        private var instance: AppWatcherAccessibilityService? = null

        /** Retourne false si le service d'accessibilité n'est pas activé par l'utilisateur. */
        fun takeScreenshot(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }

        /** Verrouille l'écran. Nécessite Android 9+ (GLOBAL_ACTION_LOCK_SCREEN). */
        fun lockScreen(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }

        fun goHome(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_HOME)
        }

        fun openRecents(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_RECENTS)
        }

        /** Bouton retour système, utile pour sortir d'un écran/dialogue dans une autre appli. */
        fun pressBack(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_BACK)
        }

        /** Vrai si le texte donné est visible quelque part dans l'appli au premier plan
         *  (utilisé par la condition "Un texte est visible à l'écran" et par le bloc
         *  "Attendre qu'un texte apparaisse"). */
        fun isTextVisible(text: String): Boolean {
            val service = instance ?: return false
            return service.findNodeByText(text, exact = false) != null
        }

        /** Cherche un nœud portant [text] (ou le premier ancêtre cliquable) et clique dessus.
         *  Retourne false si le texte est introuvable, si aucun élément cliquable n'a été
         *  trouvé, ou si le service d'accessibilité n'est pas actif. */
        fun clickText(text: String): Boolean {
            val service = instance ?: return false
            val node = service.findNodeByText(text, exact = false) ?: return false
            val target = service.clickableSelfOrAncestor(node) ?: node
            return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }

        fun longClickText(text: String): Boolean {
            val service = instance ?: return false
            val node = service.findNodeByText(text, exact = false) ?: return false
            val target = service.longClickableSelfOrAncestor(node) ?: node
            return target.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        }

        /** Clique sur un élément identifié par sa description d'accessibilité (souvent le
         *  seul moyen d'atteindre une icône sans texte, ex: bouton "Envoyer", "Menu"...). */
        fun clickByDescription(description: String): Boolean {
            val service = instance ?: return false
            val node = service.findNodeByDescription(description) ?: return false
            val target = service.clickableSelfOrAncestor(node) ?: node
            return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }

        /** Écrit [text] dans le champ actuellement en édition (celui qui a le focus) dans
         *  l'application au premier plan. Nécessite qu'un champ de saisie ait déjà le focus
         *  (l'utilisateur ou une action précédente doit l'avoir touché). */
        fun inputTextInFocusedField(text: String): Boolean {
            val service = instance ?: return false
            val root = service.rootInActiveWindow ?: return false
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            if (!focused.isEditable) return false
            val arguments = Bundle()
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        }

        /**
         * CORRECTIF CLÉ : jusqu'ici, "écrire dans le champ actif" exigeait qu'un champ ait
         * DÉJÀ le focus — ce qui n'arrive quasiment jamais tout seul juste après avoir ouvert
         * une appli ou une conversation. Résultat : dans une appli de messagerie (Instagram,
         * WhatsApp, Messenger, Telegram...), le champ "Message..." n'a jamais le focus au
         * moment voulu, donc écrire puis envoyer un message échouait silencieusement.
         * Cette fonction cherche elle-même le champ de saisie le plus probable (le dernier
         * champ éditable trouvé dans l'arbre — la barre de message est presque toujours en
         * bas de l'écran, donc la dernière rencontrée lors d'un parcours haut → bas), clique
         * dessus pour lui donner le focus, PUIS y écrit le texte. C'est cette combinaison qui
         * rend "Dans l'appli : envoyer un message" réellement fiable.
         */
        fun clickInputFieldAndType(text: String): Boolean {
            val service = instance ?: return false
            val root = service.rootInActiveWindow ?: return false
            val editable = findFirstEditableRecursive(root)
            val field = editable.lastOrNull() ?: return false
            field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            field.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val arguments = Bundle()
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) return true
            // Repli : sur certaines applis (dont Instagram par moments), ACTION_SET_TEXT direct
            // sur le nœud fraîchement cliqué échoue une première fois tant que le clavier n'a
            // pas fini de s'afficher ; on retente une fois via le champ qui a effectivement le
            // focus juste après le clic.
            val focused = service.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && focused.isEditable) {
                return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            }
            return false
        }

        /** Clique uniquement sur le champ de saisie (sans y écrire) pour lui donner le focus —
         *  utile en bloc séparé si besoin de contrôler précisément l'ordre des actions. */
        fun clickFirstEditableField(): Boolean {
            val service = instance ?: return false
            val root = service.rootInActiveWindow ?: return false
            val field = findFirstEditableRecursive(root).lastOrNull() ?: return false
            field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            return field.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }

        /** Boutons "Envoyer" les plus courants tous réglages de langue confondus (texte affiché
         *  OU description d'accessibilité de l'icône), utilisés quand aucun libellé précis n'a
         *  été donné par l'utilisateur pour le bloc "envoyer un message". */
        private val COMMON_SEND_LABELS = listOf(
            "Envoyer", "Send", "Enviar", "Invia", "Senden", "Publier", "Post", "➤", "▶"
        )

        /** Clique sur le bouton d'envoi. Si [customLabel] est fourni, essaie d'abord ce texte
         *  puis cette description exacts ; sinon (ou en repli) essaie une liste de libellés
         *  d'envoi courants, par texte puis par description d'icône. */
        fun clickSendButton(customLabel: String?): Boolean {
            if (!customLabel.isNullOrBlank()) {
                if (clickText(customLabel) || clickByDescription(customLabel)) return true
            }
            for (label in COMMON_SEND_LABELS) {
                if (clickText(label) || clickByDescription(label)) return true
            }
            return false
        }

        /** Fait défiler le premier conteneur scrollable trouvé dans l'appli au premier plan. */
        fun scroll(forward: Boolean): Boolean {
            val service = instance ?: return false
            val root = service.rootInActiveWindow ?: return false
            val scrollable = findScrollableRecursive(root) ?: return false
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            return scrollable.performAction(action)
        }

        /** Cherche le premier champ éditable visible (souvent le champ "Message..." d'une appli
         *  de discussion type Instagram/WhatsApp/Messenger/Telegram/SMS). On prend le DERNIER
         *  trouvé lors d'un parcours haut → bas de l'arbre, car la barre de saisie de message
         *  est presque toujours en bas de l'écran (les autres champs éditables, s'il y en a,
         *  sont en général une barre de recherche ou un titre situés plus haut). */
        private fun findFirstEditableRecursive(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
            val results = mutableListOf<AccessibilityNodeInfo>()
            if (node.isEditable) results.add(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                results.addAll(findFirstEditableRecursive(child))
            }
            return results
        }

        private fun findScrollableRecursive(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (node.isScrollable) return node
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val found = findScrollableRecursive(child)
                if (found != null) return found
            }
            return null
        }

        /**
         * Balaye l'écran dans une direction donnée via un vrai geste tactile simulé
         * (dispatchGesture), pour les cas où l'appli ciblée ne réagit pas à
         * ACTION_SCROLL_FORWARD/BACKWARD (ex: certains carrousels, jeux, lecteurs vidéo).
         * Nécessite Android 7.0+ (API 24) pour dispatchGesture.
         */
        fun swipe(direction: String, durationMs: Long = 300): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
            val metrics = service.resources.displayMetrics
            val width = metrics.widthPixels.toFloat()
            val height = metrics.heightPixels.toFloat()
            val (startX, startY, endX, endY) = when (direction) {
                "up" -> listOf(width / 2, height * 0.75f, width / 2, height * 0.25f)
                "down" -> listOf(width / 2, height * 0.25f, width / 2, height * 0.75f)
                "left" -> listOf(width * 0.75f, height / 2, width * 0.25f, height / 2)
                else -> listOf(width * 0.25f, height / 2, width * 0.75f, height / 2) // "right" par défaut
            }
            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
                .build()
            return service.dispatchGesture(gesture, null, null)
        }
    }
}
