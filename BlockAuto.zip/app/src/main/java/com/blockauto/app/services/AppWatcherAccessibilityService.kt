package com.blockauto.app.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository

class AppWatcherAccessibilityService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPackage) return
        lastPackage = pkg
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == TriggerType.APP_OPENED) {
                val targetPkg = a.trigger?.params?.get("package")
                if (targetPkg == pkg) {
                    AutomationExecutionService.start(this, a.id)
                }
            }
        }
    }

    override fun onInterrupt() {}
}
