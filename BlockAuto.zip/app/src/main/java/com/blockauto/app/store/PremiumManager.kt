package com.blockauto.app.store

import android.content.Context
import com.blockauto.app.BuildConfig

/**
 * Gère quelles fonctionnalités "premium" sont débloquées sur cet appareil.
 *
 * Important (transparence) : ce squelette N'ENCAISSE PAS de vrais paiements. Pour vendre
 * réellement une fonctionnalité, il faut brancher la Google Play Billing Library (ce qui
 * demande de créer les produits dans la Play Console, un compte marchand, etc. — une
 * étape à faire côté Play Console, pas dans ce fichier). Ce qui est fourni ici :
 *  - le catalogue des fonctionnalités et leur état verrouillé/débloqué ;
 *  - un système de code promo simple pour débloquer manuellement (ex : codes offerts à
 *    des bêta-testeurs, ou remis après un vrai achat traité ailleurs) ;
 *  - un bouton "Restaurer" qui relit ce qui est stocké localement.
 *
 * Volontairement absent : un déblocage caché/"admin" invisible pour l'utilisateur. Un tel
 * mécanisme reviendrait à intégrer, dans l'appli elle-même, un moyen de contourner sa
 * propre boutique — ce qui n'a pas de sens si l'objectif est d'avoir de vraies
 * fonctionnalités qui valent la peine d'être achetées par de vrais utilisateurs. À la
 * place, le mode développeur ci-dessous est visible, documenté, et désactivé par
 * construction dans un build de release (BuildConfig.DEBUG).
 */
object PremiumManager {

    private const val PREFS = "blockauto_store"
    private const val KEY_PREFIX_OWNED = "owned_"
    private const val KEY_DEV_UNLOCK = "dev_unlock_all"

    /** Codes promo valides de démonstration. Dans un vrai lancement, ceci viendrait d'un
     *  serveur (ou d'une vérification de reçu Play Billing), pas d'une liste en dur. */
    private val DEMO_PROMO_CODES = mapOf(
        "BETA-NFC" to FeatureId.NFC_CUSTOM_TAGS,
        "BETA-CLOUD" to FeatureId.CLOUD_BACKUP
    )

    enum class FeatureId(val displayName: String, val description: String, val priceLabel: String) {
        NFC_CUSTOM_TAGS(
            "Tags NFC personnalisés",
            "Écris n'importe quel texte ou lien sur un tag NFC vierge (pas seulement un lancement d'automatisation) : mot de passe Wi-Fi à recopier, carte de visite, lien vers un menu, etc.",
            "2,99 €"
        ),
        CLOUD_BACKUP(
            "Sauvegarde automatique",
            "Sauvegarde chiffrée et horodatée de toutes tes automatisations à chaque modification, en plus de l'export manuel déjà gratuit.",
            "1,99 € / mois"
        ),
        ICON_PACK(
            "Pack d'icônes et thèmes",
            "Personnalise l'icône de l'application et la couleur d'accent de l'atelier.",
            "0,99 €"
        );
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isUnlocked(context: Context, feature: FeatureId): Boolean {
        if (BuildConfig.DEBUG && prefs(context).getBoolean(KEY_DEV_UNLOCK, false)) return true
        return prefs(context).getBoolean(KEY_PREFIX_OWNED + feature.name, false)
    }

    fun unlock(context: Context, feature: FeatureId) {
        prefs(context).edit().putBoolean(KEY_PREFIX_OWNED + feature.name, true).apply()
    }

    /** Résultat de la saisie d'un code promo. */
    sealed class RedeemResult {
        data class Success(val feature: FeatureId) : RedeemResult()
        object Invalid : RedeemResult()
    }

    fun redeemPromoCode(context: Context, rawCode: String): RedeemResult {
        val code = rawCode.trim().uppercase()
        val feature = DEMO_PROMO_CODES[code] ?: return RedeemResult.Invalid
        unlock(context, feature)
        return RedeemResult.Success(feature)
    }

    /** Mode développeur : débloque tout, UNIQUEMENT sur un build de debug (jamais en
     *  release, donc jamais pour un utilisateur qui a téléchargé l'appli publiée), pour
     *  pouvoir tester les fonctionnalités premium sans payer pendant le développement.
     *  Visible et documenté dans l'écran Boutique — ce n'est pas un panneau caché. */
    fun isDevUnlockAvailable(): Boolean = BuildConfig.DEBUG

    fun setDevUnlockAll(context: Context, enabled: Boolean) {
        if (!BuildConfig.DEBUG) return
        prefs(context).edit().putBoolean(KEY_DEV_UNLOCK, enabled).apply()
    }

    fun isDevUnlockAllEnabled(context: Context): Boolean =
        BuildConfig.DEBUG && prefs(context).getBoolean(KEY_DEV_UNLOCK, false)
}
