package com.blockauto.app.builder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** Un nœud de la carte mentale : une pastille colorée + une icône + un libellé + un détail optionnel. */
data class MindMapNode(
    val icon: String,
    val label: String,
    val detail: String?,
    val color: Int
)

/**
 * Vue "carte mentale" de l'automatisation : un nœud racine (le déclencheur) à gauche,
 * relié par des courbes à chaque bloc action qui s'étale verticalement à droite, plus
 * un nœud pointillé "+ Ajouter un bloc" — exactement la représentation Mind Map qu'on
 * trouve dans des outils comme ClickUp, appliquée à une chaîne d'automatisation BlockAuto.
 *
 * C'est un mode d'affichage ALTERNATIF à la chaîne de blocs empilés (RecyclerView +
 * PuzzleBlockView) : les deux lisent/écrivent la même [Automation], seule la représentation
 * visuelle change. Le dessin est entièrement fait au Canvas (pas de sous-vues), et la
 * détection de tap se fait par simple test d'appartenance à un RectF mémorisé au dernier
 * onDraw.
 */
class MindMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Appelé quand on touche le nœud racine (le déclencheur). */
    var onRootTapped: (() -> Unit)? = null

    /** Appelé avec l'index du bloc action touché. */
    var onChildTapped: ((Int) -> Unit)? = null

    /** Appelé quand on touche le nœud pointillé "+ Ajouter un bloc". */
    var onAddTapped: (() -> Unit)? = null

    private var root: MindMapNode? = null
    private var children: List<MindMapNode> = emptyList()

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val nodeHeight = dp(58f)
    private val rootWidth = dp(130f)
    private val rowSpacing = dp(16f)
    private val sidePadding = dp(16f)

    private val rootRect = RectF()
    private val addRect = RectF()
    private val childRects = mutableListOf<RectF>()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#262C52") }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2.5f) }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(17f); textAlign = Paint.Align.CENTER }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(13f); color = Color.parseColor("#F6F7FF")
    }
    private val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(10.5f); color = Color.parseColor("#ACB2DA")
    }
    private val addPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(13f); color = Color.parseColor("#ACB2DA"); textAlign = Paint.Align.CENTER
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        color = Color.parseColor("#6E75A0")
        pathEffect = DashPathEffect(floatArrayOf(dp(8f), dp(6f)), 0f)
    }

    /** Remplace le contenu affiché : un déclencheur (racine) et la liste ordonnée des actions. */
    fun setData(root: MindMapNode, children: List<MindMapNode>) {
        this.root = root
        this.children = children
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val rows = children.size + 1 // +1 pour le nœud pointillé "+ Ajouter"
        val height = (rows * nodeHeight + (rows - 1) * rowSpacing + dp(8f)).toInt()
        setMeasuredDimension(width, height.coerceAtLeast(nodeHeight.toInt()))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = root ?: return
        val w = width.toFloat()
        val h = height.toFloat()

        val rootTop = h / 2f - nodeHeight / 2f
        rootRect.set(sidePadding, rootTop, sidePadding + rootWidth, rootTop + nodeHeight)

        val childLeft = rootRect.right + dp(56f)
        val totalRows = children.size + 1
        val totalContentHeight = totalRows * nodeHeight + (totalRows - 1) * rowSpacing
        var y = (h - totalContentHeight) / 2f

        childRects.clear()
        children.forEach { _ ->
            childRects.add(RectF(childLeft, y, w - sidePadding, y + nodeHeight))
            y += nodeHeight + rowSpacing
        }
        addRect.set(childLeft, y, w - sidePadding, y + nodeHeight)

        // Connecteurs en courbe en S, du nœud racine vers chaque enfant et vers le "+".
        (childRects + addRect).forEach { target -> drawConnector(canvas, rootRect, target, r.color) }

        drawNode(canvas, rootRect, r, isRoot = true)
        children.forEachIndexed { index, node -> drawNode(canvas, childRects[index], node, isRoot = false) }
        drawAddNode(canvas, addRect)
    }

    private fun drawConnector(canvas: Canvas, from: RectF, to: RectF, tint: Int) {
        val startX = from.right
        val startY = from.centerY()
        val endX = to.left
        val endY = to.centerY()
        val midX = (startX + endX) / 2f
        val path = Path().apply {
            moveTo(startX, startY)
            cubicTo(midX, startY, midX, endY, endX, endY)
        }
        linePaint.color = Color.argb(150, Color.red(tint), Color.green(tint), Color.blue(tint))
        canvas.drawPath(path, linePaint)
    }

    private fun drawNode(canvas: Canvas, rect: RectF, node: MindMapNode, isRoot: Boolean) {
        canvas.drawRoundRect(rect, dp(14f), dp(14f), bgPaint)
        borderPaint.color = node.color
        borderPaint.strokeWidth = if (isRoot) dp(2.5f) else dp(1.8f)
        canvas.drawRoundRect(rect, dp(14f), dp(14f), borderPaint)

        val dotCx = rect.left + dp(24f)
        val dotCy = rect.centerY()
        dotPaint.color = node.color
        canvas.drawCircle(dotCx, dotCy, dp(14f), dotPaint)
        canvas.drawText(node.icon, dotCx, dotCy + dp(6f), iconPaint)

        val textStart = rect.left + dp(46f)
        if (node.detail.isNullOrBlank()) {
            canvas.drawText(elide(node.label, rect, textStart, labelPaint), textStart, rect.centerY() + dp(5f), labelPaint)
        } else {
            canvas.drawText(elide(node.label, rect, textStart, labelPaint), textStart, rect.centerY() - dp(4f), labelPaint)
            canvas.drawText(elide(node.detail, rect, textStart, detailPaint), textStart, rect.centerY() + dp(13f), detailPaint)
        }
    }

    private fun drawAddNode(canvas: Canvas, rect: RectF) {
        canvas.drawRoundRect(rect, dp(14f), dp(14f), dashPaint)
        canvas.drawText("+ Ajouter un bloc", rect.centerX(), rect.centerY() + dp(5f), addPaint)
    }

    private fun elide(text: String, rect: RectF, startX: Float, paint: Paint): String {
        val maxWidth = rect.right - startX - dp(10f)
        if (paint.measureText(text) <= maxWidth) return text
        var t = text
        while (t.isNotEmpty() && paint.measureText("$t…") > maxWidth) t = t.dropLast(1)
        return "$t…"
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y
            when {
                rootRect.contains(x, y) -> { performClick(); onRootTapped?.invoke() }
                addRect.contains(x, y) -> { performClick(); onAddTapped?.invoke() }
                else -> {
                    val idx = childRects.indexOfFirst { it.contains(x, y) }
                    if (idx >= 0) { performClick(); onChildTapped?.invoke(idx) }
                }
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
