package com.blockauto.app.builder

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

/** Un nœud de la carte mentale : une pastille colorée + une icône + un libellé + un détail optionnel. */
data class MindMapNode(
    val icon: String,
    val label: String,
    val detail: String?,
    val color: Int
)

/**
 * Vue "carte mentale" INTERACTIVE de l'automatisation : un nœud racine (le déclencheur) relié
 * par un petit hub central à chaque bloc action, plus un nœud pointillé "+ Ajouter un bloc" —
 * la même représentation que dans des outils comme ClickUp, avec les mêmes gestes :
 *
 *  - un doigt sur le fond -> on déplace le canevas (pan) ;
 *  - un doigt posé sur un nœud puis glissé -> on déplace CE nœud librement (drag) ;
 *  - deux doigts -> zoom (pincer), avec zoom centré sur le point du pincement ;
 *  - un simple tap sur un nœud (sans glisser) -> déclenche l'action associée (édition...) ;
 *  - boutons +/- et "recentrer" fournis par la vue hôte via [zoomBy] / [recenter].
 *
 * Les nœuds vivent dans un espace "monde" indépendant de la taille de l'écran ; un fond en
 * pointillés (grille) est dessiné dans ce même espace pour qu'il bouge avec le pan/zoom, comme
 * un vrai canevas de mind-map. Les positions déplacées à la main sont conservées (par clé
 * icône+libellé) tant que la structure ne change pas trop, pour ne pas tout réinitialiser à
 * chaque petite modification de l'automatisation.
 */
class MindMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Appelé quand on TAPE (sans glisser) le nœud racine (le déclencheur). */
    var onRootTapped: (() -> Unit)? = null

    /** Appelé avec l'index du bloc action tapé (sans glisser). */
    var onChildTapped: ((Int) -> Unit)? = null

    /** Appelé quand on tape le nœud pointillé "+ Ajouter un bloc". */
    var onAddTapped: (() -> Unit)? = null

    private var root: MindMapNode? = null
    private var children: List<MindMapNode> = emptyList()

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    // ---- Tailles des nœuds (en unités "monde") ----
    private val nodeHeight = dp(58f)
    private val rootWidth = dp(148f)
    private val childWidth = dp(158f)
    private val rowSpacing = dp(28f)
    private val hubRadius = dp(7f)
    private val corner = dp(14f)

    private enum class Kind { ROOT, HUB, CHILD, ADD }

    private class NodeBox(
        val kind: Kind,
        val index: Int, // pour les CHILD : index dans `children`
        var cx: Float,
        var cy: Float,
        val w: Float,
        val h: Float,
        val node: MindMapNode?
    ) {
        val rect = RectF()
        fun refreshRect() { rect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f) }
    }

    private val boxes = mutableListOf<NodeBox>()
    // Positions personnalisées mémorisées par clé stable (icône+libellé), pour survivre aux
    // petites modifications de l'automatisation (ajout/suppression d'un autre bloc, etc.)
    private val savedPositions = mutableMapOf<String, Pair<Float, Float>>()
    private var hasBoxes = false
    private var cameraCentered = false

    // ---- Pan / zoom ----
    private var scale = 1f
    private var panX = 0f
    private var panY = 0f
    private val minScale = 0.45f
    private val maxScale = 2.2f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val newScale = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
            val factor = newScale / scale
            // Zoom centré sur le point de pincement : on ajuste le pan pour que ce point
            // reste visuellement fixe pendant le zoom.
            panX = detector.focusX - (detector.focusX - panX) * factor
            panY = detector.focusY - (detector.focusY - panY) * factor
            scale = newScale
            invalidate()
            return true
        }
    })

    private var draggingBox: NodeBox? = null
    private var isPanning = false
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val tapSlop = dp(10f)

    // ---- Peintures ----
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B2040") }
    private val bgPaintRoot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#262C52") }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33000000") }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2.4f) }
    private val hubFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hubRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(2f); color = Color.parseColor("#0D1021")
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#242A50") }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(17f); textAlign = Paint.Align.CENTER }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(13f); color = Color.parseColor("#F6F7FF")
    }
    private val labelPaintBold = Paint(labelPaint).apply { isFakeBoldText = true; textSize = dp(13.5f) }
    private val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(10.5f); color = Color.parseColor("#ACB2DA")
    }
    private val addPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(13f); color = Color.parseColor("#ACB2DA"); textAlign = Paint.Align.CENTER
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        color = Color.parseColor("#6E75A0")
        pathEffect = DashPathEffect(floatArrayOf(dp(8f), dp(6f)), 0f)
    }

    // Palette de couleurs pour les branches, cyclée par index d'enfant (façon ClickUp : chaque
    // branche a sa propre couleur de fil, distincte de la couleur "catégorie" du nœud lui-même).
    private val branchColors = listOf(
        Color.parseColor("#4C97FF"),
        Color.parseColor("#9966FF"),
        Color.parseColor("#FFC93C"),
        Color.parseColor("#2BE0C9"),
        Color.parseColor("#FF6FB0"),
        Color.parseColor("#4CD97B")
    )

    /** Remplace le contenu affiché : un déclencheur (racine) et la liste ordonnée des actions. */
    fun setData(root: MindMapNode, children: List<MindMapNode>) {
        this.root = root
        this.children = children
        layoutBoxes()
        hasBoxes = true
        invalidate()
    }

    private fun keyOf(kind: Kind, index: Int, node: MindMapNode?): String = when (kind) {
        Kind.ROOT -> "root"
        Kind.HUB -> "hub"
        Kind.ADD -> "add"
        Kind.CHILD -> "child:${node?.icon}:${node?.label}:$index"
    }

    /** Calcule (ou recalcule) les positions des nœuds dans l'espace monde. */
    private fun layoutBoxes() {
        val r = root ?: return
        val newBoxes = mutableListOf<NodeBox>()

        val rootCx = dp(100f)
        val rootCy = dp(40f) + (children.size * (nodeHeight + rowSpacing)) / 2f
        newBoxes.add(makeBox(Kind.ROOT, -1, rootCx, rootCy, rootWidth, nodeHeight, r))

        val hubCx = rootCx + rootWidth / 2f + dp(46f)
        val hubCy = rootCy
        newBoxes.add(makeBox(Kind.HUB, -1, hubCx, hubCy, hubRadius * 2, hubRadius * 2, null))

        val childLeft = hubCx + dp(46f)
        val totalRows = children.size + 1
        val totalHeight = totalRows * nodeHeight + (totalRows - 1) * rowSpacing
        var y = rootCy - totalHeight / 2f + nodeHeight / 2f
        children.forEachIndexed { index, node ->
            newBoxes.add(makeBox(Kind.CHILD, index, childLeft + childWidth / 2f, y, childWidth, nodeHeight, node))
            y += nodeHeight + rowSpacing
        }
        newBoxes.add(makeBox(Kind.ADD, -1, childLeft + childWidth / 2f, y, childWidth, nodeHeight, null))

        boxes.clear()
        boxes.addAll(newBoxes)
        boxes.forEach { it.refreshRect() }
    }

    /** Centre la caméra sur le nœud racine une fois que la vue a une taille connue (ne se
     *  déclenche qu'une fois, pour ne pas recentrer sous le doigt de l'utilisateur à chaque
     *  petite mise à jour des données). */
    private fun centerCameraIfNeeded() {
        if (cameraCentered || height <= 0) return
        val rootBox = boxes.firstOrNull { it.kind == Kind.ROOT } ?: return
        scale = 1f
        panX = dp(24f)
        panY = height / 2f - rootBox.cy
        cameraCentered = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (h > 0 && hasBoxes) centerCameraIfNeeded()
    }

    private fun makeBox(kind: Kind, index: Int, cx: Float, cy: Float, w: Float, h: Float, node: MindMapNode?): NodeBox {
        val key = keyOf(kind, index, node)
        val saved = savedPositions[key]
        val box = if (saved != null) NodeBox(kind, index, saved.first, saved.second, w, h, node)
                  else NodeBox(kind, index, cx, cy, w, h, node)
        return box
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (root == null) return
        centerCameraIfNeeded()

        canvas.save()
        canvas.translate(panX, panY)
        canvas.scale(scale, scale)

        drawGrid(canvas)

        val hub = boxes.firstOrNull { it.kind == Kind.HUB }
        val rootBox = boxes.firstOrNull { it.kind == Kind.ROOT }
        val addBox = boxes.firstOrNull { it.kind == Kind.ADD }
        val childBoxes = boxes.filter { it.kind == Kind.CHILD }

        if (rootBox != null && hub != null) {
            drawStraightConnector(canvas, rootBox.rect.right, rootBox.cy, hub.cx, hub.cy, rootBox.node?.color ?: Color.WHITE)
        }
        if (hub != null) {
            childBoxes.forEachIndexed { i, box ->
                drawCurvedConnector(canvas, hub.cx, hub.cy, box.rect.left, box.cy, branchColors[i % branchColors.size])
            }
            if (addBox != null) {
                drawCurvedConnector(canvas, hub.cx, hub.cy, addBox.rect.left, addBox.cy, Color.parseColor("#6E75A0"))
            }
        }

        if (hub != null) drawHub(canvas, hub, rootBox?.node?.color ?: Color.parseColor("#7C5CFC"))
        rootBox?.let { drawNode(canvas, it, isRoot = true) }
        childBoxes.forEach { drawNode(canvas, it, isRoot = false) }
        addBox?.let { drawAddNode(canvas, it) }

        canvas.restore()
    }

    private fun drawGrid(canvas: Canvas) {
        val step = dp(22f)
        // Bornes visibles en espace "monde" à partir du pan/zoom courant.
        val left = -panX / scale
        val top = -panY / scale
        val right = left + width / scale
        val bottom = top + height / scale
        var gx = (left / step).toInt() * step
        while (gx < right) {
            var gy = (top / step).toInt() * step
            while (gy < bottom) {
                canvas.drawCircle(gx, gy, dp(1.3f), gridDotPaint)
                gy += step
            }
            gx += step
        }
    }

    private fun drawStraightConnector(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, tint: Int) {
        linePaint.color = Color.argb(200, Color.red(tint), Color.green(tint), Color.blue(tint))
        canvas.drawLine(x1, y1, x2, y2, linePaint)
    }

    private fun drawCurvedConnector(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, tint: Int) {
        val midX = (x1 + x2) / 2f
        val path = Path().apply {
            moveTo(x1, y1)
            cubicTo(midX, y1, midX, y2, x2, y2)
        }
        linePaint.color = Color.argb(210, Color.red(tint), Color.green(tint), Color.blue(tint))
        canvas.drawPath(path, linePaint)
    }

    private fun drawHub(canvas: Canvas, hub: NodeBox, tint: Int) {
        hubFillPaint.color = tint
        canvas.drawCircle(hub.cx, hub.cy, hubRadius, hubFillPaint)
        canvas.drawCircle(hub.cx, hub.cy, hubRadius, hubRingPaint)
    }

    private fun drawNode(canvas: Canvas, box: NodeBox, isRoot: Boolean) {
        val node = box.node ?: return
        val rect = box.rect
        // Petite ombre portée pour détacher visuellement le nœud du canevas (effet "carte").
        val shadowRect = RectF(rect.left, rect.top + dp(2.5f), rect.right, rect.bottom + dp(2.5f))
        canvas.drawRoundRect(shadowRect, corner, corner, shadowPaint)

        canvas.drawRoundRect(rect, corner, corner, if (isRoot) bgPaintRoot else bgPaint)
        borderPaint.color = node.color
        borderPaint.strokeWidth = if (isRoot) dp(2.6f) else dp(1.8f)
        canvas.drawRoundRect(rect, corner, corner, borderPaint)

        val dotCx = rect.left + dp(24f)
        val dotCy = rect.centerY()
        dotPaint.color = node.color
        canvas.drawCircle(dotCx, dotCy, dp(14f), dotPaint)
        canvas.drawText(node.icon, dotCx, dotCy + dp(6f), iconPaint)

        val textStart = rect.left + dp(46f)
        val labelP = if (isRoot) labelPaintBold else labelPaint
        if (node.detail.isNullOrBlank()) {
            canvas.drawText(elide(node.label, rect, textStart, labelP), textStart, rect.centerY() + dp(5f), labelP)
        } else {
            canvas.drawText(elide(node.label, rect, textStart, labelP), textStart, rect.centerY() - dp(4f), labelP)
            canvas.drawText(elide(node.detail, rect, textStart, detailPaint), textStart, rect.centerY() + dp(13f), detailPaint)
        }
    }

    private fun drawAddNode(canvas: Canvas, box: NodeBox) {
        canvas.drawRoundRect(box.rect, corner, corner, dashPaint)
        canvas.drawText("+ Ajouter un bloc", box.rect.centerX(), box.rect.centerY() + dp(5f), addPaint)
    }

    private fun elide(text: String, rect: RectF, startX: Float, paint: Paint): String {
        val maxWidth = rect.right - startX - dp(10f)
        if (paint.measureText(text) <= maxWidth) return text
        var t = text
        while (t.isNotEmpty() && paint.measureText("$t…") > maxWidth) t = t.dropLast(1)
        return "$t…"
    }

    // ---- Conversion écran -> monde, pour la détection de nœud sous le doigt ----
    private fun toWorldX(screenX: Float) = (screenX - panX) / scale
    private fun toWorldY(screenY: Float) = (screenY - panY) / scale

    private fun boxAt(worldX: Float, worldY: Float): NodeBox? =
        boxes.filter { it.kind != Kind.HUB }.lastOrNull { it.rect.contains(worldX, worldY) }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x; downY = event.y
                lastTouchX = event.x; lastTouchY = event.y
                moved = false
                val wx = toWorldX(event.x); val wy = toWorldY(event.y)
                val hit = boxAt(wx, wy)
                if (hit != null) { draggingBox = hit; isPanning = false }
                else { draggingBox = null; isPanning = true }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Un 2e doigt arrive : on bascule en pincement, on annule un éventuel drag de nœud.
                draggingBox = null
                isPanning = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    if (abs(event.x - downX) > tapSlop || abs(event.y - downY) > tapSlop) moved = true
                    val box = draggingBox
                    if (box != null) {
                        box.cx += dx / scale
                        box.cy += dy / scale
                        box.refreshRect()
                        savedPositions[keyOf(box.kind, box.index, box.node)] = box.cx to box.cy
                        invalidate()
                    } else if (isPanning) {
                        panX += dx
                        panY += dy
                        invalidate()
                    }
                    lastTouchX = event.x
                    lastTouchY = event.y
                }
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (!moved) {
                    val wx = toWorldX(event.x); val wy = toWorldY(event.y)
                    val hit = boxAt(wx, wy)
                    if (hit != null) {
                        performClick()
                        when (hit.kind) {
                            Kind.ROOT -> onRootTapped?.invoke()
                            Kind.ADD -> onAddTapped?.invoke()
                            Kind.CHILD -> onChildTapped?.invoke(hit.index)
                            else -> {}
                        }
                    }
                }
                draggingBox = null
                isPanning = false
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                draggingBox = null
                isPanning = false
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    // ---- Contrôles exposés pour des boutons +/- / recentrer côté activité ----

    /** Zoome (facteur > 1) ou dézoome (facteur < 1) en gardant le centre de la vue fixe. */
    fun zoomBy(factor: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val newScale = (scale * factor).coerceIn(minScale, maxScale)
        val f = newScale / scale
        panX = cx - (cx - panX) * f
        panY = cy - (cy - panY) * f
        scale = newScale
        invalidate()
    }

    /** Réinitialise la vue (zoom 1x) et replace le nœud racine bien en vue, sans toucher aux
     *  positions personnalisées des nœuds (on ne fait que redéplacer la caméra). */
    fun recenter() {
        val startScale = scale
        val startPanX = panX
        val startPanY = panY
        val rootBox = boxes.firstOrNull { it.kind == Kind.ROOT }
        val targetScale = 1f
        val targetPanX = dp(24f)
        val targetPanY = if (rootBox != null) height / 2f - rootBox.cy else panY

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                scale = startScale + (targetScale - startScale) * t
                panX = startPanX + (targetPanX - startPanX) * t
                panY = startPanY + (targetPanY - startPanY) * t
                invalidate()
            }
        }.start()
    }

    fun currentZoomPercent(): Int = (scale * 100).toInt()
}
