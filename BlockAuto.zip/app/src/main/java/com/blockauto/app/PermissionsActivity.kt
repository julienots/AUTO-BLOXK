package com.blockauto.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.blockauto.app.databinding.ActivityPermissionsBinding
import com.google.android.material.snackbar.Snackbar

class PermissionsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPermissionsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnAccessibility.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.btnNotifListener.setOnClickListener {
            openOrFallback(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        binding.btnWriteSettings.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        binding.btnDndAccess.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        binding.btnOverlay.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        binding.btnBatteryOpt.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        binding.btnAppSettings.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    /**
     * BUG CORRIGÉ (v2) : le v1 de ce correctif se contentait d'un try/catch autour de
     * startActivity(). Ça couvre le cas où l'écran système lève une exception, mais sur
     * beaucoup de téléphones récents (Android 11+, surcouches One UI/MIUI/ColorOS très
     * verrouillées) l'appel ne lève PAS d'exception : le système résout silencieusement
     * l'intent vers "aucune activité" et startActivity() ne fait tout simplement rien,
     * sans crash — d'où l'impression de bouton mort alors que le fallback ne se
     * déclenchait jamais. On vérifie donc explicitement AVANT d'appeler startActivity()
     * que l'intent est résoluble (resolveActivity), et on route vers le fallback dans les
     * deux cas (non résoluble OU exception).
     */
    private fun openOrFallback(intent: Intent) {
        val resoluble = intent.resolveActivity(packageManager) != null
        Log.d("BlockAuto-Perms", "Intent ${intent.action} résoluble=$resoluble")

        if (!resoluble) {
            fallbackToAppSettings("Ce réglage n'est pas disponible directement sur ton téléphone. Cherche-le dans les paramètres de l'application qui viennent de s'ouvrir (Autorisations, Batterie, Notifications...).")
            return
        }

        try {
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("BlockAuto-Perms", "startActivity a échoué pour ${intent.action}", e)
            fallbackToAppSettings("Ce réglage n'est pas accessible directement sur ton téléphone. Cherche-le dans les paramètres de l'application qui viennent de s'ouvrir (Autorisations, Batterie, Notifications...).")
        }
    }

    private fun fallbackToAppSettings(message: String) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
        } catch (e: Exception) {
            Log.e("BlockAuto-Perms", "Même le fallback vers les paramètres de l'app a échoué", e)
            Snackbar.make(
                binding.root,
                "Impossible d'ouvrir ce réglage sur ton téléphone. Cherche-le manuellement dans les paramètres Android.",
                Snackbar.LENGTH_LONG
            ).show()
        }
    }
}
