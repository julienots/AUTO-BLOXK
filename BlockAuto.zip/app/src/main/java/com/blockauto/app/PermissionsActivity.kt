package com.blockauto.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.blockauto.app.databinding.ActivityPermissionsBinding
import com.google.android.material.snackbar.Snackbar

class PermissionsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPermissionsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnAccessibility.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.btnNotifListener.setOnClickListener {
            openOrFallback(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        binding.btnWriteSettings.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        binding.btnDndAccess.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        binding.btnOverlay.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        binding.btnBatteryOpt.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        binding.btnAppSettings.setOnClickListener {
            openOrFallback(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    /**
     * BUG CORRIGÉ : chaque bouton appelait startActivity() directement, sans filet de
     * sécurité — contrairement aux appels équivalents dans MainActivity, qui sont protégés
     * par un try/catch avec le commentaire "certains constructeurs bloquent cet intent".
     * Sur les téléphones où l'écran système visé n'existe pas ou est bloqué par la
     * surcouche du fabricant (constaté notamment sur certaines versions de MIUI, EMUI,
     * ColorOS pour les réglages de notifications ou d'accessibilité), startActivity()
     * levait une ActivityNotFoundException/SecurityException non rattrapée : toute
     * l'activité Autorisations plantait et se refermait aussitôt, ce qui pouvait donner
     * l'impression que "rien ne s'ouvre" en appuyant sur une rangée.
     * On retombe maintenant sur l'écran général des paramètres de l'application (qui,
     * lui, existe toujours) avec un message expliquant où chercher le réglage à la main.
     */
    private fun openOrFallback(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                Snackbar.make(
                    binding.root,
                    "Ce réglage n'est pas accessible directement sur ton téléphone. Cherche-le dans les paramètres de l'application qui viennent de s'ouvrir (Autorisations, Batterie, Notifications...).",
                    Snackbar.LENGTH_LONG
                ).show()
            } catch (e2: Exception) {
                Snackbar.make(
                    binding.root,
                    "Impossible d'ouvrir ce réglage sur ton téléphone. Cherche-le manuellement dans les paramètres Android.",
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }
}
