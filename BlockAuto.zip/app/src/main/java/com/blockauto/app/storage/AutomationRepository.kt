package com.blockauto.app.storage

import android.content.Context
import com.blockauto.app.model.Automation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/** Sauvegarde toutes les automatisations de l'utilisateur en local (aucun serveur). */
object AutomationRepository {
    private const val PREFS = "block_auto_prefs"
    private const val KEY = "automations_json"
    private val gson = Gson()

    fun getAll(context: Context): MutableList<Automation> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Automation>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveAll(context: Context, list: List<Automation>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
    }

    fun get(context: Context, id: String): Automation? = getAll(context).find { it.id == id }

    fun save(context: Context, automation: Automation) {
        val list = getAll(context)
        val idx = list.indexOfFirst { it.id == automation.id }
        if (idx >= 0) list[idx] = automation else list.add(automation)
        saveAll(context, list)
    }

    fun delete(context: Context, id: String) {
        val list = getAll(context).filterNot { it.id == id }
        saveAll(context, list)
    }
}
