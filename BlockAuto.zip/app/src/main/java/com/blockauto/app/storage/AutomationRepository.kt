package com.blockauto.app.storage

import android.content.Context
import com.blockauto.app.model.Automation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/** Sauvegarde toutes les automatisations de l'utilisateur en local (aucun serveur). */
object AutomationRepository {
    private const val PREFS = "block_auto_prefs"
    private const val KEY = "automations_json"
    private val gson = Gson()

    fun getAll(context: Context): MutableList<Automation> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Automation>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveAll(context: Context, list: List<Automation>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
    }

    fun get(context: Context, id: String): Automation? = getAll(context).find { it.id == id }

    fun save(context: Context, automation: Automation) {
        val list = getAll(context)
        val idx = list.indexOfFirst { it.id == automation.id }
        if (idx >= 0) list[idx] = automation else list.add(automation)
        saveAll(context, list)
    }

    fun delete(context: Context, id: String) {
        val list = getAll(context).filterNot { it.id == id }
        saveAll(context, list)
    }

    /**
     * Duplique une automatisation en profondeur (nouveau [Automation.id], déclencheur et
     * blocs recopiés, pas juste la même référence de liste mutable) : sans ce passage par
     * JSON, modifier la copie via l'éditeur aurait aussi modifié l'original en mémoire,
     * puisque `data class.copy()` ne recopie pas le contenu des listes/objets imbriqués.
     * Désactivée par défaut pour éviter que deux automatisations identiques ne se déclenchent
     * en même temps sans que l'utilisateur l'ait explicitement voulu.
     */
    fun duplicate(context: Context, source: Automation): Automation {
        val json = gson.toJson(source)
        val copy = gson.fromJson(json, Automation::class.java)
        val baseName = source.name.ifBlank { "Automatisation" }
        val renamed = copy.copy(
            id = UUID.randomUUID().toString(),
            name = baseName + context.getString(com.blockauto.app.R.string.duplicate_suffix),
            enabled = false
        )
        save(context, renamed)
        return renamed
    }

    /**
     * Format de fichier BlockAuto (.Ba). Le fichier reste lisible en UTF-8 mais possède
     * une signature/version propres à BlockAuto afin que d'autres applications puissent
     * prendre en charge le même format plus tard.
     */
    private const val BA_MAGIC = "BLOCKAUTO_BA"
    private const val BA_VERSION = "1"

    fun exportAutomationBa(automation: Automation): String {
        return buildString {
            append(BA_MAGIC).append('\n')
            append("VERSION=").append(BA_VERSION).append('\n')
            append("TYPE=AUTOMATION").append('\n')
            append("DATA=").append(gson.toJson(automation)).append('\n')
        }
    }

    /** Exporte toutes les automatisations dans un seul fichier .Ba de type bundle. */
    fun exportBundleBa(context: Context): String {
        return buildString {
            append(BA_MAGIC).append('\n')
            append("VERSION=").append(BA_VERSION).append('\n')
            append("TYPE=BUNDLE").append('\n')
            append("DATA=").append(gson.toJson(getAll(context))).append('\n')
        }
    }

    /** JSON legacy conservé pour compatibilité avec les anciennes sauvegardes. */
    fun exportJson(context: Context): String = gson.toJson(getAll(context))

    /** Importe un fichier .Ba (automation ou bundle), tout en acceptant l'ancien JSON. */
    fun importBa(context: Context, content: String): Int {
        val text = content.trim()
        if (!text.startsWith(BA_MAGIC)) return importJson(context, text)

        val lines = text.lines()
        val version = lines.firstOrNull { it.startsWith("VERSION=") }?.substringAfter('=')
        val type = lines.firstOrNull { it.startsWith("TYPE=") }?.substringAfter('=')
        val data = lines.firstOrNull { it.startsWith("DATA=") }?.substringAfter('=')
        if (version != BA_VERSION || data.isNullOrBlank()) return -1

        return try {
            if (type == "AUTOMATION") {
                val automation = gson.fromJson(data, Automation::class.java) ?: return -1
                importAutomations(context, listOf(automation))
            } else if (type == "BUNDLE") {
                val listType = object : TypeToken<List<Automation>>() {}.type
                val automations: List<Automation> = gson.fromJson(data, listType) ?: return -1
                importAutomations(context, automations)
            } else {
                -1
            }
        } catch (_: Exception) {
            -1
        }
    }

    private fun importAutomations(context: Context, imported: List<Automation>): Int {
        if (imported.isEmpty()) return 0
        val existing = getAll(context)
        val existingIds = existing.map { it.id }.toHashSet()
        val toAdd = imported.filter { it.id.isNotBlank() && existingIds.add(it.id) }
        if (toAdd.isNotEmpty()) saveAll(context, existing + toAdd)
        return toAdd.size
    }

    /**
     * Importe une sauvegarde JSON en fusionnant avec les automatisations existantes :
     * les entrées dont l'id existe déjà sont ignorées (pas d'écrasement silencieux d'une
     * automatisation modifiée depuis), le reste est ajouté avec son id d'origine préservé.
     * Retourne le nombre d'automatisations effectivement ajoutées, ou -1 si le JSON est invalide.
     */
    fun importJson(context: Context, json: String): Int {
        val type = object : TypeToken<List<Automation>>() {}.type
        val imported: List<Automation> = try {
            gson.fromJson(json, type) ?: return -1
        } catch (e: Exception) {
            return -1
        }
        return importAutomations(context, imported)
    }
}
