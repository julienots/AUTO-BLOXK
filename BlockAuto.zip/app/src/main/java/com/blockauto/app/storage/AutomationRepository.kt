package com.blockauto.app.storage

import android.content.Context
import com.blockauto.app.model.Automation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/** Sauvegarde toutes les automatisations de l'utilisateur en local (aucun serveur). */
object AutomationRepository {
    private const val PREFS = "block_auto_prefs"
    private const val KEY = "automations_json"
    private val gson = Gson()

    fun getAll(context: Context): MutableList<Automation> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Automation>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveAll(context: Context, list: List<Automation>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
    }

    fun get(context: Context, id: String): Automation? = getAll(context).find { it.id == id }

    fun save(context: Context, automation: Automation) {
        val list = getAll(context)
        val idx = list.indexOfFirst { it.id == automation.id }
        if (idx >= 0) list[idx] = automation else list.add(automation)
        saveAll(context, list)
    }

    fun delete(context: Context, id: String) {
        val list = getAll(context).filterNot { it.id == id }
        saveAll(context, list)
    }

    /**
     * Duplique une automatisation en profondeur (nouveau [Automation.id], déclencheur et
     * blocs recopiés, pas juste la même référence de liste mutable) : sans ce passage par
     * JSON, modifier la copie via l'éditeur aurait aussi modifié l'original en mémoire,
     * puisque `data class.copy()` ne recopie pas le contenu des listes/objets imbriqués.
     * Désactivée par défaut pour éviter que deux automatisations identiques ne se déclenchent
     * en même temps sans que l'utilisateur l'ait explicitement voulu.
     */
    fun duplicate(context: Context, source: Automation): Automation {
        val json = gson.toJson(source)
        val copy = gson.fromJson(json, Automation::class.java)
        val baseName = source.name.ifBlank { "Automatisation" }
        val renamed = copy.copy(
            id = UUID.randomUUID().toString(),
            name = baseName + context.getString(com.blockauto.app.R.string.duplicate_suffix),
            enabled = false
        )
        save(context, renamed)
        return renamed
    }

    /** JSON exportable tel quel (même format que le stockage interne) pour sauvegarde/partage. */
    fun exportJson(context: Context): String = gson.toJson(getAll(context))

    /**
     * Importe une sauvegarde JSON en fusionnant avec les automatisations existantes :
     * les entrées dont l'id existe déjà sont ignorées (pas d'écrasement silencieux d'une
     * automatisation modifiée depuis), le reste est ajouté avec son id d'origine préservé.
     * Retourne le nombre d'automatisations effectivement ajoutées, ou -1 si le JSON est invalide.
     */
    fun importJson(context: Context, json: String): Int {
        val type = object : TypeToken<List<Automation>>() {}.type
        val imported: List<Automation> = try {
            gson.fromJson(json, type) ?: return -1
        } catch (e: Exception) {
            return -1
        }
        if (imported.isEmpty()) return 0
        val existing = getAll(context)
        val existingIds = existing.map { it.id }.toHashSet()
        val toAdd = imported.filter { it.id.isNotBlank() && existingIds.add(it.id) }
        if (toAdd.isNotEmpty()) saveAll(context, existing + toAdd)
        return toAdd.size
    }
}
