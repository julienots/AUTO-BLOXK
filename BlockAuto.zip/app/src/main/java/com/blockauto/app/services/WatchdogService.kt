package com.blockauto.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import kotlin.math.sqrt

/**
 * Petit service qui reste vivant en tâche de fond pour surveiller les événements
 * que le système n'autorise plus dans le manifeste (restrictions Android 8+) :
 * écran on/off, déverrouillage, Wi-Fi, Bluetooth, casque, mode avion, secousse.
 * C'est la pièce maîtresse qui permet à BlockAuto de fonctionner même app fermée.
 */
class WatchdogService : Service(), SensorEventListener {

    private var lastWifiState: Boolean? = null
    private var lastShakeAt = 0L
    private var sensorManager: SensorManager? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null
    private val batteryConditionState = mutableMapOf<String, Boolean>()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return
            val percent = (level * 100) / scale
            checkBatteryLevelTriggers(percent)
        }
    }

    private fun checkBatteryLevelTriggers(percent: Int) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled || a.trigger?.type != TriggerType.BATTERY_LEVEL) continue
            val target = a.trigger?.params?.get("level")?.toIntOrNull() ?: continue
            val operator = a.trigger?.params?.get("operator") ?: "above"
            val conditionNow = if (operator == "below") percent <= target else percent >= target
            val wasTrue = batteryConditionState[a.id] ?: false
            if (conditionNow && !wasTrue) {
                AutomationExecutionService.start(this, a.id)
            }
            batteryConditionState[a.id] = conditionNow
        }
    }

    private val screenAndSystemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val type = when (intent.action) {
                Intent.ACTION_SCREEN_ON -> TriggerType.SCREEN_ON
                Intent.ACTION_SCREEN_OFF -> TriggerType.SCREEN_OFF
                Intent.ACTION_USER_PRESENT -> TriggerType.DEVICE_UNLOCKED
                Intent.ACTION_HEADSET_PLUG -> if (intent.getIntExtra("state", 0) == 1) TriggerType.HEADSET_CONNECTED else null
                BluetoothDevice.ACTION_ACL_CONNECTED -> TriggerType.BLUETOOTH_CONNECTED
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> if (intent.getBooleanExtra("state", false)) TriggerType.AIRPLANE_MODE_ON else null
                else -> null
            } ?: return
            fireTriggersOfType(type)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        registerRuntimeReceivers()
        registerConnectivityCallback()
        registerShakeDetector()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenAndSystemReceiver) } catch (e: Exception) {}
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {}
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectivityCallback?.let { cm.unregisterNetworkCallback(it) }
        } catch (e: Exception) {}
        sensorManager?.unregisterListener(this)
    }

    private fun registerRuntimeReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }
        registerReceiver(screenAndSystemReceiver, filter)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun registerConnectivityCallback() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            connectivityCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (lastWifiState != true) {
                        lastWifiState = true
                        fireTriggersOfType(TriggerType.WIFI_CONNECTED)
                    }
                }
                override fun onLost(network: Network) {
                    if (lastWifiState != false) {
                        lastWifiState = false
                        fireTriggersOfType(TriggerType.WIFI_DISCONNECTED)
                    }
                }
            }
            cm.registerNetworkCallback(request, connectivityCallback!!)
        } catch (e: Exception) { /* ignoré si non disponible */ }
    }

    private fun registerShakeDetector() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accelerometer != null) {
            sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val gX = event.values[0] / 9.81f
        val gY = event.values[1] / 9.81f
        val gZ = event.values[2] / 9.81f
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)
        if (gForce > 2.7f) {
            val now = System.currentTimeMillis()
            if (now - lastShakeAt > 2000) {
                lastShakeAt = now
                fireTriggersOfType(TriggerType.SHAKE)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun fireTriggersOfType(type: TriggerType) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == type) {
                AutomationExecutionService.start(this, a.id)
            }
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "watchdog_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Surveillance BlockAuto", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BlockAuto est actif")
            .setContentText("Tes automatisations continuent de fonctionner en arrière-plan")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        startForeground(2, notif)
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, WatchdogService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
