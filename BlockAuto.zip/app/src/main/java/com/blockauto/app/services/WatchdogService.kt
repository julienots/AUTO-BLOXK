package com.blockauto.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import kotlin.math.sqrt

/**
 * Petit service qui reste vivant en tâche de fond pour surveiller les événements
 * que le système n'autorise plus dans le manifeste (restrictions Android 8+) :
 * écran on/off, déverrouillage, Wi-Fi, Bluetooth, casque, mode avion, secousse.
 * C'est la pièce maîtresse qui permet à BlockAuto de fonctionner même app fermée.
 */
class WatchdogService : Service(), SensorEventListener {

    private var lastWifiState: Boolean? = null
    private var lastShakeAt = 0L
    private var sensorManager: SensorManager? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null
    private val batteryConditionState = mutableMapOf<String, Boolean>()
    private var wasRinging = false
    private var legacyPhoneListener: PhoneStateListener? = null
    private var telephonyCallback: TelephonyCallback? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return
            val percent = (level * 100) / scale
            checkBatteryLevelTriggers(percent)
        }
    }

    private fun checkBatteryLevelTriggers(percent: Int) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled || a.trigger?.type != TriggerType.BATTERY_LEVEL) continue
            val target = a.trigger?.params?.get("level")?.toIntOrNull() ?: continue
            val operator = a.trigger?.params?.get("operator") ?: "above"
            val conditionNow = if (operator == "below") percent <= target else percent >= target
            val wasTrue = batteryConditionState[a.id] ?: false
            if (conditionNow && !wasTrue) {
                AutomationExecutionService.start(this, a.id)
            }
            batteryConditionState[a.id] = conditionNow
        }
    }

    private val screenAndSystemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val type = when (intent.action) {
                Intent.ACTION_SCREEN_ON -> TriggerType.SCREEN_ON
                Intent.ACTION_SCREEN_OFF -> TriggerType.SCREEN_OFF
                Intent.ACTION_USER_PRESENT -> TriggerType.DEVICE_UNLOCKED
                Intent.ACTION_HEADSET_PLUG -> if (intent.getIntExtra("state", 0) == 1) TriggerType.HEADSET_CONNECTED else null
                BluetoothDevice.ACTION_ACL_CONNECTED -> TriggerType.BLUETOOTH_CONNECTED
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> if (intent.getBooleanExtra("state", false)) TriggerType.AIRPLANE_MODE_ON else null
                else -> null
            } ?: return
            fireTriggersOfType(type)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        // Chaque étape est indépendante : si l'une échoue sur un appareil particulier,
        // les autres déclencheurs continuent quand même de fonctionner.
        try { registerRuntimeReceivers() } catch (e: Exception) {}
        try { registerConnectivityCallback() } catch (e: Exception) {}
        try { registerShakeDetector() } catch (e: Exception) {}
        try { registerCallStateListener() } catch (e: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenAndSystemReceiver) } catch (e: Exception) {}
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {}
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectivityCallback?.let { cm.unregisterNetworkCallback(it) }
        } catch (e: Exception) {}
        sensorManager?.unregisterListener(this)
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                telephonyCallback?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacyPhoneListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (e: Exception) {}
    }

    /**
     * Détecte les appels entrants / la fin d'un appel pour déclencher les blocs
     * "Appel entrant" et "Appel terminé", sans nécessiter le service d'accessibilité.
     */
    private fun registerCallStateListener() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val onStateChanged: (Int) -> Unit = { state ->
            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> {
                    wasRinging = true
                    fireTriggersOfType(TriggerType.CALL_INCOMING)
                }
                TelephonyManager.CALL_STATE_IDLE -> {
                    if (wasRinging) {
                        wasRinging = false
                        fireTriggersOfType(TriggerType.CALL_ENDED)
                    }
                }
                else -> {}
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = onStateChanged(state)
            }
            telephonyCallback = callback
            tm.registerTelephonyCallback(mainExecutor, callback)
        } else {
            @Suppress("DEPRECATION")
            val listener = object : PhoneStateListener() {
                @Suppress("DEPRECATION")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) = onStateChanged(state)
            }
            legacyPhoneListener = listener
            @Suppress("DEPRECATION")
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    private fun registerRuntimeReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }
        try {
            // Sur Android 13+ (API 33), il faut obligatoirement préciser RECEIVER_EXPORTED
            // ou RECEIVER_NOT_EXPORTED, sinon Android lève une SecurityException qui
            // faisait planter tout le service de veille au démarrage (donc tous les
            // déclencheurs qui en dépendent ne fonctionnaient plus du tout).
            ContextCompat.registerReceiver(this, screenAndSystemReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (e: Exception) { /* ne bloque pas le reste de l'initialisation */ }
        try {
            ContextCompat.registerReceiver(this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (e: Exception) { /* ne bloque pas le reste de l'initialisation */ }
    }

    private fun registerConnectivityCallback() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            connectivityCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (lastWifiState != true) {
                        lastWifiState = true
                        fireTriggersOfType(TriggerType.WIFI_CONNECTED)
                    }
                }
                override fun onLost(network: Network) {
                    if (lastWifiState != false) {
                        lastWifiState = false
                        fireTriggersOfType(TriggerType.WIFI_DISCONNECTED)
                    }
                }
            }
            cm.registerNetworkCallback(request, connectivityCallback!!)
        } catch (e: Exception) { /* ignoré si non disponible */ }
    }

    private fun registerShakeDetector() {
        try {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (accelerometer != null) {
                sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
            }
        } catch (e: Exception) { /* capteur absent sur certains appareils */ }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val gX = event.values[0] / 9.81f
        val gY = event.values[1] / 9.81f
        val gZ = event.values[2] / 9.81f
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)
        if (gForce > 2.7f) {
            val now = System.currentTimeMillis()
            if (now - lastShakeAt > 2000) {
                lastShakeAt = now
                fireTriggersOfType(TriggerType.SHAKE)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun fireTriggersOfType(type: TriggerType) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == type) {
                AutomationExecutionService.start(this, a.id)
            }
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "watchdog_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Surveillance BlockAuto", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BlockAuto est actif")
            .setContentText("Tes automatisations continuent de fonctionner en arrière-plan")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        startForeground(2, notif)
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, WatchdogService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
