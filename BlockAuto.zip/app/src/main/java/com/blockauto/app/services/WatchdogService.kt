package com.blockauto.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import kotlin.math.sqrt

/**
 * Petit service qui reste vivant en tâche de fond pour surveiller les événements
 * que le système n'autorise plus dans le manifeste (restrictions Android 8+) :
 * écran on/off, déverrouillage, Wi-Fi, Bluetooth, casque, mode avion, secousse.
 * C'est la pièce maîtresse qui permet à BlockAuto de fonctionner même app fermée.
 */
class WatchdogService : Service(), SensorEventListener {

    private var lastWifiState: Boolean? = null
    private var lastDarkMode: Boolean? = null
    private var lastPowerSaveMode: Boolean? = null
    private var lastShakeAt = 0L
    private var sensorManager: SensorManager? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null
    private val batteryConditionState = mutableMapOf<String, Boolean>()
    private var wasRinging = false
    private var legacyPhoneListener: PhoneStateListener? = null
    private var telephonyCallback: TelephonyCallback? = null

    // --- État des déclencheurs v3 ---
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var cellularCallback: ConnectivityManager.NetworkCallback? = null
    private var defaultNetworkCallback: ConnectivityManager.NetworkCallback? = null
    private var lastCellularState: Boolean? = null
    private var internetAvailable: Boolean? = null
    private var wasFullyCharged = false
    private var wasWirelessCharging = false
    private val batteryHotState = mutableMapOf<String, Boolean>()
    private var lastVolumeEventAt = 0L
    private var callWasAnswered = false
    private var faceDownSince = 0L
    private var isFaceDown = false
    private var proximitySensorActive = false
    private var lastProximityAt = 0L

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return
            val percent = (level * 100) / scale
            checkBatteryLevelTriggers(percent)
            checkExtraBatteryTriggers(intent, percent)
            checkMemoryTrigger()
        }
    }

    /** Batterie pleine, surchauffe et recharge sans fil : déclenchés uniquement au moment
     *  où l'état change (front montant), pas à chaque nouvelle mesure. */
    private fun checkExtraBatteryTriggers(intent: Intent, percent: Int) {
        val plugged = intent.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)
        val full = plugged != 0 && percent >= 100
        if (full && !wasFullyCharged) fireTriggersOfType(TriggerType.BATTERY_CHARGED_FULL)
        wasFullyCharged = full

        val wireless = plugged == android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS
        if (wireless && !wasWirelessCharging) fireTriggersOfType(TriggerType.CHARGING_WIRELESS)
        wasWirelessCharging = wireless

        val tempC = intent.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        for (a in AutomationRepository.getAll(this)) {
            if (!a.enabled || a.trigger?.type != TriggerType.BATTERY_TEMP_HIGH) continue
            val threshold = a.trigger?.params?.get("threshold")?.toDoubleOrNull() ?: 42.0
            val hot = tempC >= threshold
            if (hot && batteryHotState[a.id] != true) {
                AutomationExecutionService.start(this, a.id, mapOf("batterie_temp" to tempC.toString()))
            }
            batteryHotState[a.id] = hot
        }
    }

    private fun checkBatteryLevelTriggers(percent: Int) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled || a.trigger?.type != TriggerType.BATTERY_LEVEL) continue
            val target = a.trigger?.params?.get("level")?.toIntOrNull() ?: continue
            val operator = a.trigger?.params?.get("operator") ?: "above"
            val conditionNow = if (operator == "below") percent <= target else percent >= target
            val wasTrue = batteryConditionState[a.id] ?: false
            if (conditionNow && !wasTrue) {
                AutomationExecutionService.start(this, a.id)
            }
            batteryConditionState[a.id] = conditionNow
        }
    }

    /**
     * "Câble USB (données) branché/débranché" utilise l'action système
     * android.hardware.usb.action.USB_STATE, absente des constantes Intent officielles.
     */
    private val actionUsbState = "android.hardware.usb.action.USB_STATE"

    /** Diffusion non documentée mais envoyée par tous les Android récents à chaque
     *  changement de volume (touches physiques, curseur, autre appli). */
    private val actionVolumeChanged = "android.media.VOLUME_CHANGED_ACTION"

    /** Compteur journalier de déverrouillages, pour le bloc "Xᵉ déverrouillage de la journée". */
    private fun checkUnlockCount() {
        val prefs = getSharedPreferences("block_auto_unlocks", Context.MODE_PRIVATE)
        val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        val count = if (prefs.getString("day", null) == today) prefs.getInt("count", 0) + 1 else 1
        prefs.edit().putString("day", today).putInt("count", count).apply()
        for (a in AutomationRepository.getAll(this)) {
            if (!a.enabled || a.trigger?.type != TriggerType.UNLOCK_COUNT_REACHED) continue
            val target = a.trigger?.params?.get("count")?.toIntOrNull() ?: continue
            if (count == target) {
                AutomationExecutionService.start(this, a.id, mapOf("deverrouillages" to count.toString()))
            }
        }
    }

    /** Compare le mode sonnerie reçu au mode attendu par chaque automatisation
     *  (ou déclenche pour n'importe quel changement si aucun mode précis n'a été choisi). */
    private fun checkRingerModeTriggers(newMode: Int) {
        if (newMode < 0) return
        val wanted = when (newMode) {
            AudioManager.RINGER_MODE_SILENT -> "silent"
            AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
            else -> "normal"
        }
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (!a.enabled || a.trigger?.type != TriggerType.RINGER_MODE_CHANGED) continue
            val target = a.trigger?.params?.get("mode")
            if (target.isNullOrBlank() || target == wanted) {
                AutomationExecutionService.start(this, a.id)
            }
        }
    }

    /** Compare le mode sombre actuel (résolu depuis les Resources, plus fiable que l'extra de
     *  l'intent ACTION_CONFIGURATION_CHANGED qui ne détaille pas toujours le mode nuit) à l'état
     *  précédent, pour ne déclencher qu'au moment du VRAI changement (comme lastWifiState). */
    private fun checkDarkModeChange() {
        try {
            val nightModeFlags = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
            val isDark = nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES
            if (lastDarkMode != isDark) {
                lastDarkMode = isDark
                fireTriggersOfType(if (isDark) TriggerType.DARK_MODE_ON else TriggerType.DARK_MODE_OFF)
            }
        } catch (e: Exception) { /* Resources indisponibles */ }
    }

    private fun checkPowerSaveModeChange() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            val isSaving = pm.isPowerSaveMode
            if (lastPowerSaveMode != isSaving) {
                lastPowerSaveMode = isSaving
                fireTriggersOfType(if (isSaving) TriggerType.POWER_SAVE_MODE_ON else TriggerType.POWER_SAVE_MODE_OFF)
            }
        } catch (e: Exception) { /* PowerManager indisponible */ }
    }

    /** Compare le SSID du Wi-Fi qui vient de se connecter au SSID choisi par chaque automatisation. */
    private fun checkWifiSsidTriggers() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
            @Suppress("DEPRECATION")
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val ssid = wm.connectionInfo?.ssid?.trim('"') ?: return
            if (ssid.isBlank() || ssid == "<unknown ssid>") return
            val list = AutomationRepository.getAll(this)
            for (a in list) {
                if (!a.enabled || a.trigger?.type != TriggerType.WIFI_CONNECTED_SSID) continue
                val target = a.trigger?.params?.get("ssid") ?: continue
                if (target.equals(ssid, ignoreCase = true)) {
                    AutomationExecutionService.start(this, a.id)
                }
            }
        } catch (e: Exception) { /* WifiManager indisponible ou permission retirée entre-temps */ }
    }

    private val screenAndSystemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Les diffusions "collantes" (casque, dock, USB, état Wi-Fi...) sont renvoyées dès
            // l'enregistrement du receiver : ce n'est pas un vrai changement, on les ignore pour
            // ne pas lancer d'automatisations à chaque démarrage du service.
            if (isInitialStickyBroadcast) return
            val type = when (intent.action) {
                Intent.ACTION_SCREEN_ON -> TriggerType.SCREEN_ON
                Intent.ACTION_SCREEN_OFF -> TriggerType.SCREEN_OFF
                Intent.ACTION_USER_PRESENT -> {
                    checkUnlockCount()
                    TriggerType.DEVICE_UNLOCKED
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> TriggerType.BLUETOOTH_DISCONNECTED
                BluetoothAdapter.ACTION_STATE_CHANGED -> when (intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                    BluetoothAdapter.STATE_ON -> TriggerType.BLUETOOTH_TURNED_ON
                    BluetoothAdapter.STATE_OFF -> TriggerType.BLUETOOTH_TURNED_OFF
                    else -> null
                }
                WifiManager.WIFI_STATE_CHANGED_ACTION -> when (intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)) {
                    WifiManager.WIFI_STATE_ENABLED -> TriggerType.WIFI_TURNED_ON
                    WifiManager.WIFI_STATE_DISABLED -> TriggerType.WIFI_TURNED_OFF
                    else -> null
                }
                actionVolumeChanged -> {
                    // Android envoie un événement par flux audio touché : on regroupe.
                    val now = System.currentTimeMillis()
                    if (now - lastVolumeEventAt > 1500) {
                        lastVolumeEventAt = now
                        TriggerType.VOLUME_CHANGED
                    } else null
                }
                Intent.ACTION_HEADSET_PLUG -> when (intent.getIntExtra("state", 0)) {
                    1 -> TriggerType.HEADSET_CONNECTED
                    0 -> TriggerType.HEADSET_DISCONNECTED
                    else -> null
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> TriggerType.BLUETOOTH_CONNECTED
                BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
                BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                    // Beaucoup d'écouteurs / oreillettes ne remontent pas toujours un
                    // ACTION_ACL_CONNECTED exploitable (notamment via le profil A2DP pur).
                    // On se base donc en plus sur le changement d'état des profils audio,
                    // qui est le signal le plus fiable pour "écouteurs/casque connectés".
                    val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1)
                    if (state == BluetoothProfile.STATE_CONNECTED) TriggerType.BLUETOOTH_CONNECTED else null
                }
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> if (intent.getBooleanExtra("state", false)) TriggerType.AIRPLANE_MODE_ON else TriggerType.AIRPLANE_MODE_OFF
                actionUsbState -> when (intent.getBooleanExtra("connected", false)) {
                    true -> TriggerType.USB_CONNECTED
                    false -> TriggerType.USB_DISCONNECTED
                }
                Intent.ACTION_DEVICE_STORAGE_LOW -> TriggerType.STORAGE_LOW
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    checkRingerModeTriggers(intent.getIntExtra(AudioManager.EXTRA_RINGER_MODE, -1))
                    null
                }
                Intent.ACTION_CONFIGURATION_CHANGED -> {
                    checkDarkModeChange()
                    null
                }
                android.os.PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> {
                    checkPowerSaveModeChange()
                    null
                }
                Intent.ACTION_LOCALE_CHANGED -> TriggerType.LANGUAGE_CHANGED
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_DATE_CHANGED -> TriggerType.DATE_TIME_CHANGED
                Intent.ACTION_DOCK_EVENT -> {
                    val dockState = intent.getIntExtra(Intent.EXTRA_DOCK_STATE, Intent.EXTRA_DOCK_STATE_UNDOCKED)
                    if (dockState == Intent.EXTRA_DOCK_STATE_UNDOCKED) TriggerType.DOCK_DISCONNECTED else TriggerType.DOCK_CONNECTED
                }
                else -> null
            } ?: return
            fireTriggersOfType(type)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        // Chaque étape est indépendante : si l'une échoue sur un appareil particulier,
        // les autres déclencheurs continuent quand même de fonctionner.
        try { registerRuntimeReceivers() } catch (e: Exception) {}
        try { registerConnectivityCallback() } catch (e: Exception) {}
        try { registerShakeDetector() } catch (e: Exception) {}
        try { registerCallStateListener() } catch (e: Exception) {}
        try { registerClipboardListener() } catch (e: Exception) {}
        try { registerExtraNetworkCallbacks() } catch (e: Exception) {}
        try { refreshProximitySensor() } catch (e: Exception) {}
    }

    /** Données mobiles + disponibilité d'Internet (tous réseaux confondus). */
    private fun registerExtraNetworkCallbacks() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cellular = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (lastCellularState != true) {
                    lastCellularState = true
                    fireTriggersOfType(TriggerType.MOBILE_DATA_CONNECTED)
                }
            }
            override fun onLost(network: Network) {
                if (lastCellularState != false) {
                    lastCellularState = false
                    fireTriggersOfType(TriggerType.MOBILE_DATA_DISCONNECTED)
                }
            }
        }
        cellularCallback = cellular
        cm.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).build(), cellular
        )

        internetAvailable = cm.activeNetwork != null
        val default = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                mainHandler.post {
                    if (internetAvailable == false) fireTriggersOfType(TriggerType.INTERNET_RESTORED)
                    internetAvailable = true
                }
            }
            override fun onLost(network: Network) {
                // Lors d'un passage Wi-Fi → 4G, le réseau par défaut est "perdu" une fraction de
                // seconde : on attend un peu avant de conclure à une vraie coupure.
                mainHandler.postDelayed({
                    if (cm.activeNetwork == null && internetAvailable != false) {
                        internetAvailable = false
                        fireTriggersOfType(TriggerType.INTERNET_LOST)
                    }
                }, 4000)
            }
        }
        defaultNetworkCallback = default
        cm.registerDefaultNetworkCallback(default)
    }

    /** Le capteur de proximité n'est écouté que si une automatisation active l'utilise,
     *  pour ne pas consommer de batterie inutilement. */
    private fun refreshProximitySensor() {
        val needed = AutomationRepository.getAll(this).any { it.enabled && it.trigger?.type == TriggerType.PROXIMITY_NEAR }
        val sm = sensorManager ?: (getSystemService(Context.SENSOR_SERVICE) as SensorManager).also { sensorManager = it }
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        if (needed && !proximitySensorActive) {
            sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            proximitySensorActive = true
        } else if (!needed && proximitySensorActive) {
            sm.unregisterListener(this, sensor)
            proximitySensorActive = false
        }
    }

    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    /**
     * Depuis Android 10, un service en arrière-plan ne reçoit en général le contenu du
     * presse-papiers que si l'app est l'IME actif ou a le focus — mais le *callback* de
     * changement se déclenche quand même sur la plupart des appareils, donc on s'en sert
     * uniquement comme signal ("le presse-papiers vient de changer"), sans dépendre de
     * pouvoir lire le contenu à cet instant précis.
     */
    private fun registerClipboardListener() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val listener = ClipboardManager.OnPrimaryClipChangedListener {
            fireTriggersOfType(TriggerType.CLIPBOARD_CHANGED)
        }
        clipboardListener = listener
        cm.addPrimaryClipChangedListener(listener)
    }

    /** État de "mémoire faible" mémorisé pour ne déclencher qu'au moment où l'on repasse
     *  sous le seuil, pas à chaque vérification pendant qu'on y reste déjà. */
    private var memoryLowState = false

    /** Vérifié en même temps que le niveau de batterie (déclenché par ACTION_BATTERY_CHANGED,
     *  qui remonte régulièrement) : pas besoin d'une boucle de polling dédiée. */
    private fun checkMemoryTrigger() {
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val info = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val isLow = info.lowMemory || (info.availMem.toDouble() / info.totalMem.toDouble()) < 0.1
            if (isLow && !memoryLowState) {
                fireTriggersOfType(TriggerType.MEMORY_LOW)
            }
            memoryLowState = isLow
        } catch (e: Exception) { /* ActivityManager indisponible */ }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try { refreshProximitySensor() } catch (e: Exception) {}
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenAndSystemReceiver) } catch (e: Exception) {}
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {}
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectivityCallback?.let { cm.unregisterNetworkCallback(it) }
            cellularCallback?.let { cm.unregisterNetworkCallback(it) }
            defaultNetworkCallback?.let { cm.unregisterNetworkCallback(it) }
        } catch (e: Exception) {}
        sensorManager?.unregisterListener(this)
        mainHandler.removeCallbacksAndMessages(null)
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                telephonyCallback?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacyPhoneListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (e: Exception) {}
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboardListener?.let { cm.removePrimaryClipChangedListener(it) }
        } catch (e: Exception) {}
    }

    /**
     * Détecte les appels entrants / la fin d'un appel pour déclencher les blocs
     * "Appel entrant" et "Appel terminé", sans nécessiter le service d'accessibilité.
     */
    private fun registerCallStateListener() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val onStateChanged: (Int) -> Unit = { state ->
            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> {
                    wasRinging = true
                    callWasAnswered = false
                    fireTriggersOfType(TriggerType.CALL_INCOMING)
                }
                TelephonyManager.CALL_STATE_OFFHOOK -> {
                    if (wasRinging) callWasAnswered = true
                }
                TelephonyManager.CALL_STATE_IDLE -> {
                    if (wasRinging) {
                        wasRinging = false
                        // Sonnerie puis retour au repos sans décrocher = appel manqué.
                        if (!callWasAnswered) fireTriggersOfType(TriggerType.MISSED_CALL)
                        callWasAnswered = false
                        fireTriggersOfType(TriggerType.CALL_ENDED)
                    }
                }
                else -> {}
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = onStateChanged(state)
            }
            telephonyCallback = callback
            tm.registerTelephonyCallback(mainExecutor, callback)
        } else {
            @Suppress("DEPRECATION")
            val listener = object : PhoneStateListener() {
                @Suppress("DEPRECATION")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) = onStateChanged(state)
            }
            legacyPhoneListener = listener
            @Suppress("DEPRECATION")
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    private fun registerRuntimeReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
            addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
            addAction(actionUsbState)
            addAction(Intent.ACTION_DEVICE_STORAGE_LOW)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_CONFIGURATION_CHANGED)
            addAction(android.os.PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_LOCALE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_DOCK_EVENT)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(actionVolumeChanged)
        }
        // Valeurs de référence au démarrage du service, pour que checkDarkModeChange /
        // checkPowerSaveModeChange ne déclenchent pas à tort dès le premier événement reçu.
        try {
            val nightModeFlags = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
            lastDarkMode = nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            lastPowerSaveMode = pm.isPowerSaveMode
        } catch (e: Exception) { /* état initial non bloquant */ }
        try {
            // Sur Android 13+ (API 33), il faut obligatoirement préciser RECEIVER_EXPORTED
            // ou RECEIVER_NOT_EXPORTED, sinon Android lève une SecurityException qui
            // faisait planter tout le service de veille au démarrage (donc tous les
            // déclencheurs qui en dépendent ne fonctionnaient plus du tout).
            ContextCompat.registerReceiver(this, screenAndSystemReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (e: Exception) { /* ne bloque pas le reste de l'initialisation */ }
        try {
            ContextCompat.registerReceiver(this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (e: Exception) { /* ne bloque pas le reste de l'initialisation */ }
    }

    private fun registerConnectivityCallback() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            connectivityCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (lastWifiState != true) {
                        lastWifiState = true
                        fireTriggersOfType(TriggerType.WIFI_CONNECTED)
                    }
                    checkWifiSsidTriggers()
                }
                override fun onLost(network: Network) {
                    if (lastWifiState != false) {
                        lastWifiState = false
                        fireTriggersOfType(TriggerType.WIFI_DISCONNECTED)
                    }
                }
            }
            cm.registerNetworkCallback(request, connectivityCallback!!)
        } catch (e: Exception) { /* ignoré si non disponible */ }
    }

    private fun registerShakeDetector() {
        try {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (accelerometer != null) {
                sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
            }
        } catch (e: Exception) { /* capteur absent sur certains appareils */ }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        if (event.sensor.type == Sensor.TYPE_PROXIMITY) {
            val near = event.values[0] < event.sensor.maximumRange.coerceAtMost(5f)
            val now = System.currentTimeMillis()
            if (near && now - lastProximityAt > 1500) {
                lastProximityAt = now
                fireTriggersOfType(TriggerType.PROXIMITY_NEAR)
            }
            return
        }
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        checkOrientation(event.values[2])
        val gX = event.values[0] / 9.81f
        val gY = event.values[1] / 9.81f
        val gZ = event.values[2] / 9.81f
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)
        if (gForce > 2.7f) {
            val now = System.currentTimeMillis()
            if (now - lastShakeAt > 2000) {
                lastShakeAt = now
                fireTriggersOfType(TriggerType.SHAKE)
            }
        }
    }

    /** Face contre table : l'axe Z pointe vers le bas (≈ −9,8 m/s²) pendant plus d'une seconde. */
    private fun checkOrientation(z: Float) {
        val now = System.currentTimeMillis()
        if (z < -8.5f) {
            if (faceDownSince == 0L) faceDownSince = now
            if (!isFaceDown && now - faceDownSince > 1000) {
                isFaceDown = true
                fireTriggersOfType(TriggerType.PHONE_FACE_DOWN)
            }
        } else {
            faceDownSince = 0L
            if (isFaceDown && z > 7.5f) {
                isFaceDown = false
                fireTriggersOfType(TriggerType.PHONE_FACE_UP)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun fireTriggersOfType(type: TriggerType) {
        val list = AutomationRepository.getAll(this)
        for (a in list) {
            if (a.enabled && a.trigger?.type == type) {
                AutomationExecutionService.start(this, a.id)
            }
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "watchdog_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Surveillance BlockAuto", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BlockAuto est actif")
            .setContentText("Tes automatisations continuent de fonctionner en arrière-plan")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        startForeground(2, notif)
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, WatchdogService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
