package com.blockauto.app.model

/**
 * Catalogue centralisé : pour chaque bloc déclencheur/action, la ou les
 * "ressources" système qu'il consomme (permission runtime, service spécial
 * comme l'accessibilité, ou juste Internet). Ça sert à afficher sur chaque
 * automatisation, dans la liste principale, un résumé de ce qu'elle "prend"
 * — pratique pour repérer d'un coup d'œil celles qui touchent aux SMS, à la
 * position, au micro, etc. sans devoir ouvrir chaque bloc un par un.
 *
 * Centraliser cette table ici (plutôt que de la deviner ailleurs à partir du
 * code d'exécution) évite qu'elle se désynchronise quand un nouveau bloc est
 * ajouté : ajouter un bloc sans l'ajouter ici affichera juste "Aucun accès
 * particulier", ce qui est un signal visible en revue plutôt qu'un oubli
 * silencieux.
 */
private fun TriggerType.requirement(): String? = when (this) {
    TriggerType.APP_OPENED, TriggerType.APP_CLOSED -> "Service d'accessibilité"
    TriggerType.NOTIFICATION_RECEIVED -> "Accès aux notifications"
    TriggerType.SMS_RECEIVED -> "SMS"
    TriggerType.CALL_INCOMING, TriggerType.CALL_ENDED -> "État du téléphone"
    TriggerType.BLUETOOTH_CONNECTED, TriggerType.HEADSET_CONNECTED, TriggerType.HEADSET_DISCONNECTED -> "Bluetooth"
    TriggerType.WIFI_CONNECTED_SSID -> "Position (nom du Wi-Fi)"
    TriggerType.UI_TEXT_APPEARS -> "Service d'accessibilité"
    else -> null
}

private fun ActionType.requirement(): String? = when (this) {
    ActionType.SEND_SMS, ActionType.SEND_MULTIPLE_SMS -> "SMS"
    ActionType.MAKE_CALL -> "Appels"
    ActionType.CALL_CONTACT -> "Contacts + Appels"
    ActionType.ADD_CALENDAR_EVENT -> "Calendrier"
    ActionType.RECORD_AUDIO_CLIP -> "Micro"
    ActionType.GET_LOCATION -> "Position GPS"
    ActionType.TOGGLE_FLASHLIGHT -> "Caméra (flash)"
    ActionType.TOGGLE_BLUETOOTH -> "Bluetooth"
    ActionType.SET_BRIGHTNESS, ActionType.TOGGLE_AUTO_ROTATE -> "Modifier les réglages système"
    ActionType.TOGGLE_DND, ActionType.OPEN_DND_SETTINGS -> "Accès « Ne pas déranger »"
    ActionType.TAKE_SCREENSHOT, ActionType.LOCK_SCREEN, ActionType.GO_HOME, ActionType.OPEN_RECENT_APPS -> "Service d'accessibilité"
    ActionType.UI_CLICK_TEXT, ActionType.UI_CLICK_DESCRIPTION, ActionType.UI_LONG_CLICK_TEXT,
    ActionType.UI_INPUT_TEXT, ActionType.UI_SCROLL_DOWN, ActionType.UI_SCROLL_UP,
    ActionType.UI_SWIPE, ActionType.UI_PRESS_BACK, ActionType.UI_WAIT_FOR_TEXT,
    ActionType.UI_OPEN_APP_AND_CLICK -> "Service d'accessibilité"
    ActionType.HTTP_REQUEST, ActionType.DISCORD_WEBHOOK, ActionType.TELEGRAM_MESSAGE,
    ActionType.SLACK_WEBHOOK, ActionType.IFTTT_WEBHOOK, ActionType.HOME_ASSISTANT_WEBHOOK -> "Internet"
    ActionType.OPEN_CAMERA -> "Caméra"
    ActionType.SET_SCREEN_TIMEOUT -> "Modifier les réglages système"
    else -> null
}

/** Liste triée, sans doublons, de tout ce que cette automatisation consomme comme accès. */
fun Automation.requiredAccess(): List<String> {
    val set = linkedSetOf<String>()
    trigger?.type?.requirement()?.let { set.add(it) }
    for (action in actions) action.type.requirement()?.let { set.add(it) }
    return set.sorted()
}
