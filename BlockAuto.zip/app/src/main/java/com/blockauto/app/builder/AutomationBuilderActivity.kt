package com.blockauto.app.builder

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.databinding.ActivityAutomationBuilderBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/** Libellé affiché quand on ajoute un bloc "Si..." : rappelle qu'on peut brancher
 *  un "Sinon" et qu'il faut refermer avec "Fin de condition" pour un vrai Si/Sinon. */
private const val IF_HINT =
    "Ajoute ensuite les blocs à exécuter si vrai. Tu peux insérer « Sinon » puis " +
        "terminer avec « Fin de condition » pour créer un vrai Si / Sinon."

/**
 * Écran "atelier de blocs" : on choisit un bloc déclencheur, puis on empile
 * les blocs actions / logique dans l'ordre voulu, exactement comme des rouages
 * qu'on assemble les uns après les autres pour fabriquer un scénario complet.
 */
class AutomationBuilderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAutomationBuilderBinding
    private lateinit var automation: Automation
    private lateinit var actionAdapter: ActionBlockAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAutomationBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra("automation_id")
        automation = if (id != null) AutomationRepository.get(this, id) ?: Automation() else Automation()

        binding.editName.setText(automation.name)

        binding.recyclerActions.layoutManager = LinearLayoutManager(this)
        binding.recyclerActions.addItemDecoration(ChainConnectorDecoration(this))
        // Le bloc déclencheur est la "tête" de la chaîne (comme un bloc chapeau
        // Scratch/Blockly) : pas d'encoche en haut puisque rien ne vient avant lui,
        // mais une languette en bas qui annonce visuellement la suite de la chaîne.
        binding.triggerBlock.hasTopNotch = false
        binding.triggerBlock.hasBottomTab = true
        binding.triggerBlock.setColors(
            accent = androidx.core.content.ContextCompat.getColor(this, com.blockauto.app.R.color.accent_teal),
            fill = androidx.core.content.ContextCompat.getColor(this, com.blockauto.app.R.color.bg_surface_elevated)
        )
        actionAdapter = ActionBlockAdapter { position ->
            automation.actions.removeAt(position)
            actionAdapter.submitList(automation.actions)
        }
        binding.recyclerActions.adapter = actionAdapter
        actionAdapter.submitList(automation.actions)

        refreshTriggerLabel()

        binding.btnPickTrigger.setOnClickListener { showTriggerPicker() }
        binding.btnAddAction.setOnClickListener { showActionPicker() }

        binding.btnSave.setOnClickListener {
            automation.name = binding.editName.text.toString().ifBlank { "Automatisation" }
            if (automation.trigger == null) {
                Toast.makeText(this, "Choisis un bloc déclencheur", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (automation.actions.isEmpty()) {
                Toast.makeText(this, "Ajoute au moins un bloc action", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AutomationRepository.save(this, automation)
            TriggerScheduler.schedule(this, automation)
            finish()
        }

        binding.btnDelete.setOnClickListener {
            AutomationRepository.delete(this, automation.id)
            TriggerScheduler.cancel(this, automation.id)
            finish()
        }
        binding.btnDelete.visibility = if (id != null) View.VISIBLE else View.GONE
    }

    private fun refreshTriggerLabel() {
        val t = automation.trigger
        val detail = t?.params?.entries?.joinToString(", ") { "${it.key}=${it.value}" }
        binding.textCurrentTrigger.text = when {
            t == null -> "Aucun déclencheur choisi"
            detail.isNullOrBlank() -> t.type.label
            else -> "${t.type.label} ($detail)"
        }
    }

    // ---- Choix du bloc déclencheur ----

    private fun showTriggerPicker() {
        val types = TriggerType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc déclencheur")
            .setItems(labels) { _, which -> configureTrigger(types[which]) }
            .show()
    }

    private fun configureTrigger(type: TriggerType) {
        when (type) {
            TriggerType.TIME -> {
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    automation.trigger = TriggerBlock(
                        type, mutableMapOf("hour" to hour.toString(), "minute" to minute.toString())
                    )
                    refreshTriggerLabel()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            TriggerType.APP_OPENED -> {
                showAppPicker { pkg ->
                    automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                    refreshTriggerLabel()
                }
            }
            // BUG CORRIGÉ : le moteur (NotifListenerService) sait déclencher sur la
            // notification de "n'importe quelle application" quand le paramètre "package"
            // est vide/absent (voir README), mais cet écran forçait jusqu'ici à toujours
            // choisir une app précise via showAppPicker : ce mode "n'importe laquelle" était
            // donc impossible à créer. On propose maintenant explicitement le choix.
            TriggerType.NOTIFICATION_RECEIVED -> {
                AlertDialog.Builder(this)
                    .setTitle("De quelle application ?")
                    .setItems(arrayOf("N'importe quelle application", "Choisir une application précise")) { _, which ->
                        if (which == 0) {
                            automation.trigger = TriggerBlock(type, mutableMapOf())
                            refreshTriggerLabel()
                        } else {
                            showAppPicker { pkg ->
                                automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                                refreshTriggerLabel()
                            }
                        }
                    }.show()
            }
            TriggerType.INTERVAL -> showNumberInputs(
                listOf(NumericField("Toutes les combien de minutes ?", "minutes", 30, 1, 1440))
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.BATTERY_LEVEL -> {
                AlertDialog.Builder(this)
                    .setTitle("Batterie au-dessus ou en dessous ?")
                    .setItems(arrayOf("Au-dessus de X%", "En dessous de X%")) { _, which ->
                        val operator = if (which == 0) "above" else "below"
                        showNumberInputs(listOf(NumericField("Pourcentage", "level", 50, 0, 100))) { map ->
                            map["operator"] = operator
                            automation.trigger = TriggerBlock(type, map)
                            refreshTriggerLabel()
                        }
                    }.show()
            }
            TriggerType.SMS_RECEIVED -> showTextInputs(
                listOf("Numéro de l'expéditeur (laisser vide = n'importe qui)" to "sender")
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.WIFI_CONNECTED_SSID -> showTextInputs(
                listOf("Nom du réseau Wi-Fi (SSID)" to "ssid")
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.RINGER_MODE_CHANGED -> {
                AlertDialog.Builder(this)
                    .setTitle("Vers quel mode sonnerie ?")
                    .setItems(arrayOf("N'importe lequel", "Normal", "Vibreur", "Silencieux")) { _, which ->
                        val mode = when (which) { 1 -> "normal"; 2 -> "vibrate"; 3 -> "silent"; else -> "" }
                        automation.trigger = TriggerBlock(type, mutableMapOf("mode" to mode))
                        refreshTriggerLabel()
                    }.show()
            }
            else -> {
                automation.trigger = TriggerBlock(type)
                refreshTriggerLabel()
            }
        }
    }

    // ---- Choix des blocs actions / logique ----

    private fun showActionPicker() {
        val types = ActionType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc action ou logique")
            .setItems(labels) { _, which -> configureAction(types[which]) }
            .show()
    }

    private fun configureAction(type: ActionType) {
        when (type) {
            ActionType.OPEN_APP -> showAppPicker { pkg ->
                addAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.SEND_NOTIFICATION -> showTextInputs(listOf("Titre" to "title", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SHOW_TOAST -> showTextInputs(listOf("Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.VIBRATE -> showNumberInputs(
                listOf(NumericField("Durée en millisecondes", "duration_ms", 500, 100, 20_000))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_RING_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_ALARM_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_BRIGHTNESS -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 128, 0, 255))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TOGGLE_FLASHLIGHT -> onOffDialog("Lampe torche") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_WIFI -> onOffDialog("Wi-Fi") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_BLUETOOTH -> onOffDialog("Bluetooth") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.SET_RINGER_MODE -> {
                AlertDialog.Builder(this)
                    .setTitle("Mode sonnerie")
                    .setItems(arrayOf("Normal", "Vibreur", "Silencieux")) { _, which ->
                        val mode = when (which) { 0 -> "normal"; 1 -> "vibrate"; else -> "silent" }
                        addAction(ActionBlock(type, mutableMapOf("mode" to mode)))
                    }.show()
            }
            ActionType.OPEN_URL -> showTextInputs(listOf("URL (https://...)" to "url")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_SMS -> showTextInputs(listOf("Numéro" to "number", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.MAKE_CALL -> showTextInputs(listOf("Numéro à appeler" to "number")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_EMAIL -> showTextInputs(
                listOf("Destinataire" to "to", "Sujet" to "subject", "Message" to "body")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.COPY_CLIPBOARD -> showTextInputs(listOf("Texte à copier" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CREATE_ALARM -> showNumberInputs(
                listOf(NumericField("Heure", "hour", 7, 0, 23), NumericField("Minute", "minute", 0, 0, 59))
            ) { numMap ->
                showTextInputs(listOf("Libellé" to "label")) { labelMap ->
                    addAction(ActionBlock(type, (numMap + labelMap).toMutableMap()))
                }
            }
            ActionType.LOG_EVENT -> showTextInputs(listOf("Texte à enregistrer" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.WAIT -> showNumberInputs(
                listOf(NumericField("Secondes", "seconds", 1, 1, 300))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.CALL_CONTACT -> showTextInputs(listOf("Nom du contact" to "name")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.ADD_CALENDAR_EVENT -> showTextInputs(listOf("Titre de l'événement" to "title")) { titleMap ->
                showNumberInputs(
                    listOf(
                        NumericField("Dans combien de minutes ?", "minutes_from_now", 0, 0, 10_080),
                        NumericField("Durée (minutes)", "duration_minutes", 60, 5, 1440)
                    )
                ) { numMap ->
                    addAction(ActionBlock(type, (titleMap + numMap).toMutableMap()))
                }
            }
            ActionType.SHARE_TEXT -> showTextInputs(listOf("Texte à partager" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.TOGGLE_AUTO_ROTATE -> onOffDialog("Rotation automatique") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_DND -> onOffDialog("Ne pas déranger") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.RECORD_AUDIO_CLIP -> showNumberInputs(
                listOf(NumericField("Durée en secondes", "seconds", 5, 1, 120))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SPEAK_TEXT -> showTextInputs(listOf("Texte à lire à voix haute" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CREATE_TIMER -> showNumberInputs(
                listOf(NumericField("Durée en secondes", "seconds", 60, 1, 86_400))
            ) { numMap ->
                showTextInputs(listOf("Libellé" to "label")) { labelMap ->
                    addAction(ActionBlock(type, (numMap + labelMap).toMutableMap()))
                }
            }
            ActionType.SET_SCREEN_TIMEOUT -> showNumberInputs(
                listOf(NumericField("Minutes avant mise en veille", "minutes", 2, 1, 60))
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs connecteurs ---
            ActionType.HTTP_REQUEST -> {
                AlertDialog.Builder(this)
                    .setTitle("Méthode HTTP")
                    .setItems(arrayOf("GET", "POST")) { _, which ->
                        val method = if (which == 0) "GET" else "POST"
                        showTextInputs(listOf("URL" to "url", "Corps de la requête (si POST)" to "body")) { map ->
                            map["method"] = method
                            addAction(ActionBlock(type, map))
                        }
                    }.show()
            }
            ActionType.DISCORD_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Discord" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TELEGRAM_MESSAGE -> showTextInputs(
                listOf("Token du bot Telegram" to "bot_token", "Chat ID" to "chat_id", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SLACK_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Slack" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.IFTTT_WEBHOOK -> showTextInputs(
                listOf("Nom de l'événement" to "event_name", "Clé Webhooks IFTTT" to "key", "Valeur (value1)" to "value1")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.HOME_ASSISTANT_WEBHOOK -> showTextInputs(
                listOf("URL de base (ex: http://192.168.1.10:8123)" to "base_url", "ID du webhook" to "webhook_id", "Payload JSON (optionnel)" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs logiques ---
            ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW ->
                showNumberInputs(listOf(NumericField("Pourcentage", "level", 50, 0, 100))) {
                    addConditionAction(ActionBlock(type, it))
                }
            ActionType.IF_DAY_OF_WEEK -> {
                val dayCodes = arrayOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
                val dayLabels = arrayOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")
                val checked = BooleanArray(7)
                AlertDialog.Builder(this)
                    .setTitle("Quels jours ?")
                    .setMultiChoiceItems(dayLabels, checked) { _, which, isChecked -> checked[which] = isChecked }
                    .setPositiveButton("OK") { _, _ ->
                        val selected = dayCodes.filterIndexed { i, _ -> checked[i] }.joinToString(",")
                        addConditionAction(ActionBlock(type, mutableMapOf("days" to selected)))
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            ActionType.IF_TIME_BETWEEN -> showNumberInputs(
                listOf(
                    NumericField("Heure de début", "start_hour", 22, 0, 23),
                    NumericField("Minute de début", "start_minute", 0, 0, 59),
                    NumericField("Heure de fin", "end_hour", 7, 0, 23),
                    NumericField("Minute de fin", "end_minute", 0, 0, 59)
                )
            ) { addConditionAction(ActionBlock(type, it)) }
            ActionType.IF_WIFI_CONNECTED -> addConditionAction(ActionBlock(type))
            ActionType.ELSE_BRANCH -> {
                addAction(ActionBlock(type))
                Toast.makeText(
                    this,
                    "Ajoute maintenant les blocs à exécuter si la condition est fausse, puis termine avec « Fin de condition »",
                    Toast.LENGTH_LONG
                ).show()
            }
            ActionType.RANDOM_CHANCE -> showNumberInputs(
                listOf(NumericField("Pourcentage de chance", "percent", 50, 0, 100))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.REPEAT_START -> showNumberInputs(
                listOf(NumericField("Nombre de répétitions", "count", 2, 1, 100))
            ) {
                addAction(ActionBlock(type, it))
                Toast.makeText(
                    this,
                    "Ajoute maintenant les blocs à répéter, puis termine avec le bloc « Fin de répétition »",
                    Toast.LENGTH_LONG
                ).show()
            }
            // --- Chaînage vers une autre automatisation ---
            ActionType.RUN_AUTOMATION -> showAutomationPicker { targetId, targetName ->
                addAction(
                    ActionBlock(
                        type,
                        mutableMapOf("automation_id" to targetId, "automation_name" to targetName)
                    )
                )
            }
            else -> addAction(ActionBlock(type))
        }
    }

    /** Ajoute un bloc "Si..." et rappelle qu'on peut le refermer en vrai Si / Sinon. */
    private fun addConditionAction(block: ActionBlock) {
        addAction(block)
        Toast.makeText(this, IF_HINT, Toast.LENGTH_LONG).show()
    }

    private fun addAction(block: ActionBlock) {
        automation.actions.add(block)
        actionAdapter.submitList(automation.actions)
    }

    // ---- Utilitaires de saisie ----

    /** Description d'un champ numérique : clé du paramètre, valeur par défaut et bornes valides. */
    private data class NumericField(val label: String, val key: String, val default: Long, val min: Long, val max: Long)

    /**
     * Variante numérique de [showTextInputs] : clavier numérique, valeur par défaut pré-remplie,
     * et surtout un retour visible si ce qui est tapé n'est pas exploitable.
     *
     * ARCHITECTURE : avant ce correctif, tous les champs "durée"/"pourcentage"/"niveau" passaient
     * par [showTextInputs] avec un clavier texte libre, et une entrée invalide (lettre tapée par
     * erreur, champ laissé vide, espace collé, etc.) retombait *silencieusement* sur une valeur
     * par défaut dans AutomationExecutor — donnant l'impression que le bloc "ne fonctionne pas"
     * alors qu'il s'exécute très bien, juste pas avec la durée demandée. C'est exactement ce qui
     * rendait "Faire vibrer" pendant un temps précis peu fiable. Cette fonction centralise la
     * validation au moment de la saisie : clavier numérique, et un Toast explicite si la valeur
     * est hors bornes ou illisible, plutôt qu'un silence qui masque le problème.
     */
    private fun showNumberInputs(fields: List<NumericField>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { field ->
            val edit = EditText(this)
            edit.hint = "${field.label} (${field.min}-${field.max})"
            edit.setText(field.default.toString())
            edit.inputType = InputType.TYPE_CLASS_NUMBER
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                var hadInvalid = false
                fields.forEachIndexed { index, field ->
                    val typed = editTexts[index].text.toString().trim().toLongOrNull()
                    val value = if (typed == null) {
                        hadInvalid = true
                        field.default
                    } else {
                        typed.coerceIn(field.min, field.max)
                    }
                    map[field.key] = value.toString()
                }
                if (hadInvalid) {
                    Toast.makeText(this, "Valeur invalide ignorée, réglage par défaut utilisé", Toast.LENGTH_LONG).show()
                }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun onOffDialog(title: String, onPicked: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("Activer", "Désactiver")) { _, which ->
                onPicked(if (which == 0) "on" else "off")
            }.show()
    }

    private fun showTextInputs(fields: List<Pair<String, String>>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { (label, _) ->
            val edit = EditText(this)
            edit.hint = label
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                fields.forEachIndexed { index, (_, key) -> map[key] = editTexts[index].text.toString() }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /** Liste toutes les autres automatisations existantes pour construire une chaîne
     *  (l'automatisation en cours d'édition est exclue pour éviter une boucle évidente
     *  sur elle-même ; les boucles indirectes restent possibles mais sont limitées par
     *  la profondeur maximale gérée dans AutomationExecutor). */
    private fun showAutomationPicker(onPicked: (id: String, name: String) -> Unit) {
        val others = AutomationRepository.getAll(this).filter { it.id != automation.id }
        if (others.isEmpty()) {
            Toast.makeText(this, "Crée d'abord une autre automatisation à chaîner", Toast.LENGTH_LONG).show()
            return
        }
        val labels = others.map { it.name.ifBlank { "Automatisation sans nom" } }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Chaîner vers quelle automatisation ?")
            .setItems(labels) { _, which -> onPicked(others[which].id, others[which].name) }
            .show()
    }

    private fun showAppPicker(onPicked: (String) -> Unit) {
        val pm = packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir une application")
            .setItems(labels) { _, which -> onPicked(apps[which].activityInfo.packageName) }
            .show()
    }
}
