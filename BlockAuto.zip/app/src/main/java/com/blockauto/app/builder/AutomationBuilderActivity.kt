package com.blockauto.app.builder

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.databinding.ActivityAutomationBuilderBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionCategory
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerCategory
import com.blockauto.app.model.TriggerType
import com.blockauto.app.model.color
import com.blockauto.app.model.icon
import com.blockauto.app.model.paletteCategory
import com.blockauto.app.nfc.NfcHelper
import com.blockauto.app.storage.AutomationRepository
import com.blockauto.app.ui.BadgeStyle
import java.util.Calendar

/** Libellé affiché quand on ajoute un bloc "Si..." : rappelle qu'on peut brancher
 *  un "Sinon" et qu'il faut refermer avec "Fin de condition" pour un vrai Si/Sinon. */
private const val IF_HINT =
    "Ajoute ensuite les blocs à exécuter si vrai. Tu peux insérer « Sinon » puis " +
        "terminer avec « Fin de condition » pour créer un vrai Si / Sinon."

/**
 * Écran "atelier de blocs" : on choisit un bloc déclencheur, puis on empile
 * les blocs actions / logique dans l'ordre voulu, exactement comme des rouages
 * qu'on assemble les uns après les autres pour fabriquer un scénario complet.
 */
class AutomationBuilderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAutomationBuilderBinding
    private lateinit var automation: Automation
    private lateinit var actionAdapter: ActionBlockAdapter

    /** Vrai pendant qu'on attend qu'un tag NFC soit approché pour l'apprendre comme
     *  déclencheur (voir [startNfcLearnMode]). */
    private var awaitingNfcTrigger = false
    private var nfcLearnDialog: android.app.AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAutomationBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra("automation_id")
        automation = if (id != null) AutomationRepository.get(this, id) ?: Automation() else Automation()

        binding.editName.setText(automation.name)

        binding.recyclerActions.layoutManager = LinearLayoutManager(this)
        binding.recyclerActions.addItemDecoration(ChainConnectorDecoration(this))
        // Le bloc déclencheur est la "tête" de la chaîne (comme un bloc chapeau
        // Scratch/Blockly) : pas d'encoche en haut puisque rien ne vient avant lui,
        // mais une languette en bas qui annonce visuellement la suite de la chaîne.
        binding.triggerBlock.hasTopNotch = false
        binding.triggerBlock.hasBottomTab = true
        actionAdapter = ActionBlockAdapter { position ->
            automation.actions.removeAt(position)
            actionAdapter.submitList(automation.actions)
            refreshMindMap()
        }
        binding.recyclerActions.adapter = actionAdapter
        actionAdapter.submitList(automation.actions)

        setupModeTabs()
        refreshTriggerLabel()

        binding.btnPickTrigger.setOnClickListener { showTriggerPicker() }
        binding.btnAddAction.setOnClickListener { showActionPicker() }

        binding.btnSave.setOnClickListener {
            automation.name = binding.editName.text.toString().ifBlank { "Automatisation" }
            if (automation.trigger == null) {
                Toast.makeText(this, "Choisis un bloc déclencheur", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (automation.actions.isEmpty()) {
                Toast.makeText(this, "Ajoute au moins un bloc action", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AutomationRepository.save(this, automation)
            TriggerScheduler.schedule(this, automation)
            finish()
        }

        binding.btnDelete.setOnClickListener {
            AutomationRepository.delete(this, automation.id)
            TriggerScheduler.cancel(this, automation.id)
            finish()
        }
        binding.btnDelete.visibility = if (id != null) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        NfcHelper.enableForegroundDispatch(this)
    }

    override fun onPause() {
        super.onPause()
        NfcHelper.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (!awaitingNfcTrigger) return
        val tag = NfcHelper.extractTag(intent) ?: return
        awaitingNfcTrigger = false
        nfcLearnDialog?.dismiss()
        val uid = NfcHelper.tagUid(tag)
        automation.trigger = TriggerBlock(TriggerType.NFC_TAG_SCANNED, mutableMapOf("tag_uid" to uid))
        refreshTriggerLabel()
        Toast.makeText(this, getString(com.blockauto.app.R.string.nfc_tag_learned), Toast.LENGTH_LONG).show()
    }

    /** Attend le prochain tag NFC approché pour l'enregistrer comme déclencheur : son
     *  identifiant matériel (voir [NfcHelper.tagUid]) est mémorisé dans le trigger, et
     *  [MainActivity] reconnaîtra ce même tag plus tard pour lancer l'automatisation. */
    private fun startNfcLearnMode() {
        if (!NfcHelper.isAvailable(this)) {
            Toast.makeText(this, getString(com.blockauto.app.R.string.nfc_not_available), Toast.LENGTH_LONG).show()
            return
        }
        awaitingNfcTrigger = true
        nfcLearnDialog = AlertDialog.Builder(this)
            .setTitle(getString(com.blockauto.app.R.string.nfc_waiting_title))
            .setMessage(getString(com.blockauto.app.R.string.nfc_learn_waiting_message))
            .setNegativeButton(android.R.string.cancel) { _, _ -> awaitingNfcTrigger = false }
            .show()
    }

    private fun refreshTriggerLabel() {
        val t = automation.trigger
        val detail = t?.params?.entries?.joinToString(", ") { "${it.key}=${it.value}" }
        binding.textCurrentTrigger.text = when {
            t == null -> "Aucun déclencheur choisi"
            detail.isNullOrBlank() -> t.type.label
            else -> "${t.type.label} ($detail)"
        }

        // Le bloc "chapeau" du déclencheur prend la couleur de sa catégorie
        // (façon Scratch) dès qu'un déclencheur est choisi, sinon une teinte neutre.
        val color = t?.type?.paletteCategory()?.color()
            ?: androidx.core.content.ContextCompat.getColor(this, com.blockauto.app.R.color.bg_stroke)
        binding.triggerBlock.setColors(
            accent = color,
            fill = androidx.core.content.ContextCompat.getColor(this, com.blockauto.app.R.color.bg_surface_elevated)
        )
        binding.badgeTriggerBuilderIcon.text = t?.type?.icon() ?: "❓"
        BadgeStyle.applyLogo(binding.badgeTriggerBuilderIcon, color)

        refreshMindMap()
    }

    // ---- Mode d'affichage : chaîne de blocs empilés VS carte mentale (Mind Map) ----

    /** Bascule entre les deux modes d'affichage des mêmes données (le déclencheur + les
     *  actions de [automation]) : la chaîne de blocs empilés façon Scratch (par défaut),
     *  ou une carte mentale façon ClickUp où le déclencheur est le nœud racine relié à
     *  chaque action. */
    private fun setupModeTabs() {
        binding.tabChainMode.setOnClickListener { setMindMapMode(false) }
        binding.tabMindMapMode.setOnClickListener { setMindMapMode(true) }
        binding.btnMindMapZoomIn.setOnClickListener { binding.mindMapView.zoomBy(1.2f) }
        binding.btnMindMapZoomOut.setOnClickListener { binding.mindMapView.zoomBy(1f / 1.2f) }
        binding.btnMindMapRecenter.setOnClickListener { binding.mindMapView.recenter() }
        setMindMapMode(false)
    }

    private fun setMindMapMode(mindMap: Boolean) {
        binding.recyclerActions.visibility = if (mindMap) View.GONE else View.VISIBLE
        binding.textActionsHint.visibility = if (mindMap) View.GONE else View.VISIBLE
        binding.mindMapContainer.visibility = if (mindMap) View.VISIBLE else View.GONE
        binding.textMindMapHint.visibility = if (mindMap) View.VISIBLE else View.GONE
        binding.btnAddAction.visibility = if (mindMap) View.GONE else View.VISIBLE

        val elevatedBg = com.blockauto.app.R.drawable.bg_card_elevated
        binding.tabChainMode.background = if (!mindMap) androidx.core.content.ContextCompat.getDrawable(this, elevatedBg) else null
        binding.tabMindMapMode.background = if (mindMap) androidx.core.content.ContextCompat.getDrawable(this, elevatedBg) else null
        binding.tabChainMode.setTextColor(
            androidx.core.content.ContextCompat.getColor(this, if (!mindMap) com.blockauto.app.R.color.text_primary else com.blockauto.app.R.color.text_secondary)
        )
        binding.tabMindMapMode.setTextColor(
            androidx.core.content.ContextCompat.getColor(this, if (mindMap) com.blockauto.app.R.color.text_primary else com.blockauto.app.R.color.text_secondary)
        )
        binding.tabChainMode.setTypeface(null, if (!mindMap) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        binding.tabMindMapMode.setTypeface(null, if (mindMap) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

        if (mindMap) refreshMindMap()
    }

    /** Reconstruit la carte mentale à partir du déclencheur et des actions actuels : un
     *  nœud racine (le déclencheur) relié par une courbe à chaque bloc action, dans l'ordre
     *  d'exécution, plus un nœud pointillé pour ajouter une nouvelle action. */
    private fun refreshMindMap() {
        val t = automation.trigger
        val rootColor = t?.type?.paletteCategory()?.color()
            ?: androidx.core.content.ContextCompat.getColor(this, com.blockauto.app.R.color.bg_stroke)
        val root = MindMapNode(
            icon = t?.type?.icon() ?: "❓",
            label = t?.type?.label ?: "Aucun déclencheur",
            detail = t?.params?.entries?.joinToString(", ") { "${it.key}=${it.value}" }?.ifBlank { null },
            color = rootColor
        )
        val children = automation.actions.mapIndexed { index, action ->
            MindMapNode(
                icon = action.type.icon(),
                label = "${index + 1}. ${action.type.label}",
                detail = action.params.entries.joinToString(", ") { "${it.key}=${it.value}" }.ifBlank { null },
                color = action.type.paletteCategory().color()
            )
        }
        binding.mindMapView.setData(root, children)
        binding.mindMapView.onRootTapped = { showTriggerPicker() }
        binding.mindMapView.onAddTapped = { showActionPicker() }
        binding.mindMapView.onChildTapped = { index -> confirmRemoveActionFromMindMap(index) }
    }

    /** Appui sur un nœud action de la carte mentale : montre son détail et propose de le
     *  supprimer (l'édition fine des paramètres reste réservée au mode chaîne). */
    private fun confirmRemoveActionFromMindMap(index: Int) {
        val item = automation.actions.getOrNull(index) ?: return
        val detail = item.params.entries.joinToString("\n") { "${it.key} = ${it.value}" }
        AlertDialog.Builder(this)
            .setTitle("${item.type.icon()} ${item.type.label}")
            .setMessage(detail.ifBlank { "Aucun réglage particulier." })
            .setPositiveButton("Supprimer") { _, _ ->
                automation.actions.removeAt(index)
                actionAdapter.submitList(automation.actions)
                refreshMindMap()
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    // ---- Choix du bloc déclencheur ----

    /**
     * Sélecteur en deux étapes, façon palette Scratch : on choisit d'abord un GROUPE de
     * blocs (coloré, thématique — "Temps", "Réseau"...), puis seulement le bloc précis à
     * l'intérieur de ce groupe. Ça évite de faire défiler une liste géante et non triée
     * de tous les blocs à chaque fois, et range visuellement les blocs qui se ressemblent
     * ensemble — exactement comme les catégories de la palette Scratch/Blockly.
     */
    /** Le libellé d'une catégorie est écrit "EMOJI Texte" (ex. "⏰ Temps") : on sépare
     *  l'emoji pour le badge coloré, et on garde le texte seul comme titre, pour éviter
     *  de voir l'emoji deux fois (badge + texte) dans la grille de catégories. */
    private fun splitCategoryLabel(raw: String): Pair<String, String> {
        val spaceIndex = raw.indexOf(' ')
        return if (spaceIndex <= 0) "🔹" to raw else raw.substring(0, spaceIndex) to raw.substring(spaceIndex + 1)
    }

    private fun showTriggerPicker() {
        val categoryEntries = TriggerCategory.values().map { cat ->
            val types = TriggerType.values().filter { it.paletteCategory() == cat }
            val (emoji, text) = splitCategoryLabel(cat.label)
            BlockPickerDialog.CategoryEntry(
                label = text,
                icon = emoji,
                color = cat.color(),
                items = types.map { type ->
                    BlockPickerDialog.ItemEntry(
                        label = type.label,
                        icon = type.icon(),
                        color = cat.color(),
                        onSelect = { configureTrigger(type) },
                    )
                },
            )
        }
        BlockPickerDialog(this, getString(com.blockauto.app.R.string.picker_choose_trigger_title)).show(categoryEntries)
    }

    private fun configureTrigger(type: TriggerType) {
        when (type) {
            TriggerType.TIME -> {
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    automation.trigger = TriggerBlock(
                        type, mutableMapOf("hour" to hour.toString(), "minute" to minute.toString())
                    )
                    refreshTriggerLabel()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            TriggerType.APP_OPENED -> {
                showAppPicker { pkg ->
                    automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                    refreshTriggerLabel()
                }
            }
            // BUG CORRIGÉ : le moteur (NotifListenerService) sait déclencher sur la
            // notification de "n'importe quelle application" quand le paramètre "package"
            // est vide/absent (voir README), mais cet écran forçait jusqu'ici à toujours
            // choisir une app précise via showAppPicker : ce mode "n'importe laquelle" était
            // donc impossible à créer. On propose maintenant explicitement le choix.
            TriggerType.NOTIFICATION_RECEIVED -> {
                AlertDialog.Builder(this)
                    .setTitle("De quelle application ?")
                    .setItems(arrayOf("N'importe quelle application", "Choisir une application précise")) { _, which ->
                        if (which == 0) {
                            automation.trigger = TriggerBlock(type, mutableMapOf())
                            refreshTriggerLabel()
                        } else {
                            showAppPicker { pkg ->
                                automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                                refreshTriggerLabel()
                            }
                        }
                    }.show()
            }
            TriggerType.INTERVAL -> showNumberInputs(
                listOf(NumericField("Toutes les combien de minutes ?", "minutes", 30, 1, 1440))
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.BATTERY_LEVEL -> {
                AlertDialog.Builder(this)
                    .setTitle("Batterie au-dessus ou en dessous ?")
                    .setItems(arrayOf("Au-dessus de X%", "En dessous de X%")) { _, which ->
                        val operator = if (which == 0) "above" else "below"
                        showNumberInputs(listOf(NumericField("Pourcentage", "level", 50, 0, 100))) { map ->
                            map["operator"] = operator
                            automation.trigger = TriggerBlock(type, map)
                            refreshTriggerLabel()
                        }
                    }.show()
            }
            TriggerType.SMS_RECEIVED -> showTextInputs(
                listOf("Numéro de l'expéditeur (laisser vide = n'importe qui)" to "sender")
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.WIFI_CONNECTED_SSID -> showTextInputs(
                listOf("Nom du réseau Wi-Fi (SSID)" to "ssid")
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.APP_CLOSED -> {
                showAppPicker { pkg ->
                    automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                    refreshTriggerLabel()
                }
            }
            TriggerType.APP_INSTALLED, TriggerType.APP_UNINSTALLED -> {
                AlertDialog.Builder(this)
                    .setTitle("Quelle application ?")
                    .setItems(arrayOf("N'importe quelle application", "Choisir une application précise (nom de paquet)")) { _, which ->
                        if (which == 0) {
                            automation.trigger = TriggerBlock(type, mutableMapOf())
                            refreshTriggerLabel()
                        } else {
                            // On désinstalle justement l'app visée dans le cas APP_UNINSTALLED :
                            // elle n'apparaîtra donc plus dans le sélecteur d'apps installées.
                            // On demande le nom du paquet en texte libre plutôt que de passer
                            // par showAppPicker (qui ne liste que les apps encore installées).
                            showTextInputs(
                                listOf("Nom du paquet (ex : com.whatsapp)" to "package")
                            ) { map ->
                                automation.trigger = TriggerBlock(type, map)
                                refreshTriggerLabel()
                            }
                        }
                    }.show()
            }
            TriggerType.RINGER_MODE_CHANGED -> {
                AlertDialog.Builder(this)
                    .setTitle("Vers quel mode sonnerie ?")
                    .setItems(arrayOf("N'importe lequel", "Normal", "Vibreur", "Silencieux")) { _, which ->
                        val mode = when (which) { 1 -> "normal"; 2 -> "vibrate"; 3 -> "silent"; else -> "" }
                        automation.trigger = TriggerBlock(type, mutableMapOf("mode" to mode))
                        refreshTriggerLabel()
                    }.show()
            }
            TriggerType.WEEKDAY_TIME -> {
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    val dayCodes = arrayOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
                    val dayLabels = arrayOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")
                    val checked = BooleanArray(7)
                    AlertDialog.Builder(this)
                        .setTitle("Quels jours ?")
                        .setMultiChoiceItems(dayLabels, checked) { _, which, isChecked -> checked[which] = isChecked }
                        .setPositiveButton("OK") { _, _ ->
                            val selected = dayCodes.filterIndexed { i, _ -> checked[i] }.joinToString(",")
                            automation.trigger = TriggerBlock(
                                type,
                                mutableMapOf("hour" to hour.toString(), "minute" to minute.toString(), "days" to selected)
                            )
                            refreshTriggerLabel()
                        }
                        .setNegativeButton("Annuler", null)
                        .show()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            TriggerType.RANDOM_DAILY_TIME -> showNumberInputs(
                listOf(
                    NumericField("Heure de début", "start_hour", 8, 0, 23),
                    NumericField("Minute de début", "start_minute", 0, 0, 59),
                    NumericField("Heure de fin", "end_hour", 20, 0, 23),
                    NumericField("Minute de fin", "end_minute", 0, 0, 59)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.COUNTDOWN_ONCE -> showNumberInputs(
                listOf(NumericField("Dans combien de minutes ?", "minutes", 1, 1, 10_080))
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.INTERVAL_LIMITED -> showNumberInputs(
                listOf(
                    NumericField("Toutes les combien de minutes ?", "minutes", 30, 1, 1440),
                    NumericField("Combien de fois au total ?", "times", 3, 1, 100)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.MONTHLY_DATE -> showNumberInputs(
                listOf(
                    NumericField("Quel jour du mois (1-28) ?", "day", 1, 1, 28),
                    NumericField("Heure", "hour", 9, 0, 23),
                    NumericField("Minute", "minute", 0, 0, 59)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.YEARLY_DATE -> showNumberInputs(
                listOf(
                    NumericField("Jour", "day", 1, 1, 28),
                    NumericField("Mois", "month", 1, 1, 12),
                    NumericField("Heure", "hour", 9, 0, 23),
                    NumericField("Minute", "minute", 0, 0, 59)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.RANDOM_INTERVAL -> showNumberInputs(
                listOf(
                    NumericField("Au minimum toutes les combien de minutes ?", "min_minutes", 15, 1, 1440),
                    NumericField("Au maximum toutes les combien de minutes ?", "max_minutes", 45, 1, 1440)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.APP_UPDATED -> {
                AlertDialog.Builder(this)
                    .setTitle("Quelle application ?")
                    .setItems(arrayOf("N'importe quelle application", "Choisir une application précise")) { _, which ->
                        if (which == 0) {
                            automation.trigger = TriggerBlock(type, mutableMapOf())
                            refreshTriggerLabel()
                        } else {
                            showAppPicker { pkg ->
                                automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                                refreshTriggerLabel()
                            }
                        }
                    }.show()
            }
            TriggerType.UI_TEXT_APPEARS -> {
                showTextInputs(
                    listOf("Texte à surveiller à l'écran" to "text")
                ) { textMap ->
                    AlertDialog.Builder(this)
                        .setTitle("Dans quelle application ?")
                        .setItems(arrayOf("N'importe laquelle (au premier plan)", "Choisir une application précise")) { _, which ->
                            if (which == 0) {
                                automation.trigger = TriggerBlock(type, textMap)
                                refreshTriggerLabel()
                            } else {
                                showAppPicker { pkg ->
                                    textMap["package"] = pkg
                                    automation.trigger = TriggerBlock(type, textMap)
                                    refreshTriggerLabel()
                                }
                            }
                        }.show()
                }
            }
            TriggerType.EVERY_N_HOURS -> showNumberInputs(
                listOf(NumericField("Toutes les combien d'heures ?", "hours", 1, 1, 168))
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.UI_TEXT_DISAPPEARS -> {
                showTextInputs(
                    listOf("Texte dont il faut détecter la disparition" to "text")
                ) { textMap ->
                    AlertDialog.Builder(this)
                        .setTitle("Dans quelle application ?")
                        .setItems(arrayOf("N'importe laquelle (au premier plan)", "Choisir une application précise")) { _, which ->
                            if (which == 0) {
                                automation.trigger = TriggerBlock(type, textMap)
                                refreshTriggerLabel()
                            } else {
                                showAppPicker { pkg ->
                                    textMap["package"] = pkg
                                    automation.trigger = TriggerBlock(type, textMap)
                                    refreshTriggerLabel()
                                }
                            }
                        }.show()
                }
            }
            TriggerType.NOTIFICATION_CONTAINS_TEXT -> {
                showTextInputs(
                    listOf("Texte à repérer dans le titre ou le contenu" to "text")
                ) { textMap ->
                    AlertDialog.Builder(this)
                        .setTitle("De quelle application ?")
                        .setItems(arrayOf("N'importe quelle application", "Choisir une application précise")) { _, which ->
                            if (which == 0) {
                                automation.trigger = TriggerBlock(type, textMap)
                                refreshTriggerLabel()
                            } else {
                                showAppPicker { pkg ->
                                    textMap["package"] = pkg
                                    automation.trigger = TriggerBlock(type, textMap)
                                    refreshTriggerLabel()
                                }
                            }
                        }.show()
                }
            }
            TriggerType.TIME_WINDOW_INTERVAL -> showNumberInputs(
                listOf(
                    NumericField("Toutes les combien de minutes ?", "minutes", 30, 1, 1440),
                    NumericField("Heure de début de la fenêtre", "start_hour", 8, 0, 23),
                    NumericField("Minute de début", "start_minute", 0, 0, 59),
                    NumericField("Heure de fin de la fenêtre", "end_hour", 22, 0, 23),
                    NumericField("Minute de fin", "end_minute", 0, 0, 59)
                )
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.FULL_MOON, TriggerType.FRIDAY_13TH -> {
                // Un seul réglage utile pour ces deux blocs "fun" : à quelle heure vérifier
                // chaque jour candidat (pleine lune, ou prochain vendredi 13).
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    automation.trigger = TriggerBlock(
                        type, mutableMapOf("hour" to hour.toString(), "minute" to minute.toString())
                    )
                    refreshTriggerLabel()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            // PALINDROME_TIME n'a aucun réglage : il se déclenche tout seul à chaque heure
            // palindrome de la journée (11:11, 12:21...), géré par le cas "else" ci-dessous.
            TriggerType.NFC_TAG_SCANNED -> startNfcLearnMode()
            else -> {
                automation.trigger = TriggerBlock(type)
                refreshTriggerLabel()
            }
        }
    }

    // ---- Choix des blocs actions / logique ----

    private fun showActionPicker() {
        val categoryEntries = ActionCategory.values().map { cat ->
            val types = ActionType.values().filter { it.paletteCategory() == cat }
            val (emoji, text) = splitCategoryLabel(cat.label)
            BlockPickerDialog.CategoryEntry(
                label = text,
                icon = emoji,
                color = cat.color(),
                items = types.map { type ->
                    BlockPickerDialog.ItemEntry(
                        label = type.label,
                        icon = type.icon(),
                        color = cat.color(),
                        onSelect = { configureAction(type) },
                    )
                },
            )
        }
        BlockPickerDialog(this, getString(com.blockauto.app.R.string.picker_choose_action_title)).show(categoryEntries)
    }

    private fun configureAction(type: ActionType) {
        when (type) {
            ActionType.OPEN_APP -> showAppPicker { pkg ->
                addAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.SEND_NOTIFICATION -> showTextInputs(listOf("Titre" to "title", "Message" to "text")) { fields ->
                // Une fois le titre/message saisis, on demande si la notification doit rester
                // silencieuse (pas de son ni de vibration) — pratique pour les automatisations
                // fun déclenchées la nuit ou en réunion, sans faire de bruit.
                AlertDialog.Builder(this)
                    .setTitle("Notification silencieuse ?")
                    .setItems(arrayOf("Silencieuse (sans bruit)", "Normale (avec son)")) { _, which ->
                        fields["silent"] = if (which == 0) "true" else "false"
                        addAction(ActionBlock(type, fields))
                    }.show()
            }
            ActionType.SHOW_TOAST -> showTextInputs(listOf("Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.VIBRATE -> showNumberInputs(
                listOf(NumericField("Durée en millisecondes", "duration_ms", 500, 100, 20_000))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_RING_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_ALARM_VOLUME -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 5, 0, 15))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SET_BRIGHTNESS -> showNumberInputs(
                listOf(NumericField("Niveau", "level", 128, 0, 255))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TOGGLE_FLASHLIGHT -> onOffDialog("Lampe torche") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_WIFI -> onOffDialog("Wi-Fi") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_BLUETOOTH -> onOffDialog("Bluetooth") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.SET_RINGER_MODE -> {
                AlertDialog.Builder(this)
                    .setTitle("Mode sonnerie")
                    .setItems(arrayOf("Normal", "Vibreur", "Silencieux")) { _, which ->
                        val mode = when (which) { 0 -> "normal"; 1 -> "vibrate"; else -> "silent" }
                        addAction(ActionBlock(type, mutableMapOf("mode" to mode)))
                    }.show()
            }
            ActionType.OPEN_URL -> showTextInputs(listOf("URL (https://...)" to "url")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_SMS -> showTextInputs(listOf("Numéro" to "number", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.MAKE_CALL -> showTextInputs(listOf("Numéro à appeler" to "number")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_EMAIL -> showTextInputs(
                listOf("Destinataire" to "to", "Sujet" to "subject", "Message" to "body")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.COPY_CLIPBOARD -> showTextInputs(listOf("Texte à copier" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CREATE_ALARM -> showNumberInputs(
                listOf(NumericField("Heure", "hour", 7, 0, 23), NumericField("Minute", "minute", 0, 0, 59))
            ) { numMap ->
                showTextInputs(listOf("Libellé" to "label")) { labelMap ->
                    addAction(ActionBlock(type, (numMap + labelMap).toMutableMap()))
                }
            }
            ActionType.LOG_EVENT -> showTextInputs(listOf("Texte à enregistrer" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.WAIT -> showNumberInputs(
                listOf(NumericField("Secondes", "seconds", 1, 1, 300))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.CALL_CONTACT -> showTextInputs(listOf("Nom du contact" to "name")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.ADD_CALENDAR_EVENT -> showTextInputs(listOf("Titre de l'événement" to "title")) { titleMap ->
                showNumberInputs(
                    listOf(
                        NumericField("Dans combien de minutes ?", "minutes_from_now", 0, 0, 10_080),
                        NumericField("Durée (minutes)", "duration_minutes", 60, 5, 1440)
                    )
                ) { numMap ->
                    addAction(ActionBlock(type, (titleMap + numMap).toMutableMap()))
                }
            }
            ActionType.SHARE_TEXT -> showTextInputs(listOf("Texte à partager" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.TOGGLE_AUTO_ROTATE -> onOffDialog("Rotation automatique") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_DND -> onOffDialog("Ne pas déranger") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.RECORD_AUDIO_CLIP -> showNumberInputs(
                listOf(NumericField("Durée en secondes", "seconds", 5, 1, 120))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SPEAK_TEXT -> showTextInputs(listOf("Texte à lire à voix haute" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CREATE_TIMER -> showNumberInputs(
                listOf(NumericField("Durée en secondes", "seconds", 60, 1, 86_400))
            ) { numMap ->
                showTextInputs(listOf("Libellé" to "label")) { labelMap ->
                    addAction(ActionBlock(type, (numMap + labelMap).toMutableMap()))
                }
            }
            ActionType.SET_SCREEN_TIMEOUT -> showNumberInputs(
                listOf(NumericField("Minutes avant mise en veille", "minutes", 2, 1, 60))
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs connecteurs ---
            ActionType.HTTP_REQUEST -> {
                AlertDialog.Builder(this)
                    .setTitle("Méthode HTTP")
                    .setItems(arrayOf("GET", "POST")) { _, which ->
                        val method = if (which == 0) "GET" else "POST"
                        showTextInputs(listOf("URL" to "url", "Corps de la requête (si POST)" to "body")) { map ->
                            map["method"] = method
                            addAction(ActionBlock(type, map))
                        }
                    }.show()
            }
            ActionType.DISCORD_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Discord" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TELEGRAM_MESSAGE -> showTextInputs(
                listOf("Token du bot Telegram" to "bot_token", "Chat ID" to "chat_id", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SLACK_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Slack" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.IFTTT_WEBHOOK -> showTextInputs(
                listOf("Nom de l'événement" to "event_name", "Clé Webhooks IFTTT" to "key", "Valeur (value1)" to "value1")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.HOME_ASSISTANT_WEBHOOK -> showTextInputs(
                listOf("URL de base (ex: http://192.168.1.10:8123)" to "base_url", "ID du webhook" to "webhook_id", "Payload JSON (optionnel)" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.ZAPIER_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Zapier (Catch Hook)" to "webhook_url", "Payload JSON (optionnel)" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.MAKE_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Make (Custom webhook)" to "webhook_url", "Payload JSON (optionnel)" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.NTFY_NOTIFICATION -> showTextInputs(
                listOf("Topic ntfy.sh (ex: mon-topic-secret)" to "topic", "Serveur (optionnel, défaut ntfy.sh)" to "server", "Titre" to "title", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.PUSHOVER_NOTIFICATION -> showTextInputs(
                listOf("Token de l'application Pushover" to "app_token", "Clé utilisateur Pushover" to "user_key", "Titre" to "title", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.GOOGLE_SHEETS_WEBHOOK -> showTextInputs(
                listOf("URL du Web App Google Apps Script" to "web_app_url", "Payload JSON" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.NOTION_API -> showTextInputs(
                listOf("Jeton d'intégration Notion" to "integration_token", "ID de la base de données" to "database_id", "Nom de la propriété titre (défaut: Name)" to "title_property", "Titre de la page" to "title")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TRELLO_WEBHOOK -> showTextInputs(
                listOf("Clé API Trello" to "api_key", "Token Trello" to "token", "ID de la liste" to "list_id", "Nom de la carte" to "name", "Description (optionnel)" to "desc")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.HTTP_REQUEST_ADVANCED -> {
                AlertDialog.Builder(this)
                    .setTitle("Méthode HTTP")
                    .setItems(arrayOf("GET", "POST", "PUT", "PATCH", "DELETE")) { _, which ->
                        val method = arrayOf("GET", "POST", "PUT", "PATCH", "DELETE")[which]
                        showTextInputs(
                            listOf(
                                "URL" to "url",
                                "En-têtes (un par ligne, \"Nom: Valeur\")" to "headers",
                                "Corps de la requête (JSON, si POST/PUT/PATCH)" to "body",
                                "Préfixe des variables de résultat (défaut: http)" to "variable_prefix"
                            )
                        ) { map ->
                            map["method"] = method
                            addAction(ActionBlock(type, map))
                        }
                    }.show()
            }
            ActionType.GET_WEATHER -> showTextInputs(
                listOf("Ville (ex: Paris, Lyon, London...)" to "city")
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs logiques ---
            ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW ->
                showNumberInputs(listOf(NumericField("Pourcentage", "level", 50, 0, 100))) {
                    addConditionAction(ActionBlock(type, it))
                }
            ActionType.IF_DAY_OF_WEEK -> {
                val dayCodes = arrayOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
                val dayLabels = arrayOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")
                val checked = BooleanArray(7)
                AlertDialog.Builder(this)
                    .setTitle("Quels jours ?")
                    .setMultiChoiceItems(dayLabels, checked) { _, which, isChecked -> checked[which] = isChecked }
                    .setPositiveButton("OK") { _, _ ->
                        val selected = dayCodes.filterIndexed { i, _ -> checked[i] }.joinToString(",")
                        addConditionAction(ActionBlock(type, mutableMapOf("days" to selected)))
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            ActionType.IF_TIME_BETWEEN -> showNumberInputs(
                listOf(
                    NumericField("Heure de début", "start_hour", 22, 0, 23),
                    NumericField("Minute de début", "start_minute", 0, 0, 59),
                    NumericField("Heure de fin", "end_hour", 7, 0, 23),
                    NumericField("Minute de fin", "end_minute", 0, 0, 59)
                )
            ) { addConditionAction(ActionBlock(type, it)) }
            ActionType.IF_WIFI_CONNECTED -> addConditionAction(ActionBlock(type))
            ActionType.IF_APP_INSTALLED -> showAppPicker { pkg ->
                addConditionAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.ELSE_BRANCH -> {
                addAction(ActionBlock(type))
                Toast.makeText(
                    this,
                    "Ajoute maintenant les blocs à exécuter si la condition est fausse, puis termine avec « Fin de condition »",
                    Toast.LENGTH_LONG
                ).show()
            }
            ActionType.RANDOM_CHANCE -> showNumberInputs(
                listOf(NumericField("Pourcentage de chance", "percent", 50, 0, 100))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.REPEAT_START -> showNumberInputs(
                listOf(NumericField("Nombre de répétitions", "count", 2, 1, 100))
            ) {
                addAction(ActionBlock(type, it))
                Toast.makeText(
                    this,
                    "Ajoute maintenant les blocs à répéter, puis termine avec le bloc « Fin de répétition »",
                    Toast.LENGTH_LONG
                ).show()
            }
            // --- Chaînage vers une autre automatisation ---
            ActionType.OPEN_APP_SETTINGS -> showAppPicker { pkg ->
                addAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.RUN_AUTOMATION -> showAutomationPicker { targetId, targetName ->
                // Optionnel : poser une "variable d'entrée" avant de lancer la chaîne, comme un
                // argument passé à une fonction — pratique pour réutiliser la même automatisation
                // cible avec des valeurs différentes selon qui l'appelle.
                AlertDialog.Builder(this)
                    .setTitle("Passer une valeur à « $targetName » ?")
                    .setItems(arrayOf("Non, juste chaîner", "Oui, définir une variable avant de lancer")) { _, which ->
                        val base = mutableMapOf("automation_id" to targetId, "automation_name" to targetName)
                        if (which == 0) {
                            addAction(ActionBlock(type, base))
                        } else {
                            showTextInputs(
                                listOf("Nom de la variable à poser" to "input_name", "Valeur (peut utiliser {autre_variable})" to "input_value")
                            ) { inputMap -> addAction(ActionBlock(type, (base + inputMap).toMutableMap())) }
                        }
                    }.show()
            }
            ActionType.RANDOM_RUN_AUTOMATION -> showMultiAutomationPicker { ids ->
                if (ids.isEmpty()) {
                    Toast.makeText(this, "Choisis au moins une automatisation", Toast.LENGTH_SHORT).show()
                } else {
                    addAction(ActionBlock(type, mutableMapOf("automation_ids" to ids.joinToString(","))))
                }
            }
            // --- Blocs variables (façon Scratch) ---
            ActionType.SET_VARIABLE -> showTextInputs(
                listOf("Nom de la variable (sans accolades)" to "name", "Valeur (peut utiliser {autre_variable})" to "value")
            ) { fields ->
                askGlobalScope { global ->
                    fields["global"] = global
                    addAction(ActionBlock(type, fields))
                }
            }
            ActionType.INCREMENT_VARIABLE -> showTextInputs(listOf("Nom de la variable" to "name")) { nameMap ->
                showNumberInputs(listOf(NumericField("Ajouter (négatif pour soustraire)", "amount", 1, -1_000_000, 1_000_000))) { numMap ->
                    askGlobalScope { global ->
                        val fields = (nameMap + numMap).toMutableMap()
                        fields["global"] = global
                        addAction(ActionBlock(type, fields))
                    }
                }
            }
            ActionType.RANDOM_NUMBER -> showTextInputs(listOf("Nom de la variable" to "name")) { nameMap ->
                showNumberInputs(
                    listOf(NumericField("Minimum", "min", 1, -1_000_000, 1_000_000), NumericField("Maximum", "max", 100, -1_000_000, 1_000_000))
                ) { numMap ->
                    addAction(ActionBlock(type, (nameMap + numMap).toMutableMap()))
                }
            }
            ActionType.MATH_OPERATION -> showTextInputs(
                listOf("Nom de la variable résultat" to "result_name", "Valeur A (nombre ou {variable})" to "a", "Valeur B (nombre ou {variable})" to "b")
            ) { fields ->
                AlertDialog.Builder(this)
                    .setTitle("Quelle opération ?")
                    .setItems(arrayOf("A + B", "A − B", "A × B", "A ÷ B", "A modulo B")) { _, which ->
                        fields["operator"] = when (which) { 0 -> "+"; 1 -> "-"; 2 -> "*"; 3 -> "/"; else -> "%" }
                        addAction(ActionBlock(type, fields))
                    }.show()
            }
            ActionType.RANDOM_CHOICE_VARIABLE -> showTextInputs(
                listOf("Nom de la variable résultat" to "result_name", "Choix possibles, séparés par |" to "choices")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.LOAD_GLOBAL_VARIABLE -> showTextInputs(
                listOf("Nom de la variable globale à charger" to "name", "Valeur par défaut si jamais définie" to "default")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.JSON_EXTRACT_VARIABLE -> showTextInputs(
                listOf(
                    "Variable source contenant le JSON (défaut: http_body)" to "source_variable",
                    "Chemin du champ (ex: user.name ou id)" to "field_path",
                    "Nom de la nouvelle variable" to "target_variable"
                )
            ) { fields ->
                askGlobalScope { global ->
                    fields["global"] = global
                    addAction(ActionBlock(type, fields))
                }
            }
            ActionType.SET_LIST -> showTextInputs(
                listOf("Nom de la liste" to "name", "Éléments séparés par |  (ex: Alice|Bob|Chloé)" to "items")
            ) { fields ->
                askGlobalScope { global ->
                    fields["global"] = global
                    addAction(ActionBlock(type, fields))
                }
            }
            ActionType.LIST_APPEND -> showTextInputs(
                listOf("Nom de la liste" to "name", "Valeur à ajouter (peut utiliser {variable})" to "value")
            ) { fields ->
                askGlobalScope { global ->
                    fields["global"] = global
                    addAction(ActionBlock(type, fields))
                }
            }
            ActionType.LIST_GET_ITEM -> showTextInputs(
                listOf("Nom de la liste" to "name", "Position (0 = premier élément)" to "index", "Nom de la variable résultat" to "result_name")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.LIST_LENGTH -> showTextInputs(
                listOf("Nom de la liste" to "name", "Nom de la variable résultat" to "result_name")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.PAUSE_AUTOMATION_FOR -> showAutomationPicker { targetId, targetName ->
                showNumberInputs(listOf(NumericField("Durée de la pause (minutes)", "minutes", 30, 1, 1440))) { numMap ->
                    numMap["automation_id"] = targetId
                    numMap["automation_name"] = targetName
                    addAction(ActionBlock(type, numMap))
                }
            }
            ActionType.RANDOM_DELAY -> showNumberInputs(
                listOf(
                    NumericField("Minimum (secondes)", "min_seconds", 1, 0, 300),
                    NumericField("Maximum (secondes)", "max_seconds", 5, 0, 300)
                )
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs logiques avancés (conditions et boucles sur des valeurs) ---
            ActionType.IF_VARIABLE_ABOVE, ActionType.IF_VARIABLE_BELOW -> showTextInputs(listOf("Nom de la variable" to "name")) { nameMap ->
                showNumberInputs(listOf(NumericField("Seuil", "value", 0, -1_000_000, 1_000_000))) { numMap ->
                    addConditionAction(ActionBlock(type, (nameMap + numMap).toMutableMap()))
                }
            }
            ActionType.IF_VARIABLE_EQUALS -> showTextInputs(
                listOf("Nom de la variable" to "name", "Valeur attendue" to "value")
            ) { addConditionAction(ActionBlock(type, it)) }
            ActionType.REPEAT_WHILE_START -> showTextInputs(listOf("Nom de la variable" to "name")) { nameMap ->
                AlertDialog.Builder(this)
                    .setTitle("Répéter tant que la variable est...")
                    .setItems(arrayOf("En dessous d'un seuil", "Au-dessus d'un seuil")) { _, which ->
                        val operator = if (which == 0) "below" else "above"
                        showNumberInputs(
                            listOf(
                                NumericField("Seuil", "threshold", 10, -1_000_000, 1_000_000),
                                NumericField("Nombre de tours maximum (sécurité)", "max_iterations", 50, 1, 500)
                            )
                        ) { numMap ->
                            val fields = (nameMap + numMap).toMutableMap()
                            fields["operator"] = operator
                            addAction(ActionBlock(type, fields))
                            Toast.makeText(
                                this,
                                "Ajoute maintenant les blocs à répéter, puis termine avec « Fin de répétition »",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }.show()
            }
            // --- Blocs fun / envois groupés ---
            ActionType.SEND_MULTIPLE_SMS -> showTextInputs(
                listOf("Numéro" to "number", "Message (utilise {n} pour le numéro d'ordre)" to "text")
            ) { textMap ->
                showNumberInputs(
                    listOf(
                        NumericField("Combien de messages ?", "count", 3, 1, 20),
                        NumericField("Pause entre chaque (secondes)", "delay_seconds", 2, 0, 300)
                    )
                ) { numMap -> addAction(ActionBlock(type, (textMap + numMap).toMutableMap())) }
            }
            ActionType.SEND_MULTIPLE_NOTIFICATIONS -> showTextInputs(
                listOf("Titre" to "title", "Message (utilise {n} pour le numéro d'ordre)" to "text")
            ) { textMap ->
                showNumberInputs(
                    listOf(
                        NumericField("Combien de notifications ?", "count", 3, 1, 20),
                        NumericField("Pause entre chaque (secondes)", "delay_seconds", 2, 0, 300)
                    )
                ) { numMap -> addAction(ActionBlock(type, (textMap + numMap).toMutableMap())) }
            }
            ActionType.PLAY_BEEP -> showNumberInputs(
                listOf(NumericField("Combien de bips ?", "count", 1, 1, 10))
            ) { addAction(ActionBlock(type, it)) }
            ActionType.VIBRATE_PATTERN -> {
                AlertDialog.Builder(this)
                    .setTitle("Motif de vibration")
                    .setItems(arrayOf("SOS (morse)", "Motif personnalisé")) { _, which ->
                        if (which == 0) {
                            addAction(ActionBlock(type, mutableMapOf("pattern" to "sos")))
                        } else {
                            showTextInputs(
                                listOf("Durées en ms séparées par des virgules (pause,vibre,pause,vibre...)" to "pattern")
                            ) { addAction(ActionBlock(type, it)) }
                        }
                    }.show()
            }
            ActionType.SHOW_RANDOM_MESSAGE -> showTextInputs(
                listOf("Messages possibles, séparés par |" to "messages")
            ) { addAction(ActionBlock(type, it)) }

            // --- Blocs d'interaction DANS une autre application ---
            ActionType.UI_CLICK_TEXT, ActionType.UI_LONG_CLICK_TEXT -> showTextInputs(
                listOf("Texte affiché sur l'élément à cliquer" to "text")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.UI_CLICK_DESCRIPTION -> showTextInputs(
                listOf("Description de l'icône (ex : Envoyer, Menu...)" to "description")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.UI_INPUT_TEXT -> showTextInputs(
                listOf("Texte à écrire dans le champ actif" to "text")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.UI_SCROLL_DOWN, ActionType.UI_SCROLL_UP, ActionType.UI_PRESS_BACK ->
                addAction(ActionBlock(type))
            ActionType.UI_SWIPE -> {
                AlertDialog.Builder(this)
                    .setTitle("Balayer vers où ?")
                    .setItems(arrayOf("Vers le haut", "Vers le bas", "Vers la gauche", "Vers la droite")) { _, which ->
                        val direction = when (which) { 0 -> "up"; 1 -> "down"; 2 -> "left"; else -> "right" }
                        addAction(ActionBlock(type, mutableMapOf("direction" to direction)))
                    }.show()
            }
            ActionType.UI_WAIT_FOR_TEXT -> showTextInputs(
                listOf("Texte à attendre" to "text")
            ) { map ->
                showNumberInputs(listOf(NumericField("Délai maximum (secondes) ?", "timeout_seconds", 10, 1, 120))) { numMap ->
                    map.putAll(numMap)
                    addAction(ActionBlock(type, map))
                }
            }
            ActionType.UI_OPEN_APP_AND_CLICK -> {
                showAppPicker { pkg ->
                    showTextInputs(
                        listOf("Texte à cliquer une fois l'application ouverte" to "text")
                    ) { map ->
                        map["package"] = pkg
                        addAction(ActionBlock(type, map))
                    }
                }
            }
            ActionType.IF_TEXT_VISIBLE -> showTextInputs(
                listOf("Texte à repérer à l'écran" to "text")
            ) { addConditionAction(ActionBlock(type, it)) }

            // --- Blocs "envoyer un message dans une appli" (Instagram, WhatsApp, etc.) ---
            ActionType.UI_CLICK_INPUT_FIELD -> addAction(ActionBlock(type))
            ActionType.UI_SEND_MESSAGE_IN_APP -> showTextInputs(
                listOf(
                    "Message à envoyer" to "text",
                    "Libellé exact du bouton d'envoi (laisser vide = essaie automatiquement « Envoyer », « Send »...)" to "send_label"
                )
            ) { map ->
                Toast.makeText(
                    this,
                    "Assure-toi que la conversation est déjà ouverte à l'écran avant ce bloc (ajoute par exemple un bloc « Ouvrir une application » juste avant).",
                    Toast.LENGTH_LONG
                ).show()
                addAction(ActionBlock(type, map))
            }
            ActionType.UI_SEND_MULTIPLE_MESSAGES_IN_APP -> showTextInputs(
                listOf(
                    "Message (utilise {n} pour le numéro d'ordre)" to "text",
                    "Libellé exact du bouton d'envoi (laisser vide = automatique)" to "send_label"
                )
            ) { textMap ->
                showNumberInputs(
                    listOf(
                        NumericField("Combien de messages ?", "count", 3, 1, 20),
                        NumericField("Pause entre chaque (secondes)", "delay_seconds", 3, 1, 300)
                    )
                ) { numMap ->
                    Toast.makeText(
                        this,
                        "Assure-toi que la conversation est déjà ouverte à l'écran avant ce bloc.",
                        Toast.LENGTH_LONG
                    ).show()
                    addAction(ActionBlock(type, (textMap + numMap).toMutableMap()))
                }
            }
            ActionType.UI_OPEN_APP_AND_SEND_MESSAGE -> {
                showAppPicker { pkg ->
                    showTextInputs(
                        listOf(
                            "Nom du contact/de la conversation à cliquer (laisser vide si l'appli ouvre déjà la bonne conversation)" to "contact_text",
                            "Message à envoyer" to "text",
                            "Libellé exact du bouton d'envoi (laisser vide = automatique)" to "send_label"
                        )
                    ) { map ->
                        map["package"] = pkg
                        addAction(ActionBlock(type, map))
                    }
                }
            }

            // --- Blocs fun / surprises ---
            ActionType.FLIP_COIN -> showTextInputs(
                listOf("Nom de la variable pour le résultat (PILE/FACE)" to "name")
            ) { fields ->
                if (fields["name"].isNullOrBlank()) fields["name"] = "piece"
                askGlobalScope { global ->
                    fields["global"] = global
                    addAction(ActionBlock(type, fields))
                }
            }
            ActionType.SET_WALLPAPER_COLOR -> {
                val presetColors = listOf(
                    "🌌 Bleu nuit" to "#0D1B2A", "❤️ Rouge vif" to "#E63946", "🌿 Vert menthe" to "#2DD4BF",
                    "💜 Violet" to "#7C3AED", "🧡 Orange" to "#F97316", "⚫ Noir" to "#000000", "🌸 Rose" to "#FF6FB0"
                )
                val labels = (presetColors.map { it.first } + "Couleur personnalisée (code hex)").toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Quelle couleur de fond d'écran ?")
                    .setItems(labels) { _, which ->
                        if (which < presetColors.size) {
                            addAction(ActionBlock(type, mutableMapOf("color" to presetColors[which].second)))
                        } else {
                            showTextInputs(listOf("Code couleur hex (ex : #FF5733)" to "color")) { map ->
                                addAction(ActionBlock(type, map))
                            }
                        }
                    }.show()
            }
            // TELL_JOKE, OPEN_RANDOM_APP et MYSTERY_BOX n'ont besoin d'aucun réglage :
            // ils tombent dans le cas "else" ci-dessous, prêts à l'emploi en un tap.
            else -> addAction(ActionBlock(type))
        }
    }

    /** Ajoute un bloc "Si..." et rappelle qu'on peut le refermer en vrai Si / Sinon. */
    private fun addConditionAction(block: ActionBlock) {
        addAction(block)
        Toast.makeText(this, IF_HINT, Toast.LENGTH_LONG).show()
    }

    private fun addAction(block: ActionBlock) {
        automation.actions.add(block)
        actionAdapter.submitList(automation.actions)
        refreshMindMap()
    }

    // ---- Utilitaires de saisie ----

    /** Description d'un champ numérique : clé du paramètre, valeur par défaut et bornes valides. */
    private data class NumericField(val label: String, val key: String, val default: Long, val min: Long, val max: Long)

    /**
     * Variante numérique de [showTextInputs] : clavier numérique, valeur par défaut pré-remplie,
     * et surtout un retour visible si ce qui est tapé n'est pas exploitable.
     *
     * ARCHITECTURE : avant ce correctif, tous les champs "durée"/"pourcentage"/"niveau" passaient
     * par [showTextInputs] avec un clavier texte libre, et une entrée invalide (lettre tapée par
     * erreur, champ laissé vide, espace collé, etc.) retombait *silencieusement* sur une valeur
     * par défaut dans AutomationExecutor — donnant l'impression que le bloc "ne fonctionne pas"
     * alors qu'il s'exécute très bien, juste pas avec la durée demandée. C'est exactement ce qui
     * rendait "Faire vibrer" pendant un temps précis peu fiable. Cette fonction centralise la
     * validation au moment de la saisie : clavier numérique, et un Toast explicite si la valeur
     * est hors bornes ou illisible, plutôt qu'un silence qui masque le problème.
     */
    private fun showNumberInputs(fields: List<NumericField>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { field ->
            val edit = EditText(this)
            edit.hint = "${field.label} (${field.min}-${field.max})"
            edit.setText(field.default.toString())
            edit.inputType = InputType.TYPE_CLASS_NUMBER
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                var hadInvalid = false
                fields.forEachIndexed { index, field ->
                    val typed = editTexts[index].text.toString().trim().toLongOrNull()
                    val value = if (typed == null) {
                        hadInvalid = true
                        field.default
                    } else {
                        typed.coerceIn(field.min, field.max)
                    }
                    map[field.key] = value.toString()
                }
                if (hadInvalid) {
                    Toast.makeText(this, "Valeur invalide ignorée, réglage par défaut utilisé", Toast.LENGTH_LONG).show()
                }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun onOffDialog(title: String, onPicked: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("Activer", "Désactiver")) { _, which ->
                onPicked(if (which == 0) "on" else "off")
            }.show()
    }

    /** Demande si une variable doit rester locale à cette exécution ou devenir "globale"
     *  (persistée sur disque, lisible par n'importe quelle autre automatisation). */
    private fun askGlobalScope(onPicked: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Variable locale ou globale ?")
            .setItems(arrayOf("Locale (cette automatisation et ses chaînes)", "Globale (partagée avec toutes les automatisations)")) { _, which ->
                onPicked(if (which == 1) "true" else "false")
            }.show()
    }

    /** Sélection à cases à cocher de plusieurs automatisations, pour le bloc "Chaîner vers une
     *  automatisation au hasard" — contrairement à [showAutomationPicker] qui n'en choisit qu'une. */
    private fun showMultiAutomationPicker(onPicked: (List<String>) -> Unit) {
        val others = AutomationRepository.getAll(this).filter { it.id != automation.id }
        if (others.size < 2) {
            Toast.makeText(this, "Crée d'abord au moins deux autres automatisations à tirer au sort", Toast.LENGTH_LONG).show()
            return
        }
        val labels = others.map { it.name.ifBlank { "Automatisation sans nom" } }.toTypedArray()
        val checked = BooleanArray(others.size)
        AlertDialog.Builder(this)
            .setTitle("Tirer au sort parmi lesquelles ?")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("OK") { _, _ ->
                onPicked(others.filterIndexed { i, _ -> checked[i] }.map { it.id })
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showTextInputs(fields: List<Pair<String, String>>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { (label, _) ->
            val edit = EditText(this)
            edit.hint = label
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                fields.forEachIndexed { index, (_, key) -> map[key] = editTexts[index].text.toString() }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /** Liste toutes les autres automatisations existantes pour construire une chaîne
     *  (l'automatisation en cours d'édition est exclue pour éviter une boucle évidente
     *  sur elle-même ; les boucles indirectes restent possibles mais sont limitées par
     *  la profondeur maximale gérée dans AutomationExecutor). */
    private fun showAutomationPicker(onPicked: (id: String, name: String) -> Unit) {
        val others = AutomationRepository.getAll(this).filter { it.id != automation.id }
        if (others.isEmpty()) {
            Toast.makeText(this, "Crée d'abord une autre automatisation à chaîner", Toast.LENGTH_LONG).show()
            return
        }
        val labels = others.map { it.name.ifBlank { "Automatisation sans nom" } }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Chaîner vers quelle automatisation ?")
            .setItems(labels) { _, which -> onPicked(others[which].id, others[which].name) }
            .show()
    }

    private fun showAppPicker(onPicked: (String) -> Unit) {
        val pm = packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir une application")
            .setItems(labels) { _, which -> onPicked(apps[which].activityInfo.packageName) }
            .show()
    }
}
