package com.blockauto.app.builder

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.blockauto.app.databinding.ActivityAutomationBuilderBinding
import com.blockauto.app.engine.TriggerScheduler
import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType
import com.blockauto.app.storage.AutomationRepository
import java.util.Calendar

/**
 * Écran "atelier de blocs" : on choisit un bloc déclencheur, puis on empile
 * les blocs actions / logique dans l'ordre voulu, exactement comme des rouages
 * qu'on assemble les uns après les autres pour fabriquer un scénario complet.
 */
class AutomationBuilderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAutomationBuilderBinding
    private lateinit var automation: Automation
    private lateinit var actionAdapter: ActionBlockAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAutomationBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra("automation_id")
        automation = if (id != null) AutomationRepository.get(this, id) ?: Automation() else Automation()

        binding.editName.setText(automation.name)

        binding.recyclerActions.layoutManager = LinearLayoutManager(this)
        binding.recyclerActions.addItemDecoration(GearConnectorDecoration(this))
        actionAdapter = ActionBlockAdapter { position ->
            automation.actions.removeAt(position)
            actionAdapter.submitList(automation.actions)
        }
        binding.recyclerActions.adapter = actionAdapter
        actionAdapter.submitList(automation.actions)

        refreshTriggerLabel()

        binding.btnPickTrigger.setOnClickListener { showTriggerPicker() }
        binding.btnAddAction.setOnClickListener { showActionPicker() }

        binding.btnSave.setOnClickListener {
            automation.name = binding.editName.text.toString().ifBlank { "Automatisation" }
            if (automation.trigger == null) {
                Toast.makeText(this, "Choisis un bloc déclencheur", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (automation.actions.isEmpty()) {
                Toast.makeText(this, "Ajoute au moins un bloc action", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AutomationRepository.save(this, automation)
            TriggerScheduler.schedule(this, automation)
            finish()
        }

        binding.btnDelete.setOnClickListener {
            AutomationRepository.delete(this, automation.id)
            TriggerScheduler.cancel(this, automation.id)
            finish()
        }
        binding.btnDelete.visibility = if (id != null) View.VISIBLE else View.GONE
    }

    private fun refreshTriggerLabel() {
        val t = automation.trigger
        val detail = t?.params?.entries?.joinToString(", ") { "${it.key}=${it.value}" }
        binding.textCurrentTrigger.text = when {
            t == null -> "Aucun déclencheur choisi"
            detail.isNullOrBlank() -> t.type.label
            else -> "${t.type.label} ($detail)"
        }
    }

    // ---- Choix du bloc déclencheur ----

    private fun showTriggerPicker() {
        val types = TriggerType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc déclencheur")
            .setItems(labels) { _, which -> configureTrigger(types[which]) }
            .show()
    }

    private fun configureTrigger(type: TriggerType) {
        when (type) {
            TriggerType.TIME -> {
                val now = Calendar.getInstance()
                TimePickerDialog(this, { _, hour, minute ->
                    automation.trigger = TriggerBlock(
                        type, mutableMapOf("hour" to hour.toString(), "minute" to minute.toString())
                    )
                    refreshTriggerLabel()
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }
            TriggerType.APP_OPENED, TriggerType.NOTIFICATION_RECEIVED -> {
                showAppPicker { pkg ->
                    automation.trigger = TriggerBlock(type, mutableMapOf("package" to pkg))
                    refreshTriggerLabel()
                }
            }
            TriggerType.INTERVAL -> showTextInputs(listOf("Toutes les combien de minutes ?" to "minutes")) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            TriggerType.BATTERY_LEVEL -> {
                AlertDialog.Builder(this)
                    .setTitle("Batterie au-dessus ou en dessous ?")
                    .setItems(arrayOf("Au-dessus de X%", "En dessous de X%")) { _, which ->
                        val operator = if (which == 0) "above" else "below"
                        showTextInputs(listOf("Pourcentage (0-100)" to "level")) { map ->
                            map["operator"] = operator
                            automation.trigger = TriggerBlock(type, map)
                            refreshTriggerLabel()
                        }
                    }.show()
            }
            TriggerType.SMS_RECEIVED -> showTextInputs(
                listOf("Numéro de l'expéditeur (laisser vide = n'importe qui)" to "sender")
            ) {
                automation.trigger = TriggerBlock(type, it)
                refreshTriggerLabel()
            }
            else -> {
                automation.trigger = TriggerBlock(type)
                refreshTriggerLabel()
            }
        }
    }

    // ---- Choix des blocs actions / logique ----

    private fun showActionPicker() {
        val types = ActionType.values()
        val labels = types.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir un bloc action ou logique")
            .setItems(labels) { _, which -> configureAction(types[which]) }
            .show()
    }

    private fun configureAction(type: ActionType) {
        when (type) {
            ActionType.OPEN_APP -> showAppPicker { pkg ->
                addAction(ActionBlock(type, mutableMapOf("package" to pkg)))
            }
            ActionType.SEND_NOTIFICATION -> showTextInputs(listOf("Titre" to "title", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SHOW_TOAST -> showTextInputs(listOf("Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.VIBRATE -> showTextInputs(listOf("Durée en millisecondes" to "duration_ms")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SET_VOLUME -> showTextInputs(listOf("Niveau (0 à 15)" to "level")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SET_BRIGHTNESS -> showTextInputs(listOf("Niveau (0 à 255)" to "level")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.TOGGLE_FLASHLIGHT -> onOffDialog("Lampe torche") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_WIFI -> onOffDialog("Wi-Fi") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_BLUETOOTH -> onOffDialog("Bluetooth") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.SET_RINGER_MODE -> {
                AlertDialog.Builder(this)
                    .setTitle("Mode sonnerie")
                    .setItems(arrayOf("Normal", "Vibreur", "Silencieux")) { _, which ->
                        val mode = when (which) { 0 -> "normal"; 1 -> "vibrate"; else -> "silent" }
                        addAction(ActionBlock(type, mutableMapOf("mode" to mode)))
                    }.show()
            }
            ActionType.OPEN_URL -> showTextInputs(listOf("URL (https://...)" to "url")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_SMS -> showTextInputs(listOf("Numéro" to "number", "Message" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.MAKE_CALL -> showTextInputs(listOf("Numéro à appeler" to "number")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.SEND_EMAIL -> showTextInputs(
                listOf("Destinataire" to "to", "Sujet" to "subject", "Message" to "body")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.COPY_CLIPBOARD -> showTextInputs(listOf("Texte à copier" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CREATE_ALARM -> showTextInputs(
                listOf("Heure (0-23)" to "hour", "Minute (0-59)" to "minute", "Libellé" to "label")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.LOG_EVENT -> showTextInputs(listOf("Texte à enregistrer" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.WAIT -> showTextInputs(listOf("Secondes" to "seconds")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.CALL_CONTACT -> showTextInputs(listOf("Nom du contact" to "name")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.ADD_CALENDAR_EVENT -> showTextInputs(
                listOf(
                    "Titre de l'événement" to "title",
                    "Dans combien de minutes ?" to "minutes_from_now",
                    "Durée (minutes)" to "duration_minutes"
                )
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SHARE_TEXT -> showTextInputs(listOf("Texte à partager" to "text")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.TOGGLE_AUTO_ROTATE -> onOffDialog("Rotation automatique") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.TOGGLE_DND -> onOffDialog("Ne pas déranger") {
                addAction(ActionBlock(type, mutableMapOf("state" to it)))
            }
            ActionType.RECORD_AUDIO_CLIP -> showTextInputs(listOf("Durée en secondes" to "seconds")) {
                addAction(ActionBlock(type, it))
            }
            // --- Blocs connecteurs ---
            ActionType.HTTP_REQUEST -> {
                AlertDialog.Builder(this)
                    .setTitle("Méthode HTTP")
                    .setItems(arrayOf("GET", "POST")) { _, which ->
                        val method = if (which == 0) "GET" else "POST"
                        showTextInputs(listOf("URL" to "url", "Corps de la requête (si POST)" to "body")) { map ->
                            map["method"] = method
                            addAction(ActionBlock(type, map))
                        }
                    }.show()
            }
            ActionType.DISCORD_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Discord" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.TELEGRAM_MESSAGE -> showTextInputs(
                listOf("Token du bot Telegram" to "bot_token", "Chat ID" to "chat_id", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.SLACK_WEBHOOK -> showTextInputs(
                listOf("URL du webhook Slack" to "webhook_url", "Message" to "message")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.IFTTT_WEBHOOK -> showTextInputs(
                listOf("Nom de l'événement" to "event_name", "Clé Webhooks IFTTT" to "key", "Valeur (value1)" to "value1")
            ) { addAction(ActionBlock(type, it)) }
            ActionType.HOME_ASSISTANT_WEBHOOK -> showTextInputs(
                listOf("URL de base (ex: http://192.168.1.10:8123)" to "base_url", "ID du webhook" to "webhook_id", "Payload JSON (optionnel)" to "payload")
            ) { addAction(ActionBlock(type, it)) }
            // --- Blocs logiques ---
            ActionType.IF_BATTERY_ABOVE, ActionType.IF_BATTERY_BELOW ->
                showTextInputs(listOf("Pourcentage (0-100)" to "level")) {
                    addAction(ActionBlock(type, it))
                }
            ActionType.IF_DAY_OF_WEEK -> {
                val dayCodes = arrayOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
                val dayLabels = arrayOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")
                val checked = BooleanArray(7)
                AlertDialog.Builder(this)
                    .setTitle("Quels jours ?")
                    .setMultiChoiceItems(dayLabels, checked) { _, which, isChecked -> checked[which] = isChecked }
                    .setPositiveButton("OK") { _, _ ->
                        val selected = dayCodes.filterIndexed { i, _ -> checked[i] }.joinToString(",")
                        addAction(ActionBlock(type, mutableMapOf("days" to selected)))
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            ActionType.IF_TIME_BETWEEN -> showTextInputs(
                listOf(
                    "Heure de début (0-23)" to "start_hour", "Minute de début" to "start_minute",
                    "Heure de fin (0-23)" to "end_hour", "Minute de fin" to "end_minute"
                )
            ) { addAction(ActionBlock(type, it)) }
            ActionType.RANDOM_CHANCE -> showTextInputs(listOf("Pourcentage de chance (0-100)" to "percent")) {
                addAction(ActionBlock(type, it))
            }
            ActionType.REPEAT_START -> showTextInputs(listOf("Nombre de répétitions" to "count")) {
                addAction(ActionBlock(type, it))
                Toast.makeText(
                    this,
                    "Ajoute maintenant les blocs à répéter, puis termine avec le bloc « Fin de répétition »",
                    Toast.LENGTH_LONG
                ).show()
            }
            else -> addAction(ActionBlock(type))
        }
    }

    private fun addAction(block: ActionBlock) {
        automation.actions.add(block)
        actionAdapter.submitList(automation.actions)
    }

    // ---- Utilitaires de saisie ----

    private fun onOffDialog(title: String, onPicked: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("Activer", "Désactiver")) { _, which ->
                onPicked(if (which == 0) "on" else "off")
            }.show()
    }

    private fun showTextInputs(fields: List<Pair<String, String>>, onDone: (MutableMap<String, String>) -> Unit) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        container.setPadding(padding, padding, padding, padding)
        val editTexts = fields.map { (label, _) ->
            val edit = EditText(this)
            edit.hint = label
            container.addView(edit)
            edit
        }
        AlertDialog.Builder(this)
            .setTitle("Paramètres du bloc")
            .setView(container)
            .setPositiveButton("OK") { _, _ ->
                val map = mutableMapOf<String, String>()
                fields.forEachIndexed { index, (_, key) -> map[key] = editTexts[index].text.toString() }
                onDone(map)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showAppPicker(onPicked: (String) -> Unit) {
        val pm = packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir une application")
            .setItems(labels) { _, which -> onPicked(apps[which].activityInfo.packageName) }
            .show()
    }
}
