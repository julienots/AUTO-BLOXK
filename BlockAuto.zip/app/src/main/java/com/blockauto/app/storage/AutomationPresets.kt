package com.blockauto.app.storage

import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType

/**
 * Suggestions réellement utilisables sans fausse adresse IP ni service externe.
 * Les actions qui dépendent d'un accès Android spécial restent explicitement
 * indiquées dans leur description.
 */
object AutomationPresets {
    data class Preset(
        val title: String,
        val description: String,
        val build: () -> List<Automation>
    )

    fun all(): List<Preset> = listOf(
        Preset(
            "🔋 Alerte batterie faible",
            "Quand Android signale une batterie faible : notification + vibration.",
            {
                listOf(Automation(
                    name = "Alerte batterie faible",
                    trigger = TriggerBlock(TriggerType.BATTERY_LOW),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "Batterie faible", "text" to "Pense à brancher ton téléphone 🔌")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "800")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Alerte batterie faible déclenchée"))
                    )
                ))
            }
        ),
        Preset(
            "🔌 BlockAuto au démarrage",
            "Au redémarrage du téléphone : message + historique. Aucun réglage externe.",
            {
                listOf(Automation(
                    name = "BlockAuto actif au démarrage",
                    trigger = TriggerBlock(TriggerType.BOOT_COMPLETED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "BlockAuto est actif ✅")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Démarrage détecté"))
                    )
                ))
            }
        ),
        Preset(
            "🎉 Secousse party",
            "Secoue le téléphone : double vibration + message.",
            {
                listOf(Automation(
                    name = "Secousse party",
                    trigger = TriggerBlock(TriggerType.SHAKE),
                    actions = mutableListOf(
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150")),
                        ActionBlock(ActionType.WAIT, mutableMapOf("seconds" to "1")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🎉 Party time !"))
                    )
                ))
            }
        ),
        Preset(
            "✨ Batterie pleine",
            "Quand le téléphone est branché : vibration + message de confirmation.",
            {
                listOf(Automation(
                    name = "Batterie pleine",
                    trigger = TriggerBlock(TriggerType.BATTERY_FULL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "200")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "✨ Batterie pleine / secteur détecté"))
                    )
                ))
            }
        ),
        Preset(
            "🎧 Casque branché",
            "Quand un casque filaire est branché : notification + vibration.",
            {
                listOf(Automation(
                    name = "Casque branché",
                    trigger = TriggerBlock(TriggerType.HEADSET_CONNECTED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "🎧 Casque connecté", "text" to "Ton casque vient d'être branché.")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150"))
                    )
                ))
            }
        ),
        Preset(
            "📶 Connexion Wi‑Fi",
            "Quand un Wi‑Fi est détecté : message de confirmation. Tu peux ensuite modifier le SSID dans l'atelier.",
            {
                listOf(Automation(
                    name = "Connexion Wi‑Fi",
                    trigger = TriggerBlock(TriggerType.WIFI_CONNECTED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "📶 Wi‑Fi connecté")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Connexion Wi‑Fi détectée"))
                    )
                ))
            }
        ),
        Preset(
            "⏰ Test dans 1 minute",
            "Crée une automatisation temporaire qui se déclenche une minute après l'activation. Pratique pour vérifier que les alarmes fonctionnent.",
            {
                listOf(Automation(
                    name = "Test alarme 1 minute",
                    trigger = TriggerBlock(TriggerType.INTERVAL, mutableMapOf("minutes" to "1")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "BlockAuto", "text" to "✅ Le déclencheur fonctionne !")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Test du déclencheur INTERVAL réussi"))
                    )
                ))
            }
        ),
        Preset(
            "🎲 Coup de dé",
            "Déclenchement manuel : 50 % de chance d'afficher un message chanceux.",
            {
                listOf(Automation(
                    name = "Coup de dé",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.RANDOM_CHANCE, mutableMapOf("percent" to "50")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "100")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🍀 Aujourd'hui est ton jour de chance !"))
                    )
                ))
            }
        ),
        Preset(
            "⛓️ Démonstration du chaînage",
            "Crée deux automatisations. La première lance automatiquement la seconde : tu peux tester la chaîne avec le bouton ▶️.",
            {
                val second = Automation(
                    name = "Chaîne B — message",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "Chaîne BlockAuto", "text" to "⛓️ La deuxième automatisation a bien été exécutée !")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Chaîne B exécutée"))
                    )
                )
                val first = Automation(
                    name = "Chaîne A — lance B",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "⛓️ Lancement de la chaîne…")),
                        ActionBlock(ActionType.RUN_AUTOMATION, mutableMapOf("automation_id" to second.id, "automation_name" to second.name)),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Chaîne A terminée"))
                    )
                )
                listOf(first, second)
            }
        ),
        Preset(
            "🔊 Volume à 50 %",
            "À 8h00 : règle le volume média à environ 50 %. Nécessite uniquement l'accès audio normal.",
            {
                listOf(Automation(
                    name = "Volume du matin (8h00)",
                    trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "8", "minute" to "0")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SET_VOLUME, mutableMapOf("level" to "7")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🔊 Volume réglé pour le matin"))
                    )
                ))
            }
        )
    )
}
