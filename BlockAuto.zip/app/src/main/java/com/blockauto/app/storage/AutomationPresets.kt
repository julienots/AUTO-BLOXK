package com.blockauto.app.storage

import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType

/**
 * Modèles d'automatisations prêts à l'emploi, proposés à l'utilisateur en un clic
 * depuis l'écran principal ("Suggestions"). Chaque modèle reste modifiable ensuite
 * normalement dans l'atelier de blocs (adresse IP, horaires, textes...).
 *
 * Le bloc "Connecteur HTTP" est utilisé pour piloter l'ampoule connectée : la plupart
 * des ampoules/prises Wi-Fi grand public (Shelly, Tasmota/Sonoff, Home Assistant local...)
 * s'allument via une simple requête HTTP GET vers leur adresse IP locale. Remplace
 * `http://192.168.1.50/relay/0?turn=on` par l'URL réelle de ta lampe (voir doc du fabricant,
 * ou utilise le bloc "Webhook Home Assistant" si ta lampe est gérée par Home Assistant).
 */
object AutomationPresets {

    private const val LAMP_ON_URL = "http://192.168.1.50/relay/0?turn=on"
    private const val LAMP_OFF_URL = "http://192.168.1.50/relay/0?turn=off"

    data class Preset(
        val title: String,
        val description: String,
        // Renvoie une LISTE d'automatisations : la plupart des modèles n'en créent qu'une,
        // mais certains (ex: démo de chaînage) doivent créer plusieurs automatisations liées
        // entre elles (l'une déclenche l'autre via le bloc "Exécuter une autre automatisation").
        val build: () -> List<Automation>
    )

    fun all(): List<Preset> = listOf(
        Preset(
            title = "💡 Allumer la lampe le soir",
            description = "À 19h00 chaque jour : allume l'ampoule connectée via requête HTTP.",
            build = {
                listOf(
                    Automation(
                        name = "Allumer la lampe (19h00)",
                        trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "19", "minute" to "0")),
                        actions = mutableListOf(
                            ActionBlock(
                                ActionType.HTTP_REQUEST,
                                mutableMapOf("url" to LAMP_ON_URL, "method" to "GET", "body" to "")
                            ),
                            ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Lampe allumée 💡")),
                            ActionBlock(ActionType.LOG_EVENT)
                        )
                    )
                )
            }
        ),
        Preset(
            title = "🌙 Routine du soir",
            description = "À 22h30 : éteint la lampe, active Ne pas déranger et baisse le volume.",
            build = {
                listOf(
                    Automation(
                        name = "Routine du soir (22h30)",
                        trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "22", "minute" to "30")),
                        actions = mutableListOf(
                            ActionBlock(
                                ActionType.HTTP_REQUEST,
                                mutableMapOf("url" to LAMP_OFF_URL, "method" to "GET", "body" to "")
                            ),
                            ActionBlock(ActionType.TOGGLE_DND, mutableMapOf("state" to "on")),
                            ActionBlock(ActionType.SET_VOLUME, mutableMapOf("level" to "2")),
                            ActionBlock(ActionType.LOG_EVENT)
                        )
                    )
                )
            }
        ),
        Preset(
            title = "📶 Bienvenue à la maison",
            description = "Quand le téléphone se connecte au Wi-Fi (ex: box maison) : allume la lampe et affiche un message.",
            build = {
                listOf(
                    Automation(
                        name = "Bienvenue à la maison",
                        trigger = TriggerBlock(TriggerType.WIFI_CONNECTED),
                        actions = mutableListOf(
                            ActionBlock(
                                ActionType.HTTP_REQUEST,
                                mutableMapOf("url" to LAMP_ON_URL, "method" to "GET", "body" to "")
                            ),
                            ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Bienvenue ! 🏠"))
                        )
                    )
                )
            }
        ),
        Preset(
            title = "🔋 Alerte batterie faible",
            description = "Batterie sous 15% : notification + vibration pour penser à brancher le téléphone.",
            build = {
                listOf(
                    Automation(
                        name = "Alerte batterie faible",
                        trigger = TriggerBlock(TriggerType.BATTERY_LOW),
                        actions = mutableListOf(
                            ActionBlock(
                                ActionType.SEND_NOTIFICATION,
                                mutableMapOf("title" to "Batterie faible", "text" to "Pense à brancher ton téléphone 🔌")
                            ),
                            ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "800"))
                        )
                    )
                )
            }
        ),
        Preset(
            title = "🔌 BlockAuto actif au démarrage",
            description = "Au démarrage du téléphone : petit message de confirmation que BlockAuto tourne bien en fond.",
            build = {
                listOf(
                    Automation(
                        name = "BlockAuto actif au démarrage",
                        trigger = TriggerBlock(TriggerType.BOOT_COMPLETED),
                        actions = mutableListOf(
                            ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "BlockAuto est actif ✅")),
                            ActionBlock(ActionType.LOG_EVENT)
                        )
                    )
                )
            }
        ),
        Preset(
            title = "🔆 Réveil en douceur",
            description = "À 7h00 : allume la lampe et règle la luminosité de l'écran pour un réveil progressif.",
            build = {
                listOf(
                    Automation(
                        name = "Réveil en douceur (7h00)",
                        trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "7", "minute" to "0")),
                        actions = mutableListOf(
                            ActionBlock(
                                ActionType.HTTP_REQUEST,
                                mutableMapOf("url" to LAMP_ON_URL, "method" to "GET", "body" to "")
                            ),
                            ActionBlock(ActionType.SET_BRIGHTNESS, mutableMapOf("level" to "60"))
                        )
                    )
                )
            }
        ),
        Preset(
            title = "🔋 Batterie : Si faible sinon message OK",
            description = "Toutes les 30 minutes : Si la batterie est sous 30% -> notification + Ne pas déranger. Sinon -> petit message discret. Démontre le bloc Si / Sinon.",
            build = {
                listOf(
                    Automation(
                        name = "Surveillance batterie (Si / Sinon)",
                        trigger = TriggerBlock(TriggerType.INTERVAL, mutableMapOf("minutes" to "30")),
                        actions = mutableListOf(
                            ActionBlock(ActionType.IF_BATTERY_BELOW, mutableMapOf("level" to "30")),
                            ActionBlock(
                                ActionType.SEND_NOTIFICATION,
                                mutableMapOf("title" to "Batterie faible", "text" to "Pense à brancher ton téléphone 🔌")
                            ),
                            ActionBlock(ActionType.TOGGLE_DND, mutableMapOf("state" to "on")),
                            ActionBlock(ActionType.ELSE_BRANCH),
                            ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Batterie OK 🔋")),
                            ActionBlock(ActionType.ENDIF)
                        )
                    )
                )
            }
        ),
        Preset(
            title = "⛓️ Arrivée au bureau (chaîne)",
            description = "Crée 2 automatisations liées : la connexion au Wi-Fi du bureau déclenche automatiquement « Mode Travail » (Ne pas déranger + volume bas). Démontre le chaînage d'automatisations.",
            build = {
                val modeTravail = Automation(
                    name = "Mode Travail (chaînon)",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.TOGGLE_DND, mutableMapOf("state" to "on")),
                        ActionBlock(ActionType.SET_VOLUME, mutableMapOf("level" to "1")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Mode travail activé 💼"))
                    )
                )
                val arriveeBureau = Automation(
                    name = "Arrivée au bureau (Wi-Fi)",
                    trigger = TriggerBlock(TriggerType.WIFI_CONNECTED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Bienvenue au bureau 🏢")),
                        ActionBlock(
                            ActionType.RUN_AUTOMATION,
                            mutableMapOf("automation_id" to modeTravail.id, "automation_name" to modeTravail.name)
                        )
                    )
                )
                listOf(modeTravail, arriveeBureau)
            }
        )
    )
}
