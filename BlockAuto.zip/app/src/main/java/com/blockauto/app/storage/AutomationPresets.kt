package com.blockauto.app.storage

import com.blockauto.app.model.ActionBlock
import com.blockauto.app.model.ActionType
import com.blockauto.app.model.Automation
import com.blockauto.app.model.TriggerBlock
import com.blockauto.app.model.TriggerType

/**
 * Suggestions réellement utilisables sans fausse adresse IP ni service externe.
 * Les actions qui dépendent d'un accès Android spécial restent explicitement
 * indiquées dans leur description.
 */
object AutomationPresets {
    data class Preset(
        val title: String,
        val description: String,
        val build: () -> List<Automation>
    )

    fun all(): List<Preset> = listOf(
        Preset(
            "🔋 Alerte batterie faible",
            "Quand Android signale une batterie faible : notification + vibration.",
            {
                listOf(Automation(
                    name = "Alerte batterie faible",
                    trigger = TriggerBlock(TriggerType.BATTERY_LOW),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "Batterie faible", "text" to "Pense à brancher ton téléphone 🔌")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "800")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Alerte batterie faible déclenchée"))
                    )
                ))
            }
        ),
        Preset(
            "🔌 BlockAuto au démarrage",
            "Au redémarrage du téléphone : message + historique. Aucun réglage externe.",
            {
                listOf(Automation(
                    name = "BlockAuto actif au démarrage",
                    trigger = TriggerBlock(TriggerType.BOOT_COMPLETED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "BlockAuto est actif ✅")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Démarrage détecté"))
                    )
                ))
            }
        ),
        Preset(
            "🎉 Secousse party",
            "Secoue le téléphone : double vibration + message.",
            {
                listOf(Automation(
                    name = "Secousse party",
                    trigger = TriggerBlock(TriggerType.SHAKE),
                    actions = mutableListOf(
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150")),
                        ActionBlock(ActionType.WAIT, mutableMapOf("seconds" to "1")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🎉 Party time !"))
                    )
                ))
            }
        ),
        Preset(
            "✨ Batterie pleine",
            "Quand le téléphone est branché : vibration + message de confirmation.",
            {
                listOf(Automation(
                    name = "Batterie pleine",
                    trigger = TriggerBlock(TriggerType.BATTERY_FULL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "200")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "✨ Batterie pleine / secteur détecté"))
                    )
                ))
            }
        ),
        Preset(
            "🎧 Casque branché",
            "Quand un casque filaire est branché : notification + vibration.",
            {
                listOf(Automation(
                    name = "Casque branché",
                    trigger = TriggerBlock(TriggerType.HEADSET_CONNECTED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "🎧 Casque connecté", "text" to "Ton casque vient d'être branché.")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150"))
                    )
                ))
            }
        ),
        Preset(
            "📶 Connexion Wi‑Fi",
            "Quand un Wi‑Fi est détecté : message de confirmation. Tu peux ensuite modifier le SSID dans l'atelier.",
            {
                listOf(Automation(
                    name = "Connexion Wi‑Fi",
                    trigger = TriggerBlock(TriggerType.WIFI_CONNECTED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "📶 Wi‑Fi connecté")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Connexion Wi‑Fi détectée"))
                    )
                ))
            }
        ),
        Preset(
            "⏰ Test dans 1 minute",
            "Crée une automatisation temporaire qui se déclenche une minute après l'activation. Pratique pour vérifier que les alarmes fonctionnent.",
            {
                listOf(Automation(
                    name = "Test alarme 1 minute",
                    trigger = TriggerBlock(TriggerType.INTERVAL, mutableMapOf("minutes" to "1")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "BlockAuto", "text" to "✅ Le déclencheur fonctionne !")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Test du déclencheur INTERVAL réussi"))
                    )
                ))
            }
        ),
        Preset(
            "🎲 Coup de dé",
            "Déclenchement manuel : 50 % de chance d'afficher un message chanceux.",
            {
                listOf(Automation(
                    name = "Coup de dé",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.RANDOM_CHANCE, mutableMapOf("percent" to "50")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "100")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🍀 Aujourd'hui est ton jour de chance !"))
                    )
                ))
            }
        ),
        Preset(
            "⛓️ Démonstration du chaînage",
            "Crée deux automatisations. La première lance automatiquement la seconde : tu peux tester la chaîne avec le bouton ▶️.",
            {
                val second = Automation(
                    name = "Chaîne B — message",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "Chaîne BlockAuto", "text" to "⛓️ La deuxième automatisation a bien été exécutée !")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Chaîne B exécutée"))
                    )
                )
                val first = Automation(
                    name = "Chaîne A — lance B",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "⛓️ Lancement de la chaîne…")),
                        ActionBlock(ActionType.RUN_AUTOMATION, mutableMapOf("automation_id" to second.id, "automation_name" to second.name)),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Chaîne A terminée"))
                    )
                )
                listOf(first, second)
            }
        ),
        Preset(
            "🔊 Volume à 50 %",
            "À 8h00 : règle le volume média à environ 50 %. Nécessite uniquement l'accès audio normal.",
            {
                listOf(Automation(
                    name = "Volume du matin (8h00)",
                    trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "8", "minute" to "0")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SET_VOLUME, mutableMapOf("level" to "7")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🔊 Volume réglé pour le matin"))
                    )
                ))
            }
        ),
        Preset(
            "📨 Rappels par SMS",
            "Déclenchement manuel : envoie 3 SMS de rappel à la suite au même numéro, espacés de quelques secondes. Modifie le numéro et le nombre de messages dans l'atelier.",
            {
                listOf(Automation(
                    name = "Rappels par SMS",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(
                            ActionType.SEND_MULTIPLE_SMS,
                            mutableMapOf(
                                "number" to "0600000000",
                                "text" to "Rappel {n}/3 : n'oublie pas ! ⏰",
                                "count" to "3",
                                "delay_seconds" to "5"
                            )
                        ),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Série de rappels SMS envoyée"))
                    )
                ))
            }
        ),
        Preset(
            "🔢 Compteur façon Scratch",
            "Déclenchement manuel : crée une variable, l'incrémente, tire un nombre au hasard et affiche le résultat — pour découvrir les nouveaux blocs Variables.",
            {
                listOf(Automation(
                    name = "Compteur façon Scratch",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SET_VARIABLE, mutableMapOf("name" to "score", "value" to "0")),
                        ActionBlock(ActionType.INCREMENT_VARIABLE, mutableMapOf("name" to "score", "amount" to "10")),
                        ActionBlock(ActionType.RANDOM_NUMBER, mutableMapOf("name" to "bonus", "min" to "1", "max" to "6")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Score : {score} (+{bonus} de bonus 🎲)")),
                        ActionBlock(ActionType.VIBRATE_PATTERN, mutableMapOf("pattern" to "0,100,80,100"))
                    )
                ))
            }
        ),
        Preset(
            "🗓️ Rappel les jours ouvrés",
            "Tous les lundis à vendredis à 9h00 : notification + bip. Utilise le nouveau bloc « Heure précise, certains jours ».",
            {
                listOf(Automation(
                    name = "Rappel jours ouvrés (9h00)",
                    trigger = TriggerBlock(
                        TriggerType.WEEKDAY_TIME,
                        mutableMapOf("hour" to "9", "minute" to "0", "days" to "MO,TU,WE,TH,FR")
                    ),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "🗓️ Bonjour !", "text" to "C'est parti pour une nouvelle journée.")),
                        ActionBlock(ActionType.PLAY_BEEP, mutableMapOf("count" to "1"))
                    )
                ))
            }
        ),
        Preset(
            "⛓️ Chaîne complexe à valeurs",
            "Déclenchement manuel : crée 3 automatisations liées. La première tire un score au hasard, PASSE ce score en argument à la seconde, qui décide (via une vraie condition Si/Sinon sur la variable) de chaîner vers « Victoire » ou « Retente ta chance » — et le résultat final revient s'afficher dans la première.",
            {
                val victoire = Automation(
                    name = "Chaîne — Victoire 🏆",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SET_VARIABLE, mutableMapOf("name" to "resultat", "value" to "Gagné avec {score} points ! 🏆")),
                        ActionBlock(ActionType.VIBRATE_PATTERN, mutableMapOf("pattern" to "0,100,60,100,60,200"))
                    )
                )
                val retente = Automation(
                    name = "Chaîne — Retente ta chance 🔁",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SET_VARIABLE, mutableMapOf("name" to "resultat", "value" to "Raté avec seulement {score} points... 🔁")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "200"))
                    )
                )
                val decision = Automation(
                    name = "Chaîne — Décision",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.IF_VARIABLE_ABOVE, mutableMapOf("name" to "score", "value" to "50")),
                        ActionBlock(ActionType.RUN_AUTOMATION, mutableMapOf("automation_id" to victoire.id, "automation_name" to victoire.name)),
                        ActionBlock(ActionType.ELSE_BRANCH),
                        ActionBlock(ActionType.RUN_AUTOMATION, mutableMapOf("automation_id" to retente.id, "automation_name" to retente.name)),
                        ActionBlock(ActionType.ENDIF)
                    )
                )
                val depart = Automation(
                    name = "Chaîne complexe à valeurs — Départ",
                    trigger = TriggerBlock(TriggerType.MANUAL),
                    actions = mutableListOf(
                        ActionBlock(ActionType.RANDOM_NUMBER, mutableMapOf("name" to "score", "min" to "1", "max" to "100")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "Score tiré : {score}, on lance la décision...")),
                        ActionBlock(ActionType.RUN_AUTOMATION, mutableMapOf("automation_id" to decision.id, "automation_name" to decision.name)),
                        ActionBlock(ActionType.SEND_NOTIFICATION, mutableMapOf("title" to "⛓️ Résultat de la chaîne", "text" to "{resultat}"))
                    )
                )
                listOf(depart, decision, victoire, retente)
            }
        ),
        Preset(
            "🏷️💬 Tag NFC → message WhatsApp direct",
            "Colle le tag NFC où tu veux (porte, voiture, bureau...) : le scanner ouvre WhatsApp, ouvre la conversation, écrit et ENVOIE le message tout seul (blocs « Dans l'appli »). Après import : ouvre l'automatisation dans l'atelier, retouche le déclencheur pour scanner TON tag NFC, puis modifie le nom du contact et le message dans le bloc action.",
            {
                listOf(Automation(
                    name = "🏷️ Tag NFC → WhatsApp",
                    // tag_uid vide : à la première ouverture dans l'atelier, retape sur le
                    // déclencheur puis choisis « Tag NFC scanné » pour l'associer à un vrai tag.
                    trigger = TriggerBlock(TriggerType.NFC_TAG_SCANNED, mutableMapOf("tag_uid" to "")),
                    actions = mutableListOf(
                        ActionBlock(
                            ActionType.UI_OPEN_APP_AND_SEND_MESSAGE,
                            mutableMapOf(
                                "package" to "com.whatsapp",
                                "contact_text" to "Nom du contact",
                                "text" to "Message envoyé automatiquement via le tag NFC 🏷️",
                                "send_label" to ""
                            )
                        ),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "Message WhatsApp envoyé via tag NFC"))
                    )
                ))
            }
        ),
        Preset(
            "🏷️✈️ Tag NFC → message Telegram (plusieurs messages)",
            "Même principe que le préréglage WhatsApp, mais pour Telegram, avec un premier message d'ouverture PUIS deux messages supplémentaires envoyés à la suite (bloc « envoyer plusieurs messages à la suite »). À personnaliser après import : contact, textes, délai entre les messages.",
            {
                listOf(Automation(
                    name = "🏷️ Tag NFC → Telegram (x3)",
                    trigger = TriggerBlock(TriggerType.NFC_TAG_SCANNED, mutableMapOf("tag_uid" to "")),
                    actions = mutableListOf(
                        ActionBlock(
                            ActionType.UI_OPEN_APP_AND_SEND_MESSAGE,
                            mutableMapOf(
                                "package" to "org.telegram.messenger",
                                "contact_text" to "Nom du contact",
                                "text" to "Message 1/3 : bien arrivé 👋",
                                "send_label" to ""
                            )
                        ),
                        ActionBlock(
                            ActionType.UI_SEND_MULTIPLE_MESSAGES_IN_APP,
                            mutableMapOf(
                                "text" to "Message {n}/3 automatique via tag NFC 🏷️",
                                "count" to "2",
                                "delay_seconds" to "4",
                                "send_label" to ""
                            )
                        ),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "3 messages Telegram envoyés via tag NFC"))
                    )
                ))
            }
        ),
        Preset(
            "🏷️📩 Tag NFC → SMS direct (fiable, sans accessibilité)",
            "Alternative plus fiable aux deux préréglages ci-dessus : envoie un vrai SMS via l'API Android (fonctionne même si le service d'accessibilité BlockAuto n'est pas activé, ou si l'appli de messagerie change son interface). À personnaliser : numéro et texte du message.",
            {
                listOf(Automation(
                    name = "🏷️ Tag NFC → SMS direct",
                    trigger = TriggerBlock(TriggerType.NFC_TAG_SCANNED, mutableMapOf("tag_uid" to "")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SEND_SMS, mutableMapOf("number" to "0600000000", "text" to "Message envoyé automatiquement via un tag NFC 🏷️")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "150")),
                        ActionBlock(ActionType.LOG_EVENT, mutableMapOf("text" to "SMS envoyé via tag NFC"))
                    )
                ))
            }
        ),
        Preset(
            "🌙 Ne pas déranger le soir",
            "Tous les jours à 22h00 : active « Ne pas déranger » et passe la sonnerie en silencieux. Nécessite d'accorder l'accès « Ne pas déranger » dans les autorisations BlockAuto.",
            {
                listOf(Automation(
                    name = "Ne pas déranger le soir (22h00)",
                    trigger = TriggerBlock(TriggerType.TIME, mutableMapOf("hour" to "22", "minute" to "0")),
                    actions = mutableListOf(
                        ActionBlock(ActionType.TOGGLE_DND, mutableMapOf("state" to "on")),
                        ActionBlock(ActionType.SET_RINGER_MODE, mutableMapOf("mode" to "silent")),
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "🌙 Ne pas déranger activé pour la nuit"))
                    )
                ))
            }
        ),
        Preset(
            "🔓 Bonjour au déverrouillage",
            "Premier déverrouillage du téléphone : petit message de bienvenue + vibration légère. Utile comme point de départ pour ajouter d'autres blocs (météo, agenda...) une fois testé.",
            {
                listOf(Automation(
                    name = "Bonjour au déverrouillage",
                    trigger = TriggerBlock(TriggerType.DEVICE_UNLOCKED),
                    actions = mutableListOf(
                        ActionBlock(ActionType.SHOW_TOAST, mutableMapOf("text" to "👋 Bonjour ! Bonne journée.")),
                        ActionBlock(ActionType.VIBRATE, mutableMapOf("duration_ms" to "80"))
                    )
                ))
            }
        )
    )
}
